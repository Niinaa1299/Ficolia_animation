# Ficolia

Ce dossier sert à concevoir l'animation d'ouverture, les écrans d'accueil et les animations du récit de la figue de Ficolia. Le brief complet est importé ci-dessous ; les fichiers de référence sont dans `design/`.

@design/FICOLIA_DESIGN.md
