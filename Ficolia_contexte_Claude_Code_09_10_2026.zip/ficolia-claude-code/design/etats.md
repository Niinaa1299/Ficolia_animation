# Les écrans du récit de la figue

Version du 9 octobre 2026. Pour chaque écran : quand il apparaît, ce que dit le projet (références au registre v6.4), les textes, ce qu'il faut savoir et ce qui reste ouvert.

« Nouveau » signifie que l'écran n'existe pas encore au registre : il y sera inscrit s'il est retenu. « À construire » signifie que l'écran est prévu par le projet mais n'a pas encore été dessiné.

## Le parcours

- **Premier lancement** : écran de lancement fixe du téléphone, puis animation d'ouverture, puis accueil 1/3, 2/3, 3/3 (acceptation des conditions d'utilisation), puis le scanner.
- **Ouvertures suivantes** : l'animation d'ouverture joue-t-elle à chaque fois ? Non tranché (§1).
- **Les six états** surviennent en cours d'usage.

## 1. Animation d'ouverture — « Révélation du logo »

**Statut** : validée en l'état par la porteuse le 09/10 ; améliorable.

**Référence** : `design/reference/revelation-logo.dc.html` ; son déroulé est décrit dans `FICOLIA_DESIGN.md` §6.

**À savoir**
- C'est une planche du canevas de conception du prototype : `{{cls}}` et `{{chair}}` sont remplis par le canevas, qui n'est pas fourni. Réglages prévus dans la planche :
  - lecture : en boucle, une fois, ou image figée ;
  - vitesse : 1×, 0,5× ou 0,25× ;
  - instant figé ;
  - couleur de la chair : `#FFFFFF` par défaut, `#FAF4EE` ou `#EBD3CB`.
- Le logotype y est vectorisé : les lettres « Fic » et « lia » sont des tracés, la figue fait le « o ».
- Avant la première image dessinée par Flutter, Android affiche un écran de lancement fixe. La documentation Flutter conseille de reproduire sa dernière image en Flutter, pour que le passage de l'un à l'autre ne se voie pas. L'animation part donc de cet écran fixe, qui se conçoit avec elle. Pour iOS : à vérifier.
- La phrase d'accroche « Vos cosmétiques, en toute sérénité. » est un texte provisoire (`textes.md` §5.2).

**Points ouverts**
- **Vitesse validée.** Dans le canevas, la planche joue par défaut au ralenti (0,5×), soit 10 secondes ; à vitesse réelle, l'animation dure 5 secondes. À confirmer par la porteuse.
- **Fréquence.** À chaque ouverture, ou au premier lancement seulement ? L'application s'utilise surtout en magasin (Périmètre MVP §1.6). Tu peux proposer une version courte pour les ouvertures suivantes.

## 2. Accueil — trois écrans

**Statut** : existe au prototype (étape 1). Son apparence est à refaire entièrement (porteuse, 09/10) : ces trois écrans doivent donner la meilleure impression dès le premier lancement. Ils font partie du récit.

**Quand** : au premier lancement, juste après l'animation d'ouverture.

**Contenu acté** : trois contenus (`D-114` C7), détaillés par le dossier de conception (§5.1).
- **1/3, ce que fait l'application** : selon le dossier, les deux lignes, la composition d'un produit, pas un avis médical, et le rappel général « Pour toute question de santé, adressez-vous à un professionnel de santé » (`D-114` C8).
- **2/3, ce qu'elle ne sait pas faire** :
  - les grossesses non physiologiques, comme limite et non comme exclusion : l'application ne demande rien (`D-80`) ;
  - les produits vendus hors de France (`T-173`) ;
  - des données qui datent de leur source.
- **3/3, l'acceptation** (`T-557`) : limites essentielles en mots simples, lien vers les conditions d'utilisation, bouton « Accepter », aucune case précochée. Une nouvelle acceptation est demandée à chaque nouvelle version des conditions. Un lien vers la politique de confidentialité a été ajouté en séance (décision du 05/10, à valider par la juriste).

**Décisions de séance à connaître**
- Pas de liste à puces « en trois temps ». Les titres des écrans 1/3 et 2/3 sont retirés de l'écran mais gardés pour les lecteurs d'écran (06/10).
- Logotype complet à l'accueil (28/09).
- Idée du 06/10 : la figue se promène aux écrans 1/3 et 2/3, puis se pose dans le nom au 3/3. La réalisation a été jugée pas convaincante ; la refonte peut la remplacer. À noter : à la fin de l'animation d'ouverture, le logo est déjà complet.
- Aucune demande d'autorisation sur ces écrans : pas de notification (`T-224`), et la caméra n'est demandée qu'au premier scan (`T-232` ; décision du 05/10).

**Textes** : `textes.md` §5.1.

**Point ouvert** : le dossier de conception (§5.1) prévoit que le premier contenu parle des deux lignes ; le registre (`D-114` C7) ne le précise pas. La phrase qui le faisait, « Chaque produit reçoit deux lignes : grossesse, allaitement. », a été retirée par la porteuse le 06/10. À confirmer avec elle.

## 3. Formulaire envoyé

**Statut** : à construire (étapes 4 et 6 du prototype).

**Trois formulaires** (porteuse, 09/10) :
- **Signalement d'une erreur** (`D-55`). Jamais le mot « réclamation » (`T-103`).
- **Contribution photo**, en option activable (`D-113` B2).
- **Message au support** (`T-109`).

**Ce que dit le projet**
- **Contribution** : remercier, ne rien promettre ; « si le produit est publié », jamais « quand » (`T-81`). Une photo contribuée ne produit jamais de verdict pour celle qui l'a prise (`L-7`).
- **Support** : animation sobre, sans humour (porteuse, 09/10). Un message au support peut signaler un effet indésirable survenu (`T-457`, à arbitrer) ou une détresse (`T-404`, `T-115`). L'application ne lit pas le message.

**Texte** : aucun texte de confirmation acté.

**À prévoir** : au moins deux variantes, l'une avec humour (signalement, contribution), l'autre sobre (support).

## 4. Connexion insuffisante ou absente

**Statut** : à construire (étapes 3 et 5).

**Ce que dit le projet** : états dégradés (`T-203`) ; réseau faible en rayon (`T-130`) ; scan mis en attente faute de réseau (`T-512`). Les règles des écrans d'échec s'appliquent (`FICOLIA_DESIGN.md` §4).

**À savoir**
- Hors réseau, l'application n'est pas vide : les verdicts déjà consultés et ceux du catalogue embarqué restent lisibles (`D-91`).
- Ce qui ne marche pas : un produit absent du cache n'a aucun chemin, et la recherche par nom ne fonctionne pas (`L-35`).
- L'écran dit sa cause (`T-512`) : c'est le réseau qui manque, pas l'application qui ne marche plus.
- Contexte : souvent en rayon de magasin.

**Texte** : aucun texte acté.

## 5. Mise à jour obligatoire

**Statut** : nouveau, absent du registre.

**Brief** : une figue séchée, qui redevient fraîche une fois l'application à jour.

**À savoir**
- Pendant l'installation, c'est le store ou le système qui s'affiche, pas Ficolia. La figue séchée vit donc dans l'ancienne version, sur l'écran qui invite à mettre à jour. La figue fraîche ne peut apparaître qu'au premier lancement de la nouvelle version. Le mécanisme exact dépend de la solution de mise à jour retenue.
- Si les conditions d'utilisation ont changé, une nouvelle acceptation suit (`T-557`).
- Aucune annonce de fonction future, aucune revendication (« plus sûre », « sécurisée »…) : voir `textes.md`.

**Texte** : aucun.

## 6. Délai pendant la recherche de connexion

**Statut** : nouveau, absent du registre. Proche de la synchronisation qui précède le message du retour après une longue absence (`D-114` C2).

**À savoir**
- Une absence totale de réseau se détecte tout de suite ; une connexion trop faible, seulement au bout d'un délai d'attente. Ce délai n'est fixé nulle part : c'est lui qui fait passer de cet état à « connexion insuffisante ». Paramètre à faire fixer par la porteuse.
- Accessibilité : si l'animation est seule à l'écran, elle n'a pas à pouvoir être arrêtée. Avec d'autres contenus et au-delà de 5 secondes, si (WCAG 2.1, critère 2.2.2).

**Texte** : aucun.

## 7. Produit scanné mais inconnu

**Statut** : à construire (étape 3). C'est l'état 2 du registre.

**Texte acté** : « Nous ne connaissons pas ce produit » (`D-113` B3 ; Périmètre MVP §3.2).

**Ce que dit le projet**
- Jamais un feu vert, jamais une alerte ; l'absence d'évaluation est dite en clair (`D-113` B3).
- Le produit rejoint la file de transcription sans message de promesse (dossier §5.7).
- Ce peut être le premier scan qui échoue, un moment à soigner : c'est là que l'utilisatrice décide si elle scanne un quatrième produit (`T-253`). L'application ne doit pas paraître vide à chaque scan (`D-102`).

**Variantes**
- **Invitation à photographier la liste d'ingrédients** : présente ou absente, selon que l'option de contribution est activée (`T-512`, `D-113` B2).
- **Nom et photo du produit** : présents ou absents. Si la base ouverte reconnaît le produit (option a, `D-113` B1, encore ouverte), ils s'affichent sans verdict. Une figue réjouie à côté peut se lire « tout va bien » : le Périmètre MVP relève ce risque pour un cas voisin (§2.3).

**À savoir**
- Ne pas confondre avec « Ce produit n'est pas un cosmétique » (état 3, hors du récit). Ce sont deux messages aux comportements opposés : la contribution est proposée pour un produit inconnu, jamais pour un produit qui n'est pas un cosmétique (Périmètre MVP §3.2).
- Probablement fréquent au lancement : la couverture du catalogue n'est pas encore mesurée (`T-515`, `T-516`).

## 8. Service indisponible

**Statut** : à construire (étape 3). C'est l'état 5 du registre (`T-128`), provisoire.

**Dans les mots de la porteuse** : « l'application est indisponible ».

**À savoir**
- L'application s'ouvre, et les verdicts embarqués restent lisibles sur le téléphone (`D-91`) : c'est le service qui est indisponible, pas l'application. Le mot affiché compte, puisque chaque écran dit sa cause (`T-512`).
- À distinguer de « source externe indisponible » (`T-512`, `T-123`), qui n'est pas dans le récit.
- Il touche toutes les utilisatrices en même temps (`T-128`).

**Texte** : aucun texte acté.
