# Textes — règles et textes existants

Version du 9 octobre 2026. L'humour passera aussi par les mots : ces règles valent pour chaque texte que tu proposes.

## 1. Règles actées

Tirées du dossier de conception (§4.3), lui-même tiré du registre.

1. **Aucune modulation d'usage** : ni fréquence, ni quantité, ni durée (`T-402`).
2. **Aucun appel à l'action sur l'écran produit ni sur l'écran de verdict** : ni « consultez votre médecin », ni « évitez », ni « vérifiez » (`D-66`, `T-403`).
3. **Neutralité** : aucun texte ne suppose que la grossesse est en cours, que le bébé est né, ni même que c'est la lectrice qui est concernée (`D-114` C1).
4. **Aucune date**, sauf la date de publication d'une source, dans le panneau d'un ingrédient (`D-52`, `D-94`). Exception : la date de version des conditions d'utilisation et de la fiche méthode (`D-114` C9).
5. **Aucune revendication** (`T-406`, `T-534`).
6. **Le nom Ficolia, seul.**
7. **Le rappel général** — « Pour toute question de santé, adressez-vous à un professionnel de santé » — figure à quatre endroits : l'accueil, « À propos » et la fiche méthode, les conditions d'utilisation, la description des stores (`D-114` C8). Jamais sur l'écran produit ni sur un écran de verdict.

Ne rien écrire sur la manière dont les verdicts sont établis : cette formulation est une question ouverte (`D-116`, `T-534`, `T-551`).

## 2. Mots et formules à ne pas écrire

Liste du dossier de conception (§4.4) :

« sûr », « sans danger », « vérifié », « sécurisé », « validé par un comité », « validé par une sage-femme », « pour vous et votre bébé », « la seule application », « utilisable », « contre-indiqué » et « interdit » comme jugement de l'application, « Ne pas utiliser », « votre profil », « votre grossesse », « votre bébé », « bientôt », « disponible en V2 », « nous veillons sur les ingrédients », « ne jamais douter », « vérifié par un toxicologue », « NB attribués par un toxicologue ».

## 3. Règles proposées, pas encore arbitrées

Elles viennent de `T-533`, au statut « à arbitrer, plancher proposé ». Si une proposition s'en écarte, dis-le.

- (d) Aucune annonce de fonction future.
- (e) Aucune promesse de surveillance, de certitude ni de rappel individuel.
- (g) Aucun message d'acquisition jouant sur l'anxiété.
- (h) Jamais « application de santé ».
- (k) Des messages « rassurants sans être minimisants, alarmants sans être anxiogènes ».

Les textes publics hors de l'application (site, réseaux, stores) suivent les mêmes règles (`T-546`, à arbitrer).

## 4. Marquage

- **Texte nouveau que tu proposes** : étiquette « Proposition ».
- **Texte en attente d'un tiers** (toxicologue ou juriste) : étiquette « Texte provisoire », comme dans le prototype.
- **Texte à écrire** : texte de remplacement entre crochets, par exemple « [Limites essentielles, en mots simples — en attente de la juriste] ».

## 5. Textes existants

### 5.1 Accueil

Posés à l'étape 1 du prototype. Tous provisoires, sauf mention contraire.

| Où | Texte | Statut |
| --- | --- | --- |
| Écran 1/3 | « Ficolia informe sur la composition d'un produit cosmétique pendant la grossesse et l'allaitement. » | Provisoire |
| Écran 1/3 | « Ce n'est pas un avis médical. Pour toute question de santé, adressez-vous à un professionnel de santé. » | La seconde phrase est le rappel général, acté sous réserve de la juriste (`D-114` C8) |
| Écran 1/3 | Titre « Ce que fait Ficolia » | Retiré de l'écran le 06/10, gardé pour les lecteurs d'écran |
| Écran 2/3 | « Les verdicts sont établis pour une grossesse physiologique. Ficolia ne couvre pas les produits vendus hors de France. » | Provisoire ; la formulation de la première phrase est à arrêter avec la juriste (`D-80`, `L-30`) |
| Écran 2/3 | « Une formule peut changer sans que le code-barres change : les données datent de leur source. » | Provisoire |
| Écran 2/3 | Titre « Ce que Ficolia ne sait pas faire » | Retiré de l'écran le 06/10, gardé pour les lecteurs d'écran |
| Écran 3/3 | Titre « Conditions d'utilisation » ; « Pour utiliser Ficolia, il faut en accepter les conditions d'utilisation. » | Provisoire (juriste, `T-557`) |
| Écran 3/3 | « [Limites essentielles, en mots simples — en attente de la juriste] » | Texte de remplacement |
| Écran 3/3 | Liens « Lire les conditions d'utilisation » et « Politique de confidentialité » ; mention « Conditions d'utilisation — version du [date] » | Provisoire ; le second lien attend la juriste |
| Boutons | « Continuer », « Accepter », « Retour » | « Accepter » est acté (dossier §5.1) ; les deux autres sont provisoires |

Retiré par la porteuse le 06/10 : « Chaque produit reçoit deux lignes : grossesse, allaitement. » (voir `etats.md` §2, point ouvert).

### 5.2 Animation d'ouverture

« Vos cosmétiques, » / « en toute sérénité. »

**Texte provisoire** : texte public qui n'est encore passé ni par les règles de ce fichier ni par la juriste. Ne le réemploie pas ailleurs.

### 5.3 Produit scanné mais inconnu

« Nous ne connaissons pas ce produit » : **acté** (`D-113` B3 ; Périmètre MVP §3.2).

### 5.4 Les autres états du récit

Aucun texte acté. Pour toute confirmation de contribution : « si le produit est publié », jamais « quand » (`T-81`).
