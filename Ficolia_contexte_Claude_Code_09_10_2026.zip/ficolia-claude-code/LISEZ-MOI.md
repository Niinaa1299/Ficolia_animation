# Paquet de contexte Ficolia pour Claude Code — mode d'emploi

Version du 9 octobre 2026.

## Ce que contient le paquet

| Fichier | Rôle |
| --- | --- |
| `CLAUDE.md` | Lu automatiquement par Claude Code au début de chaque session ; il importe le brief principal |
| `design/FICOLIA_DESIGN.md` | Le brief : l'univers, la mission, la méthode, les règles du projet, l'identité visuelle, l'animation d'ouverture |
| `design/etats.md` | Les écrans du récit, un par un : ce que dit le projet, les textes, les points ouverts |
| `design/textes.md` | Règles de texte, mots interdits, textes existants et leur statut |
| `design/tokens.json` | Couleurs (dont celles à ne jamais employer), polices, valeurs d'accessibilité |
| `design/assets/figue-symbole.svg` | La figue en vectoriel (ton fichier, recopié tel quel) |
| `design/reference/revelation-logo.dc.html` | L'animation d'ouverture validée (ton fichier, recopié tel quel) |

## Installer

**Cas 1 — le dossier n'a pas encore de `CLAUDE.md`** (un dossier réservé au design, ou un dépôt qui n'en a pas). Copie tout le contenu du paquet à la racine du dossier, puis ouvre Claude Code dans ce dossier. Le `CLAUDE.md` est lu tout seul.

**Cas 2 — le dossier a déjà un `CLAUDE.md`** (par exemple ton dépôt Flutter). Copie seulement le dossier `design/`, puis ajoute cette ligne, seule sur sa ligne, à ton `CLAUDE.md` existant :

`@design/FICOLIA_DESIGN.md`

- Recopie-la sans accents graves ni guillemets : sinon Claude Code ne l'importe pas.
- Le chemin se lit depuis l'emplacement de ton `CLAUDE.md`. S'il est rangé dans le dossier `.claude/`, écris plutôt `@../design/FICOLIA_DESIGN.md`.
- Ne remplace pas ton `CLAUDE.md` par le mien.

**Dans les deux cas** : crée un dossier `design/captures/` et ajoutes-y des captures des écrans actuels du prototype (scanner, écran produit, accueil). Elles aident Claude Code à accorder ses propositions au reste de l'application.

## Première demande à lui faire

> Lis le brief et `design/etats.md`, puis propose le scénario de la figue : quelle étape de sa vie pour quel écran, en deux ou trois pistes, avec la pointe d'humour de chacune. Ne construis rien avant mon choix.

## Ce qu'il faut me rapporter dans le projet

- Les propositions que tu retiens (fichiers HTML), pour les intégrer au canevas du prototype.
- Tes choix, pour les tracer avec les autres décisions de séance.

## Limites

- Claude Code traite ce paquet comme du contexte, pas comme une contrainte absolue (documentation de Claude Code) : relis ses propositions.
- C'est un instantané au 9 octobre 2026. Si le registre change, le paquet doit être mis à jour.
- Je n'ai pas pu ouvrir le canevas depuis cette conversation : les espacements et les arrondis des planches n'y figurent pas. Tes captures compensent en partie.
