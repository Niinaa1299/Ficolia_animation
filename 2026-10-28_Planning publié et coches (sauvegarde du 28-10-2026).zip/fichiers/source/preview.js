// Aperçu de la page du planning : base factice, erreurs console, captures.
// Usage : node preview.js OUTDIR
const { chromium } = require("playwright");
const fs = require("fs");
const path = require("path");
const OUT = process.argv[2];
const page0 = fs.readFileSync(path.join(OUT, "planning.html"), "utf8");
const plan = JSON.parse(fs.readFileSync(path.join(OUT, "plan.json"), "utf8"));
const seed = {};
for (const [k, v] of Object.entries(plan.coches_initiales)) seed[k] = { fait: true, le: v.le, par: "Claude", source: v.source };

const fake = `<script>
(function(){
  const store = ${JSON.stringify(seed)};
  const subs = [];
  const snap = () => ({ docs: Object.keys(store).sort().map(id => ({ id, exists: true, data: () => store[id] })) });
  const emit = () => subs.forEach(f => f(snap()));
  const coll = { limit(){ return coll; }, onSnapshot(next){ subs.push(next); setTimeout(() => next(snap()), 20); return () => {}; },
    doc(id){ return { set: async d => { store[id] = d; emit(); }, delete: async () => { delete store[id]; emit(); } }; } };
  const db = { collection(){ return coll; } };
  const user = { can: async () => true };
  window.claude = { use: async n => n === "db" ? db : n === "user" ? user : null };
  window.__store = store;
})();
</script>`;
const skel = (dark, withDb) => `<!doctype html><html${dark ? ' data-theme="dark"' : ""}><head><meta charset=utf8><meta name=viewport content="width=device-width,initial-scale=1,viewport-fit=cover"><style>:root{color-scheme:light;padding-top:env(safe-area-inset-top);padding-bottom:env(safe-area-inset-bottom)}body{margin:0;font:14px system-ui}img{max-width:100%}[hidden]{display:none!important}</style>${withDb ? fake : ""}</head><body>${page0}</body></html>`;

(async () => {
  const browser = await chromium.launch();
  const runs = [["bureau_clair", 1280, false, true], ["bureau_sombre", 1280, true, true], ["telephone", 390, false, true], ["sans_base", 1280, false, false]];
  for (const [nom, w, dark, withDb] of runs) {
    const ctx = await browser.newContext({ viewport: { width: w, height: 900 }, deviceScaleFactor: 1 });
    const p = await ctx.newPage();
    const errs = [];
    p.on("pageerror", e => errs.push("pageerror: " + e.message));
    p.on("console", m => { if (m.type() === "error" && !/fonts\.g|ERR_FAILED|net::/.test(m.text())) errs.push("console: " + m.text()); });
    await p.route("**/*", r => r.request().url().startsWith("http") ? r.abort() : r.continue());
    await p.setContent(skel(dark, withDb), { waitUntil: "load" });
    await p.waitForTimeout(400);
    const info = await p.evaluate(() => ({
      etat: document.getElementById("etat").textContent,
      scrollW: document.documentElement.scrollWidth, clientW: document.documentElement.clientWidth,
      pct: document.querySelector(".ring span") && document.querySelector(".ring span").textContent,
      cette: document.querySelector("#pt-cette .n").textContent, tiers: document.querySelector("#pt-tiers .n").textContent,
      retard: document.querySelector("#pt-retard .n").textContent, prochaine: document.querySelector("#pt-prochaine .n").textContent,
      cb: document.querySelectorAll("#ch-list input[type=checkbox]").length,
      checked: document.querySelectorAll("#ch-list input[type=checkbox]:checked").length,
      disabled: document.querySelectorAll("#ch-list input[type=checkbox]:disabled").length,
      verrous: document.querySelectorAll("#ver-tab tbody tr").length,
    }));
    console.log(nom, JSON.stringify(info));
    await p.screenshot({ path: path.join(OUT, "apercu_" + nom + ".png"), fullPage: false });
    if (nom === "bureau_clair") {
      await p.evaluate(() => { document.querySelector('details.ch[data-ch="GR"]').open = true; document.getElementById("it-GR-2").open = true; });
      await p.click("#c-GR-2\\.2");
      await p.waitForTimeout(100);
      const a = await p.evaluate(() => [window.__store["GR-2.2"], document.querySelector(".ring span").textContent, document.querySelector('li[data-sid="GR-2.2"]').className]);
      console.log("apres coche", JSON.stringify(a));
      await p.click("#c-GR-2\\.3");
      await p.waitForTimeout(100);
      const t = await p.evaluate(() => [document.querySelector("#pt-tiers .n").textContent, document.querySelector("#pt-tiers ul") && document.querySelector("#pt-tiers ul").innerText.slice(0, 200)]);
      console.log("envoi GR-2 coche -> chez un tiers", JSON.stringify(t));
      await p.click("#c-GR-2\\.3"); await p.click("#c-GR-2\\.2");
      await p.waitForTimeout(100);
      console.log("apres decoche", JSON.stringify(await p.evaluate(() => [!!window.__store["GR-2.2"], document.querySelector(".ring span").textContent])));
      const sect = async (id, f) => { await p.evaluate(i => document.getElementById(i).scrollIntoView(), id); await p.waitForTimeout(80); await p.screenshot({ path: path.join(OUT, f) }); };
      await sect("gantt", "apercu_gantt.png"); await sect("envois", "apercu_envois.png"); await sect("simulation", "apercu_dates.png");
      await p.evaluate(() => document.getElementById("it-GR-2").scrollIntoView()); await p.waitForTimeout(80);
      await p.screenshot({ path: path.join(OUT, "apercu_item.png") });
      await p.fill("#q", "T-236"); await p.waitForTimeout(80);
      console.log("recherche T-236", await p.evaluate(() => Array.from(document.querySelectorAll("#ch-list details.it:not([hidden])")).map(d => d.dataset.item).join(",")));
    }
    if (nom === "telephone") {
      await p.evaluate(() => { document.querySelector('details.ch[data-ch="AL"]').open = true; const d = document.getElementById("it-AL-1"); d.open = true; d.scrollIntoView(); });
      await p.waitForTimeout(80);
      await p.screenshot({ path: path.join(OUT, "apercu_telephone_item.png") });
      await p.evaluate(() => document.getElementById("gantt").scrollIntoView()); await p.waitForTimeout(80);
      await p.screenshot({ path: path.join(OUT, "apercu_telephone_gantt.png") });
      console.log("telephone largeur apres ouverture", await p.evaluate(() => [document.documentElement.scrollWidth, document.documentElement.clientWidth]));
    }
    if (errs.length) console.log("ERREURS", nom, errs.join("\n"));
    await ctx.close();
  }
  await browser.close();
})();
