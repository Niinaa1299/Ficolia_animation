"""Construit les données du planning Ficolia : contrôles, simulation (trois scénarios et variantes),
rattachements au registre, annexes. Usage : python3 -I build_plan.py OUTDIR
Lit OUTDIR/ossature.json, taches.json, o_points.json ; écrit OUTDIR/plan.json et OUTDIR/plan_rapport.txt.
"""
import datetime as dt
import json
import math
import re
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from plan_items_1 import FAMILLES, CHANTIERS, ITEMS          # noqa: E402
from plan_items_2 import ITEMS2                               # noqa: E402
import plan_meta as M                                         # noqa: E402

OUT = sys.argv[1]
OSS = json.load(open(os.path.join(OUT, "ossature.json"), encoding="utf-8"))
T = json.load(open(os.path.join(OUT, "taches.json"), encoding="utf-8"))
O = json.load(open(os.path.join(OUT, "o_points.json"), encoding="utf-8"))

ITEMS_ALL = ITEMS + ITEMS2
IDX = {it["id"]: it for it in ITEMS_ALL}
ORDRE = {it["id"]: i for i, it in enumerate(ITEMS_ALL)}
L0 = dt.date.fromisoformat(M.LUNDI0)
rapport = []


def lundi(w):
    return L0 + dt.timedelta(days=7 * w)


def fmt(w):
    return lundi(w).strftime("%d/%m/%Y")


# ------------------------------------------------------------------ contrôles
err = []
if len(IDX) != len(ITEMS_ALL):
    err.append("identifiants d'items en double")
if set(IDX) != set(OSS["items"]):
    err.append(f"items ≠ ossature : {sorted(set(IDX) ^ set(OSS['items']))}")
for it in ITEMS_ALL:
    if it["id"].split("-")[0] not in CHANTIERS:
        err.append(f"{it['id']} : chantier inconnu")
    for d in it["dep"] + it["tox_dep"]:
        if d not in IDX:
            err.append(f"{it['id']} : dépendance inconnue {d}")
    if not it["sous"]:
        err.append(f"{it['id']} : aucune sous-tâche")
    has_e = any(s[4] == "e" for s in it["sous"])
    if (it["tox"] or it["att"]) and not has_e and it["id"] not in ("JU-2",):
        err.append(f"{it['id']} : attente sans sous-tâche d'envoi")
    if any(s[4] == "a" for s in it["sous"]) and not (it["tox"] or it["att"]):
        err.append(f"{it['id']} : sous-tâche « après » sans attente")
    for s in it["sous"]:
        if s[3] is not None and not (0 <= s[3] <= 3):
            err.append(f"{it['id']} : semaine datée hors horizon {s[3]}")
        for d in (s[5] if len(s) > 5 else []):
            if d not in IDX:
                err.append(f"{it['id']} : dépendance de sous-tâche inconnue {d}")
        if s[2] < 0:
            err.append(f"{it['id']} : heures négatives")
tox_items = {it["id"] for it in ITEMS_ALL if it["tox"]}
env_items = {e[0] for e in M.ENVOIS}
if tox_items != env_items:
    err.append(f"envois ≠ items au toxicologue : {sorted(tox_items ^ env_items)}")
SUBIDS = {f"{it['id']}.{n + 1}" for it in ITEMS_ALL for n in range(len(it["sous"]))}
for v in M.VERROUS:
    for s in v[2]:
        if s not in SUBIDS:
            err.append(f"{v[0]} : sous-tâche inconnue {s}")
for s in M.COCHES_INITIALES:
    if s not in SUBIDS:
        err.append(f"coche initiale inconnue {s}")
for coll in (M.ACTIONS_2010, M.BARRES_2010, M.LOTS_1609, M.PHASES_AVRIL):
    for row in coll:
        for x in row[3]:
            if x not in IDX:
                err.append(f"annexe : item inconnu {x} ({row[0]})")
for j in M.JALONS:
    for x in j[3]:
        if x not in IDX:
            err.append(f"{j[0]} : item inconnu {x}")
etat = {}


def visite(x, pile):
    if etat.get(x) == 1:
        err.append("cycle : " + " → ".join(pile + [x]))
        return
    if etat.get(x) == 2:
        return
    etat[x] = 1
    it = IDX[x]
    deps = set(it["dep"]) | set(it["tox_dep"]) | {d for s in it["sous"] if len(s) > 5 for d in s[5]}
    for d in deps:
        visite(d, pile + [x])
    etat[x] = 2


for x in IDX:
    visite(x, [])
if len(M.BARRES_2010) != 59:
    err.append(f"barres du 20/10 : {len(M.BARRES_2010)} au lieu de 59")
if len(M.ACTIONS_2010) != 21:
    err.append(f"actions du 20/10 : {len(M.ACTIONS_2010)} au lieu de 21")
nlots = sum(1 for r in M.LOTS_1609 if r[0].startswith("PLAN"))
if nlots != 48:
    err.append(f"lots du 16/09 : {nlots} au lieu de 48")
if len(M.PHASES_AVRIL) != 9:
    err.append("phases d'avril ≠ 9")
if err:
    print("ERREURS :\n  " + "\n  ".join(err))
    sys.exit(1)

# ------------------------------------------------------------------ simulation
MULT = {"bas": {"f": 0.75, "m": 0.6, "F": 0.4}, "central": {"f": 1, "m": 1, "F": 1},
        "haut": {"f": 1.4, "m": 1.8, "F": 2.5}}
TOXM = {"bas": 1, "central": 1, "haut": 2}
ATTM = {"bas": 0.75, "central": 1, "haut": 1.5}
RANG = {e[0]: i for i, e in enumerate(M.ENVOIS)}


QUEUE = {x: 0 for x in IDX}   # longueur de la chaîne restante derrière chaque item (semaines), passe 2


def succ_de():
    sc = {x: set() for x in IDX}
    for it in ITEMS_ALL:
        deps = set(it["dep"]) | set(it["tox_dep"]) | {d for s in it["sous"] if len(s) > 5 for d in s[5]}
        for d in deps:
            sc[d].add(it["id"])
    return sc


SUCC = succ_de()


def calcule_queue(S):
    memo = {}

    def q(x):
        if x in memo:
            return memo[x]
        best = 0
        for s in SUCC[x]:
            dur = S[s]["fin"] - min(z["fait"] for z in S[s]["subs"]) + 1
            best = max(best, dur + q(s))
        memo[x] = best
        return best
    return {x: q(x) for x in IDX}


POLITIQUE = os.environ.get("PLAN_POLITIQUE", "A")

# Héritage de priorité (28/10) : un préalable d'un envoi au toxicologue prend la priorité de cet envoi,
# pour que la file du toxicologue ne soit pas affamée par un préalable jugé moins urgent.
PRED = {x: set(IDX[x]["dep"]) | {d for s in IDX[x]["sous"] if len(s) > 5 for d in s[5]} for x in IDX}
PRIO0 = {x: IDX[x]["prio"] for x in IDX}
HERITE = {}
# Testé le 28/10 et non retenu (JALON-02 et publication plus tardifs) : désactivé par défaut.
if os.environ.get("PLAN_HERITAGE", "0") == "1":
    change = True
    while change:              # jusqu'au point fixe (un envoi peut lui-même hériter d'un autre)
        change = False
        for t in IDX:
            if not IDX[t]["tox"]:
                continue
            pile, vus = list(PRED[t]), set()
            while pile:
                p = pile.pop()
                if p in vus or p not in IDX:
                    continue
                vus.add(p)
                if IDX[p]["prio"] > IDX[t]["prio"]:
                    IDX[p]["prio"] = IDX[t]["prio"]
                    HERITE[p] = t
                    change = True
                pile.extend(PRED[p])


def cle(x):
    it = IDX[x]
    if POLITIQUE == "A":      # priorités du planning, puis ordre des items
        return (it["prio"], ORDRE[x])
    if POLITIQUE == "B":      # urgences (priorité 1), puis plus longue chaîne restante
        return (1 if it["prio"] == 1 else 2, -QUEUE[x], it["prio"], ORDRE[x])
    return (it["prio"], -QUEUE[x], ORDRE[x])   # C : priorité, puis plus longue chaîne restante


def simuler(scen, variante=None):
    v = variante or {}
    mult = MULT[scen]
    S = {}
    for it in ITEMS_ALL:
        subs = []
        for n, s in enumerate(it["sous"]):
            h = s[2]
            if s[3] is None:
                h = h * mult[it["inc"]] * v.get("heures", 1)
                if it["dev"]:
                    h *= v.get("code", 1)
            subs.append(dict(id=f"{it['id']}.{n + 1}", h=h, reste=h, sem=s[3], phase=s[4],
                             deps=(s[5] if len(s) > 5 else []), fait=None))
        tox = it["tox"] * TOXM[scen] * v.get("tox", 1)
        att = it["att"]
        if att and scen != "central":
            att = max(1, math.ceil(att * ATTM[scen] - 1e-9))
        if scen == "haut" and it["id"] == "GR-9":
            att = 2   # un second tour (R2) dans le scénario haut
            subs.insert(len(subs) - 1, dict(id="GR-9.r2", h=0.25, reste=0.25, sem=None, phase="e", deps=[], fait=None))
            subs[-1]["h"] += 3
            subs[-1]["reste"] += 3
            subs[-1]["phase"] = "a"
        S[it["id"]] = dict(subs=subs, tox=tox, att=att, envoye=None, ret=None, fin=None,
                           debut_attente=None)
    tox_libre = 0
    CONG = M.TOX_CONGES if scen == "haut" else []   # trêve des fêtes : scénario haut seulement (réponse du 28/10)
    charge = []
    WMAX = 400
    for w in range(WMAX):
        def fini(x):
            return S[x]["fin"] is not None and S[x]["fin"] < w
        te_ok = fini("TE-2")
        dev_ok = te_ok and fini("TE-3")
        apres = v.get("partage", M.CAP_APRES)
        if w == 0:
            cap_p = 0.0
        elif dev_ok:   # le partage projet/code commence quand le code peut commencer (TE-2 et TE-3 finis)
            cap_p = float(apres[0])
        else:
            cap_p = float(M.CAP_PROJET)
        cap_d = float(apres[1]) if dev_ok else 0.0
        used_p = 0.0
        # a. sous-tâches datées
        for x, st in S.items():
            for s in st["subs"]:
                if s["sem"] == w and s["fait"] is None:
                    s["fait"] = w
                    s["reste"] = 0
                    used_p += s["h"]
        # b. envois datés (relance, message) : départ de l'attente
        for x, st in S.items():
            it = IDX[x]
            if st["att"] and not st["tox"] and st["debut_attente"] is None:
                es = [s for s in st["subs"] if s["phase"] == "e"]
                if es and all(s["sem"] is not None and s["fait"] is not None for s in es):
                    we = max(s["fait"] for s in es)
                    st["debut_attente"] = we + 1
                    st["ret"] = max(we + 1 + st["att"], it["retour_min"] or 0)

        def pre_ok(x):
            pres = [s for s in S[x]["subs"] if s["phase"] is None]
            return all(s["fait"] is not None and s["fait"] < w for s in pres)

        def deps_ok(x):
            it = IDX[x]
            return all(fini(d) for d in it["dep"]) and w >= it["debut"]

        # c. file du toxicologue : au plus un envoi par semaine, traitement dans l'ordre d'envoi
        if w >= M.TOX_DEBUT and w not in CONG:
            prets = []
            for x, st in S.items():
                it = IDX[x]
                if not st["tox"] or st["envoye"] is not None:
                    continue
                if not (pre_ok(x) and deps_ok(x)):
                    continue
                if not all(S[d]["ret"] is not None and S[d]["ret"] <= w for d in it["tox_dep"]):
                    continue
                prets.append(x)
            if prets:
                x = min(prets, key=lambda k: RANG[k])
                st = S[x]
                st["envoye"] = w
                for s in st["subs"]:
                    if s["phase"] == "e" and s["fait"] is None:
                        s["fait"] = w
                        s["reste"] = 0
                        used_p += s["h"]
                debut = max(w, tox_libre)
                semaines = 0
                k = debut
                dur = max(1, round(st["tox"]))
                while semaines < dur:
                    if k not in CONG:
                        semaines += 1
                    k += 1
                tox_libre = k
                st["ret"] = k
                st["debut_attente"] = w
        # d. attentes de tiers (hors toxicologue) dont l'envoi n'est pas daté
        for x, st in S.items():
            it = IDX[x]
            if not st["att"] or st["tox"] or st["debut_attente"] is not None:
                continue
            if not (pre_ok(x) and deps_ok(x)):
                continue
            es = [s for s in st["subs"] if s["phase"] == "e" and s["fait"] is None]
            if es or any(s["phase"] == "e" for s in st["subs"]):
                for s in es:
                    s["fait"] = w
                    s["reste"] = 0
                    used_p += s["h"]
                st["debut_attente"] = w + 1
                st["ret"] = max(w + 1 + st["att"], it["retour_min"] or 0)
            else:
                st["debut_attente"] = w
                st["ret"] = max(w + st["att"], it["retour_min"] or 0)

        # e. allocation gloutonne du projet, puis du code
        def alloue(dev, cap, plafonne=True):
            used = 0.0
            cands = sorted((x for x in S if IDX[x]["dev"] == dev), key=cle)
            for x in cands:
                if cap - used <= 1e-9:
                    break
                st = S[x]
                if st["fin"] is not None or not deps_ok(x):
                    continue
                part = 0.0
                plafond = M.CAP_ITEM if (not dev and plafonne) else cap
                for s in st["subs"]:
                    if s["fait"] is not None:
                        continue
                    if s["sem"] is not None:
                        break
                    if s["phase"] == "e":
                        break
                    if s["phase"] == "a" and not (st["ret"] is not None and st["ret"] <= w):
                        break
                    if not all(fini(d) for d in s["deps"]):
                        break
                    dispo = min(cap - used, plafond - part)
                    if dispo <= 1e-9:
                        break
                    q = min(dispo, s["reste"])
                    s["reste"] -= q
                    used += q
                    part += q
                    if s["reste"] <= 1e-9:
                        s["fait"] = w
                    else:
                        break
            return used
        u = alloue(False, max(0.0, cap_p - used_p))
        used_p += u
        if cap_p - used_p > 1e-9:   # reste du temps : on lève le plafond par item plutôt que de le perdre
            used_p += alloue(False, cap_p - used_p, plafonne=False)
        if v.get("vases") and dev_ok:
            cap_d += max(0.0, cap_p - used_p)
        used_d = alloue(True, cap_d)
        charge.append(dict(w=w, projet=round(used_p, 2), code=round(used_d, 2), cap_p=cap_p, cap_d=cap_d))
        # f. fins d'items : toutes les sous-tâches faites et le tiers revenu
        for x, st in S.items():
            if st["fin"] is not None:
                continue
            if any(s["fait"] is None for s in st["subs"]):
                continue
            if (st["tox"] or st["att"]) and (st["ret"] is None or st["ret"] > w + 1):
                continue
            fins = [s["fait"] for s in st["subs"]]
            if st["ret"] is not None:
                fins.append(st["ret"] - 1)
            st["fin"] = max(fins)
        if all(S[x]["fin"] is not None for x in S):
            break
    return S, charge


S1, _ = simuler("central")          # passe 1 : priorités du registre seules
QUEUE.update(calcule_queue(S1))     # passe 2 : on avance ce qui a la plus longue chaîne derrière soi
SC = {}
for scen in ("bas", "central", "haut"):
    S, ch = simuler(scen)
    manq = [x for x in S if S[x]["fin"] is None]
    if manq:
        print(f"scénario {scen} : items non terminés {manq}")
        sys.exit(1)
    SC[scen] = (S, ch)
pub = {k: SC[k][0]["PU-5"]["fin"] for k in SC}
fin_ex2 = {k: SC[k][0]["EX-2"]["fin"] for k in SC}

VARIANTES = [
    ("tox2", "Le toxicologue met deux semaines par envoi au lieu d'une", {"tox": 2}),
    ("heures15", "Tes charges hors code sont de moitié plus longues", {"heures": 1.5}),
    ("code15", "Le code demande moitié plus d'heures", {"code": 1.5}),
    ("code07", "Le code demande 30 % d'heures en moins", {"code": 0.7}),
    ("vases", "Les heures de projet que rien n'occupe passent au code", {"vases": True}),
    ("p12", "Après l'architecture : 12 h de projet et 6 h de code", {"partage": (12, 6)}),
    ("p8", "Après l'architecture : 8 h de projet et 10 h de code", {"partage": (8, 10)}),
]
var_res = []
for key, lib, vv in VARIANTES:
    S, ch = simuler("central", vv)
    var_res.append(dict(id=key, libelle=lib, pub=S["PU-5"]["fin"], delta=S["PU-5"]["fin"] - pub["central"]))

# ------------------------------------------------------------------ chemin déterminant (central)
S0, CH0 = SC["central"]


def chaine(x):
    out = [x]
    while True:
        it = IDX[x]
        deps = set(it["dep"]) | set(it["tox_dep"]) | {d for s in it["sous"] if len(s) > 5 for d in s[5]}
        if not deps:
            return out
        d = max(deps, key=lambda k: S0[k]["fin"])
        out.append(d)
        x = d


chemin = chaine("PU-5")


# ------------------------------------------------------------------ registre : rattachements
def propre(txt, n=260):
    t = re.sub(r"\*\*|`|⚠\s*", "", txt or "")
    t = re.sub(r"\s+", " ", t).strip()
    if len(t) > n:
        t = t[:n].rsplit(" ", 1)[0].rstrip(" ,;:—-") + "…"
    return t


def ref_info(r):
    if r.startswith("O-"):
        o = O.get(r, {})
        note = "fermé sous réserve d'un tiers : à revérifier" if r in OSS.get("verifs", {}) else ""
        return dict(r=r, st=("point fermé sous réserve" if note else "point ouvert"), pe="",
                    o=propre(o.get("objet", "")), note=note)
    t = T[r]
    return dict(r=r, st=t["statut"], pe=propre(t["perim"], 60), o=propre(t["objet"]),
                note=OSS.get("provisoire", {}).get(r, ""))


def tri_ref(r):
    return (0 if r.startswith("T-") else 1, int(r.split("-")[1]))


# ------------------------------------------------------------------ sortie
envoi_de = {e[0]: (e[1], e[2]) for e in M.ENVOIS}
items_out = []
for it in ITEMS_ALL:
    x = it["id"]
    st = {k: SC[k][0][x] for k in SC}
    sous = []
    for n, s in enumerate(it["sous"]):
        sid = f"{x}.{n + 1}"
        sc_c = [z for z in st["central"]["subs"] if z["id"] == sid][0]
        sc_b = [z for z in st["bas"]["subs"] if z["id"] == sid][0]
        sc_h = [z for z in st["haut"]["subs"] if z["id"] == sid][0]
        sous.append(dict(id=sid, t=s[0], qui=s[1], h=s[2], w=(s[2] if it["dev"] else max(s[2], 0.5)),
                         sem=s[3], ph=s[4] or "", dep=(s[5] if len(s) > 5 else []),
                         c=sc_c["fait"], b=sc_b["fait"], hh=sc_h["fait"]))
    sc = st["central"]
    deb = min(s["c"] for s in sous)
    seg = []
    if sc["debut_attente"] is not None:
        seg.append(["tox" if it["tox"] else "tiers", sc["debut_attente"], sc["ret"] - 1])
    refs = [ref_info(r) for r in sorted(OSS["par_item"].get(x, []), key=tri_ref)]
    items_out.append(dict(
        id=x, ch=x.split("-")[0], titre=it["titre"], titre_long=OSS["items"][x], qui=it["qui"],
        quoi=it["quoi"], pourquoi=it["pourquoi"], fini=it["fini"], dep=it["dep"], tox_dep=it["tox_dep"],
        dev=it["dev"], hors_pct=it["hors_pct"], inc=it["inc"],
        envoi=envoi_de.get(x), att=it["att"], tox=it["tox"],
        sous=sous, debut=deb, fin=sc["fin"], fin_bas=st["bas"]["fin"], fin_haut=st["haut"]["fin"],
        envoye=sc["envoye"], ret=sc["ret"], seg=seg, refs=refs,
        h_projet=round(sum(s["h"] for s in sous) if not it["dev"] else 0, 2),
        h_code=round(sum(s["h"] for s in sous) if it["dev"] else 0, 2)))

annexe = []
for r, (a, note) in sorted(OSS["annexe"].items(), key=lambda kv: int(kv[0][2:])):
    t = T[r]
    annexe.append(dict(r=r, cat=a, o=propre(t["objet"]), note=note or OSS["annexe_notes"].get(r, ""),
                       pe=propre(t["perim"], 90)))
scindees = [dict(r=r, pe=propre(p, 220), o=propre(T[r]["objet"], 160), items=OSS["rattach"].get(r, []))
            for r, p in sorted(OSS.get("scindees", {}).items(), key=lambda kv: int(kv[0][2:]))]

envois_out = []
for x, lab, desc in M.ENVOIS:
    envois_out.append(dict(item=x, lab=lab, desc=desc,
                           envoye=SC["central"][0][x]["envoye"], ret=SC["central"][0][x]["ret"],
                           envoye_bas=SC["bas"][0][x]["envoye"], ret_bas=SC["bas"][0][x]["ret"],
                           envoye_haut=SC["haut"][0][x]["envoye"], ret_haut=SC["haut"][0][x]["ret"]))

h_projet = sum(i["h_projet"] for i in items_out if not i["hors_pct"])
h_code = sum(i["h_code"] for i in items_out)
w_total = sum(s["w"] for i in items_out if not i["hors_pct"] for s in i["sous"])
par_ch = {}
for i in items_out:
    if i["hors_pct"]:
        continue
    par_ch.setdefault(i["ch"], [0, 0])
    par_ch[i["ch"]][0] = round(par_ch[i["ch"]][0] + i["h_projet"], 2)
    par_ch[i["ch"]][1] = round(par_ch[i["ch"]][1] + i["h_code"], 2)

plan = dict(
    meta=dict(etat_au=M.ETAT_AU, lundi0=M.LUNDI0, genere=dt.datetime.now().strftime("%d/%m/%Y %H:%M"),
              cap_projet=M.CAP_PROJET, cap_apres=list(M.CAP_APRES), cap_item=M.CAP_ITEM,
              tox_debut=M.TOX_DEBUT, tox_conges=M.TOX_CONGES, registre="v6.7 (22/10/2026)",
              h_projet=round(h_projet, 1), h_code=round(h_code, 1), w_total=round(w_total, 2),
              pub=pub, fin_ex2=fin_ex2, chemin=chemin, par_ch=par_ch,
              n_sous=sum(len(i["sous"]) for i in items_out)),
    familles=[dict(id=f[0], nom=f[1], ch=f[2]) for f in FAMILLES],
    chantiers={k: dict(nom=v[0], desc=v[1]) for k, v in CHANTIERS.items()},
    items=items_out, envois=envois_out,
    verrous=[dict(id=v[0], txt=v[1], leve_par=v[2], items=v[3]) for v in M.VERROUS],
    verrous_maintien=[dict(id=v[0], txt=v[1], items=v[2]) for v in M.VERROUS_MAINTIEN],
    jalons=[dict(id=j[0], nom=j[1], txt=j[2], items=j[3], c=max(SC["central"][0][x]["fin"] for x in j[3]),
                 b=max(SC["bas"][0][x]["fin"] for x in j[3]), hh=max(SC["haut"][0][x]["fin"] for x in j[3]))
            for j in M.JALONS],
    charge=[c for c in CH0 if c["w"] <= fin_ex2["central"] + 1],
    variantes=var_res,
    annexes=dict(hors=annexe, scindees=scindees,
                 actions=[dict(c=a[0], t=a[1], sort=a[2], items=a[3]) for a in M.ACTIONS_2010],
                 barres=[dict(c=b[0], t=b[1], sort=b[2], items=b[3]) for b in M.BARRES_2010],
                 lots=[dict(c=b[0], t=b[1], sort=b[2], items=b[3]) for b in M.LOTS_1609],
                 phases=[dict(c=b[0], t=b[1], sort=b[2], items=b[3]) for b in M.PHASES_AVRIL]),
    coches_initiales={k: dict(le=v[0], source=v[1]) for k, v in M.COCHES_INITIALES.items()},
    questions=M.QUESTIONS_OUVERTES,
)
json.dump(plan, open(os.path.join(OUT, "plan.json"), "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))

# ------------------------------------------------------------------ rapport
R = rapport.append
R(f"Items : {len(items_out)} ; sous-tâches : {plan['meta']['n_sous']}")
R(f"Heures de projet (hors EX-2) : {h_projet:.1f} ; heures de code : {h_code:.1f} ; poids total : {w_total:.1f}")
R("Par chantier (projet/code) : " + ", ".join(f"{k} {v[0]:.1f}/{v[1]:.0f}" for k, v in par_ch.items()))
for k in ("bas", "central", "haut"):
    R(f"Publication {k} : semaine {pub[k]} (lundi {fmt(pub[k])}) ; fin du premier mois : sem. {fin_ex2[k]} ({fmt(fin_ex2[k])})")
R("Variantes (central) : " + " | ".join(f"{v['id']} → sem. {v['pub']} ({fmt(v['pub'])}, {v['delta']:+d})" for v in var_res))
R("Chemin déterminant (central) : " + " ← ".join(f"{x}[{S0[x]['fin']}]" for x in chemin))
R("Envois (central) : " + " | ".join(f"{e['lab']} {e['item']} envoi {e['envoye']} ({fmt(e['envoye'])}) retour {e['ret']}" for e in envois_out))
R("Envois (haut) : " + " | ".join(f"{e['item']} {e['envoye_haut']}→{e['ret_haut']}" for e in envois_out))
R("Jalons : " + " | ".join(f"{j['id']} sem.{j['c']} ({fmt(j['c'])}) [bas {j['b']}, haut {j['hh']}]" for j in plan["jalons"]))
R("Charge semaines 0 à 10 (projet/cap) : " + " ".join(f"{c['w']}:{c['projet']:.1f}/{c['cap_p']:.0f}" for c in CH0[:11]))
over = [c for c in CH0 if c["projet"] > c["cap_p"] + 0.01 and c["w"] > 0]
R("Semaines en surcharge : " + (", ".join(f"{c['w']} ({c['projet']:.1f} h)" for c in over) or "aucune"))
idle = sum(max(0, c["cap_p"] - c["projet"]) for c in CH0 if 0 < c["w"] <= pub["central"])
R(f"Heures de projet inoccupées jusqu'à la publication (central) : {idle:.0f}")
debut_code = min((c["w"] for c in CH0 if c["cap_d"] > 0), default=None)
R(f"Début du code (central) : semaine {debut_code} ({fmt(debut_code) if debut_code is not None else '—'})")
for x in ("GR-3", "GR-9", "GR-11", "AL-8", "TE-2", "TE-3", "TE-4", "TE-5", "TE-6", "CA-7", "CT-4", "GR-12", "AL-10", "MC-5", "JU-2", "PU-4"):
    R(f"  {x} fin central sem.{S0[x]['fin']} ({fmt(S0[x]['fin'])}) ; bas {SC['bas'][0][x]['fin']} ; haut {SC['haut'][0][x]['fin']}")
open(os.path.join(OUT, "plan_rapport.txt"), "w", encoding="utf-8").write("\n".join(rapport) + "\n")
print("\n".join(rapport))
