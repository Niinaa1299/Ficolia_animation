"""Lecture seule du registre v6.7 et de la couverture du 20/10.
Usage : python3 -I parse_reg.py REGISTRE COUVERTURE OUTDIR
Produit des JSON dans OUTDIR : taches.json, o_points.json, couverture.json, ecarts.json
"""
import json
import re
import sys

reg_path, cov_path, outdir = sys.argv[1], sys.argv[2], sys.argv[3]
lines = open(reg_path, encoding="utf-8").read().split("\n")

# --- sections
sec = None
dim = None
taches = {}
o_points = {}
sec8 = []
sec9 = []
for ln in lines:
    if ln.startswith("## "):
        sec = ln[3:].strip()
        continue
    if ln.startswith("### ") and sec and sec.startswith("1. Tâches"):
        dim = re.sub(r"\s+—\s+\d+\s+tâches?$", "", ln[4:].strip())
        continue
    if sec and sec.startswith("1. Tâches") and ln.startswith("| **T-"):
        cells = [c.strip() for c in ln.strip().strip("|").split(" | ")]
        ref = re.match(r"\*\*(T-\d+)\*\*", cells[0]).group(1)
        statut, dec, mention, perim = cells[-4], cells[-3], cells[-2], cells[-1]
        objet = " | ".join(cells[1:-4])
        taches[ref] = dict(ref=ref, dim=dim, objet=objet, statut=statut,
                           dec=dec, mention=mention, perim=perim)
    if sec and sec.startswith("5. Points ouverts") and ln.startswith("| **O-"):
        cells = [c.strip() for c in ln.strip().strip("|").split(" | ")]
        ref = re.match(r"\*\*(O-\d+)\*\*", cells[0]).group(1)
        objet = " | ".join(cells[1:])
        ferme = bool(re.match(r"⚠\s*\*\*(Refermé|Fermé|Fermée|Refermée|Close|Clos)", objet))
        o_points[ref] = dict(ref=ref, objet=objet, ferme=ferme)
    if sec and sec.startswith("8. Tâches sans statut") and ln.startswith("| **T-"):
        cells = [c.strip() for c in ln.strip().strip("|").split(" | ")]
        ref = re.match(r"\*\*(T-\d+)\*\*", cells[0]).group(1)
        sec8.append(dict(ref=ref, cells=cells))
    if sec and sec.startswith("9. Liste de publication") and ln.startswith("- **"):
        for m in re.finditer(r"`(T-\d+)`", ln):
            sec9.append(m.group(1))

# --- couverture
cov = {}
csec = None
for ln in open(cov_path, encoding="utf-8").read().split("\n"):
    if ln.startswith("## "):
        csec = ln[3:].strip()
        continue
    m = re.match(r"\|\s*((?:T|O)-\d+)\s*\|", ln)
    if m:
        cells = [c.strip() for c in ln.strip().strip("|").split(" | ")]
        cov.setdefault(m.group(1), []).append(dict(section=csec, cells=cells))

# --- écarts
plancher_ouv = {r for r, t in taches.items()
                if t["statut"] in ("Ouverte", "Proposition", "Suspendue")
                and t["perim"].startswith("plancher")}
sec9s = set(sec9)
ecarts = dict(
    n_taches=len(taches),
    n_sec9=len(sec9), n_sec9_uniques=len(sec9s),
    plancher_ouv_hors_sec9=sorted(plancher_ouv - sec9s, key=lambda r: int(r[2:])),
    sec9_hors_plancher_ouv=sorted(sec9s - plancher_ouv, key=lambda r: int(r[2:])),
    sec9_non_couverts=sorted([r for r in sec9s if r not in cov], key=lambda r: int(r[2:])),
    couverts_plancher_plus_au_sec9=sorted(
        [r for r, v in cov.items() if r.startswith("T-")
         and any("plancher" in (x["section"] or "").lower() and "arbitrer" not in (x["section"] or "").lower() for x in v)
         and r not in sec9s], key=lambda r: int(r[2:])),
    sec8_refs=[x["ref"] for x in sec8],
    o_ouverts=[r for r, o in o_points.items() if not o["ferme"]],
    o_fermes=[r for r, o in o_points.items() if o["ferme"]],
)
json.dump(taches, open(outdir + "/taches.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
json.dump(o_points, open(outdir + "/o_points.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
json.dump(cov, open(outdir + "/couverture.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
json.dump(dict(ecarts=ecarts, sec8=sec8), open(outdir + "/ecarts.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

from collections import Counter
print("tâches lues :", len(taches))
print("statuts :", Counter(t["statut"] for t in taches.values()).most_common())
print("§9 :", len(sec9), "uniques", len(sec9s))
print("plancher ouvert (statut ouvert/proposition/suspendue, périmètre commençant par plancher) :", len(plancher_ouv))
print("décideurs plancher §9 :", Counter(taches[r]["dec"] for r in sec9s if r in taches).most_common())
for k in ("plancher_ouv_hors_sec9", "sec9_hors_plancher_ouv", "sec9_non_couverts", "couverts_plancher_plus_au_sec9"):
    print(k, len(ecarts[k]), ecarts[k])
print("§8 :", len(sec8))
print("O ouverts :", len(ecarts["o_ouverts"]), ecarts["o_ouverts"])
print("O fermés :", len(ecarts["o_fermes"]), ecarts["o_fermes"])
