# Données du planning Ficolia — partie 1 : familles, chantiers ; PI, GR, AL.
# Sous-tâche : (texte, qui, heures de la porteuse, semaine datée 0..3 ou None, phase[, dépendances])
#   heures = ton temps, séances avec Claude comprises (une tâche de Claude compte le temps de la lancer
#            et de la relire avec lui) ; phase None = avant ; "e" = au moment de l'envoi ou de la demande
#            à un tiers ; "a" = après le retour du tiers ; dépendances propres à la sous-tâche (items).
# Semaine 0 = lundi 26/10/2026. RÈGLE DE STABILITÉ : après publication, ne jamais réordonner ni
# supprimer une sous-tâche (l'identifiant « item.n » porte les coches) ; ajouter en fin de liste.

FAMILLES = [
    ("methode", "Méthode scientifique", ["GR", "AL", "MC", "RF"]),
    ("contenus", "Contenus", ["CT"]),
    ("donnees", "Données produits", ["CA"]),
    ("prototype", "Prototype et tests", ["PR"]),
    ("code", "Code", ["TE"]),
    ("juridique", "Juridique", ["JU"]),
    ("lancement", "Lancement", ["MK", "PU", "EX"]),
    ("pilotage", "Pilotage", ["PI"]),
]

CHANTIERS = {
    "PI": ("Pilotage", "Tenir une seule source, le registre, le planning et les arbitrages d'ensemble, jusqu'à la consolidation finale avant la décision de lancement."),
    "GR": ("Ligne grossesse", "Fixer les règles de la note grossesse, valider le prompt à l'aveugle sur R1, produire les notes, puis calibrer contre l'étalon d'août et le complément. Lève VERROU-12. Porte aussi le module huiles essentielles (GR-14), commun aux deux lignes."),
    "AL": ("Ligne allaitement", "Faire juger l'étalon allaitement en deux tranches, faire noter NB_nourrisson à la main, valider le prompt allaitement, poser ②-A, puis calibrer. Lève VERROU-1 et VERROU-3."),
    "MC": ("Modèle de calcul et exposition", "Exécuter la table des paramètres, auditer l'exposition, tenir les catégories et attributs, construire le moteur de référence et ses cas de test, puis figer le modèle avec ses paramètres hors du code."),
    "RF": ("Référentiel et criblage", "Figer les jeux de données officiels, compter les statuts réglementaires des 1 318 ingrédients, faire le criblage complet (VERROU-2) et organiser la veille."),
    "CT": ("Contenus et textes", "Écrire les phrases sous le verdict par cause, les textes « ce qui est en cause », la méthodologie finale et les textes publics, avec leurs règles de rédaction."),
    "CA": ("Catalogue et données produits", "Mesurer sans tiers, choisir comment alimenter la base, collecter, arbitrer le catalogue et le constituer au seuil de couverture."),
    "PR": ("Prototype et tests", "Choisir le canevas de référence, finir les étapes 5 à 8 du prototype, tester hors cible puis avec la cible, et essayer la version candidate."),
    "TE": ("Technique et développement", "Écrire l'architecture technique, la soumettre à un avis extérieur, planifier puis construire la base, le back-office et l'application Android, intégrer le modèle figé et passer la revue de sécurité."),
    "JU": ("Juridique, structure, assurance", "Obtenir et intégrer les réponses de la juriste, déposer la marque, créer la structure éditrice, souscrire l'assurance, signer l'accord avec le toxicologue, tenir le RGPD et faire relire les textes publics."),
    "MK": ("Marketing", "Cadrer le marketing après la réponse de la juriste à la question 7.2 : réseaux sociaux d'abord, maternités et presse ensuite, sans influenceuses au début (ta réponse du 27/10)."),
    "PU": ("Publication et stores", "Relever les politiques santé des stores, ouvrir le compte de publication, préparer les déclarations, décider du lancement et soumettre l'application Android."),
    "EX": ("Exploitation", "Préparer le support, la continuité et la charge d'exploitation avant la publication ; suivre le premier mois après."),
}

ITEMS = []


def I(id, titre, qui, quoi, pourquoi, fini, sous, dep=(), tox_dep=(), tox=0, att=0, retour_min=None,
      dev=False, inc="m", prio=5, debut=1, hors_pct=False):
    ITEMS.append(dict(id=id, titre=titre, qui=qui, quoi=quoi, pourquoi=pourquoi, fini=fini,
                      sous=list(sous), dep=list(dep), tox_dep=list(tox_dep), tox=tox, att=att,
                      retour_min=retour_min, dev=dev, inc=inc, prio=prio, debut=debut, hors_pct=hors_pct))


# ======================================================================= PI
I("PI-1", "Source unique", "toi",
  "Un seul endroit fait foi pour le registre, le planning, les coches, le canevas et les données produits.",
  "Ta réponse du 27/10 : « tout ce qui est sur ce compte fait foi ». Deux précisions restent : si l'autre projet (celui de la session du 24 au 27/10, 77 documents) est aussi sur ce compte, il faut nommer le projet qui fait foi, puisque D-293 veut un seul registre au projet ; et le travail fait ailleurs (session du 24 au 27/10 ; extraction de la collecte du 25/10, sur un autre compte) ne compte qu'une fois rapatrié ici.",
  "Ce compte et ce projet font foi ; ce qui a été produit ailleurs est rapatrié et inscrit ; le canevas de référence est choisi (PR-1).",
  [("Désigner le compte qui fait foi : celui-ci (27/10)", "toi", 0.5, 0, None),
   ("Confirmer que ce projet, celui du registre v6.7 et du dossier juriste v3-2, fait foi (recommandé), si l'autre projet est sur ce compte", "toi", 0.25, 0, None),
   ("Rapatrier ici la matière de la session du 24 au 27/10 (fichier de ton Drive), pour la v6.8", "Claude", 0.5, 1, None),
   ("Rapatrier ici le fichier de l'extraction de la collecte du 25/10, dès qu'elle est finie", "toi", 0.5, None, None),
   ("Ne plus tenir de registre ni de planning ailleurs ; y renvoyer vers ce projet", "toi", 0.5, None, None)],
  prio=1, inc="f")

I("PI-2", "Planning et rappel", "Claude, toi",
  "La page du planning, ses coches, la commande « point » et la ligne d'instructions du projet.",
  "Tes réponses du 27/10 : rappel par une ligne d'instructions et une commande « point », sans tâche planifiée ; page interactive où tu coches toi-même ; planning mis à jour à chaque génération du registre.",
  "La page est publiée, la commande « point » enregistrée, la ligne ajoutée aux instructions ; chaque génération du registre met le planning à jour.",
  [("Valider l'ossature (réponses du 27/10)", "toi", 0.5, 0, None),
   ("Publier la page du planning, relue deux fois", "Claude", 0.5, 0, None),
   ("Enregistrer la commande « point » proposée", "toi", 0.25, 0, None),
   ("Ajouter la ligne de rappel aux instructions du projet", "toi", 0.25, 0, None),
   ("Mettre le planning à jour avec la v6.8", "Claude", 0.5, 1, None),
   ("Recalculer les dates avec la cadence mesurée sur la tranche 1 (T-236)", "Claude", 0.5, None, None, ["AL-4"])],
  prio=1, inc="f", debut=0)

I("PI-3", "Registre v6.8", "Claude, toi",
  "Générer la v6.8 du registre avec la matière accumulée depuis le 22/10.",
  "Le registre fait foi sur chaque statut. La matière de H8 à H12 (fichier de travail du bloc H, séances du 22 au 28/10) et celle de la session du 24 au 27/10 n'y sont pas encore. S'y ajoutent tes réponses du 27/10 qui modifient le registre : l'ordre des envois (modifie D-251), la transcription complète de la collecte (modifie la règle de T-597). D-293 : un seul registre au projet. Le projet est plein (1 998 197 sur 2 000 000 le 28/10) : la v6.8, plus longue que la v6.7, n'entre qu'après un ménage (PI-7).",
  "La v6.8 est déposée après deux relectures et le contrôle de non-perte ; la v6.7 est retirée.",
  [("Trancher la date de l'appel : jeudi 22/10 au soir (27/10)", "toi", 0.25, 0, None),
   ("Valider les propositions marquées pour la v6.8 (typologies des corrections, décisions, annotations)", "toi", 1.5, 1, None),
   ("Décider si la décision de séance 86 du 07/10 (contribution photo au plancher) s'inscrit dès la v6.8, par exception à D-223, parce que l'architecture (TE-2) en dépend", "toi", 0.25, 1, None),
   ("Inscrire H8 à H12, la session du 24 au 27/10 (sans T-612, dont la prémisse est fausse), tes réponses du 27/10 (ordre des envois, collecte) et le planning", "Claude", 1, 1, None),
   ("Deux relectures, contrôle de non-perte v6.7 → v6.8, dépôt, retrait de la v6.7 (D-293)", "Claude", 1, 1, None, ["PI-7"])],
  prio=1, inc="f", debut=0)

I("PI-4", "T-521 et jalons", "toi",
  "Trancher T-521, puis poser les jalons une fois la cadence du toxicologue mesurée.",
  "T-521 : réconcilier la « nouvelle vision » du 16/09 avec le registre — « bêta fermée autorisée » (JALON-04) contre « pas de bêta fermée » (dimension 9) ; « un petit catalogue fiable » contre D-102. Le compte personnel Google Play impose aussi un test fermé (12 testeurs pendant 14 jours). T-236 : pas de jalon daté avant la cadence du toxicologue mesurée sur la tranche 1. T-508 : forme des tests avec des testeuses.",
  "T-521 tranché et inscrit ; forme des tests fixée ; jalons datés après la cadence mesurée.",
  [("Préparer T-521 : options, conséquences sur le périmètre et l'effort", "Claude", 0.5, 1, None),
   ("Lire les trois fichiers du 16/09 jamais ouverts (T-522) pour ce qui touche au périmètre", "Claude", 0.5, 1, None),
   ("Trancher T-521 en séance", "toi", 2, 2, None),
   ("Fixer la forme des tests avec des testeuses (T-508)", "toi", 0.5, None, None),
   ("Dater les jalons après la cadence de la tranche 1 (T-236)", "toi", 1.5, None, None, ["AL-4"])],
  prio=2, inc="m")

I("PI-5", "Arbitrage final", "toi",
  "Trancher par thème les sujets « à arbitrer » qui ne sont pas tranchés plus tôt dans un autre item.",
  "D-87 : les sujets restants se tranchent par thème, jamais en bloc. Le registre v6.7 en compte 64, plus T-328 non statuée. Chaque thème vient avec une estimation d'effort, car accepter toutes les propositions « plancher » porterait le plancher de 272 à près de 300 tâches (H5, 22/10).",
  "Chaque sujet « à arbitrer » est tranché avec son effort, ou rattaché à l'item qui le tranche.",
  [("Thème science et prompts : ce que le toxicologue n'a pas réglé", "toi", 2, None, None),
   ("Thème catalogue et données (avec CA-6)", "toi", 1.5, None, None),
   ("Thème contenu (avec CT-3), avant la rédaction des textes", "toi", 2, None, None),
   ("Thème juridique (avec JU-2)", "toi", 1.5, None, None),
   ("Sujets restants (T-579, O-36 et autres), puis inscription au registre", "toi", 2, None, None)],
  dep=["PI-4", "JU-2", "CA-6"], prio=4, inc="m")

I("PI-6", "Budget et financement", "toi",
  "Chiffrer les coûts, fixer un plafond et écrire combien de temps le projet tient sans recette.",
  "T-147 : le financement du rafraîchissement des données est un paramètre de sécurité, non un sujet commercial. T-165 : plafond de dépense avec alerte. T-167 : horizon sans recette. D-19 et D-45 (rappelés par la nouvelle vision du 16/09) : pas de péage sur le verdict, pas d'affiliation, pas d'argent des marques. Les devis viennent de l'avis technique (TE-1).",
  "Coûts chiffrés (hébergement, revue de sécurité, juriste, assurance, structure), plafond fixé, horizon écrit, financement établi ou manque écrit.",
  [("Recueillir les ordres de grandeur : hébergement, assurance, comptes (T-166, T-148)", "toi", 2, None, None),
   ("Chiffrer la revue de sécurité (T-514) et les autres devis", "toi", 2, None, None),
   ("Écrire le plafond de dépense et le comportement en cas de dépassement (T-165)", "toi", 2, None, None),
   ("Écrire l'horizon sans recette et le financement du rafraîchissement (T-167, T-147)", "toi", 2, None, None),
   ("Voie de pérennité (O-15) : décider ou écrire en limite", "toi", 2, None, None)],
  dep=["TE-1"], prio=3, inc="F")

I("PI-7", "Hygiène documentaire", "Claude, toi",
  "Garder le projet lisible et lui rendre de la place : fichiers caducs, doublons, documents aux libellés périmés.",
  "Le projet était plein le 28/10 au matin (1 998 197 sur 2 000 000). Tu as retiré neuf doublons le 28/10 : un exemplaire de `_migration_Dim1.md`, `_migration_Dim4.md`, `_migration_Dim6.md`, `_migration_C71_C74.md` et `mamaCARE_Note_Passation_11_09_2026.md` (listés deux fois, 16 et 17/09) ; les versions .docx de `mamaCARE_Dimension12_Exploitation`, `mamaCARE_Note_Passation_04_09_2026` (VF.docx) et `mamaCARE_Perimetre_MVP` (.md.docx), les .md restant ; `build_v65.py`. Aucun renvoi du registre v6.7 ne vise ces fichiers sous ces noms (contrôle du 28/10). Le projet est ensuite à 93,6 %, dossier v0.1 déposé. Restent des documents aux éléments caducs : libellés de verdict d'avant D-103 ; fiche de séance du 21/10 (« une IA produit les notes depuis le 29/09 », contraire à C-251) ; fichiers cités qui n'existent pas (T-427). « Le » ou « la » toxicologue : sans importance, on ne corrige pas (ta réponse du 28/10).",
  "La place nécessaire est libérée ; chaque document caduc est retiré, corrigé ou marqué.",
  [("Proposer la liste des documents à retirer, avec leurs renvois dans le registre (méthode de H9)", "Claude", 0.5, 0, None),
   ("Décider des retraits ; garder une copie locale de chaque retrait", "toi", 0.5, 0, None),
   ("Décider du sort de la note du 21/10 et des deux documents d'été adressés à la juriste (19/08, 15/07)", "toi", 0.5, 3, None),
   ("Fiche de séance du 21/10 : corriger le fait de C-251 (« le » ou « la » toxicologue : on ne corrige pas, 28/10)", "Claude", 0.5, None, None),
   ("Marquer les libellés caducs de l'architecture scientifique et du périmètre MVP (D-103)", "Claude", 0.5, None, None),
   ("Fichiers caducs et fantômes : T-427, T-496, T-583 ; doublons apparents de la liste du projet", "Claude", 1, None, None),
   ("Corrections documentaires : plancher gradué (T-575), « dernier cinquième » (T-578), correspondance NB ↔ MoS (T-291), identifiants de la collecte (T-580)", "Claude", 1.5, None, None)],
  prio=1, inc="f", debut=0)

I("PI-8", "Consolidation finale", "Claude",
  "Régénérer en une passe le registre et les documents avant la décision de lancement.",
  "La note du 26/09 (§6 D) et D-223 prévoient une régénération d'ensemble. O-18 : aucune décision de retrait n'est enregistrée pour les pistes écartées (T-327, T-586).",
  "Registre et documents régénérés, cohérents entre eux ; pistes écartées numérotées et motivées.",
  [("Numéroter les options écartées du volet allaitement (T-586) et consigner les retraits (T-327, O-18)", "Claude", 2, None, None),
   ("Réconcilier les tables d'interfaces et les dimensions (T-364, T-425)", "Claude", 2, None, None),
   ("Régénérer le registre et les documents de dimension en une passe", "Claude", 3, None, None),
   ("Relire et valider la régénération", "toi", 3, None, None)],
  dep=["PI-5", "GR-12", "AL-10", "CT-5", "PR-3"], prio=4, inc="m")

# ======================================================================= GR
I("GR-1", "Dossier des règles", "toi, Claude",
  "Le dossier des règles de la note grossesse, chaque règle avec son statut et sa source.",
  "Protocole du 26/10 (étape 1) : le prompt se corrige d'après le seul dossier des règles. La version 0.1 (28/10) intègre la revue critique du 28/10 (trois contre-sens corrigés, dont D4 à 4) ; tu l'as acceptée le 28/10 comme base de travail, non validée par le toxicologue (T-534). Son dépôt au projet a échoué : projet plein. T-531 : toute source secondaire est vérifiée à la source primaire avant usage.",
  "Dossier accepté, déposé et tenu à jour ; les faits restants vérifiés à la source primaire ; le drapeau « moins de 5 ans » défini.",
  [("Accepter le dossier des règles (v0.1, 28/10)", "toi", 1, 0, None),
   ("Trancher l'exception à D-44 pour H350 et H351 (27/10), étendue à H340 et H341 (28/10)", "toi", 0.25, 0, None),
   ("Déposer le dossier v0.1 au projet, après le ménage", "Claude", 0.25, 1, None, ["PI-7"]),
   ("Vérifier à la source primaire (T-531) : base REACH de la restriction de D5 et D6, avis du SCCS sur les sels d'aluminium, date d'application de l'interdiction du lilial, règlement 2026/909 (citral)", "Claude", 1, 1, None),
   ("Lire pour Claude ce que ses outils ne lisent pas (EUR-Lex, CosIng, ECHA CHEM)", "toi", 0.5, 1, None),
   ("Définir le drapeau « moins de 5 ans de marché » (aucune date de mise sur le marché dans nos sources)", "Claude", 0.5, None, None),
   ("Tenir le dossier à jour à chaque réponse du toxicologue", "Claude", 0.5, None, None, ["GR-2"])],
  prio=1, inc="f", debut=0)

I("GR-2", "Message 21 à 32", "toi",
  "Transmettre au toxicologue les points 21, 22, 25 et 26 et les questions 27 à 32.",
  "Points 21 (« insufficient data ») et 22 (silice nano en forme inhalable), non adoptés le 27/10 : d'ici sa réponse, sa règle écrite s'applique. Demandes 25 (grille corrigée limitée aux lignes déjà notées) et 26 (un envoi par semaine dès le 23/11 ; complément grossesse annoncé). Questions 27 à 32 (28/10, déposées) : annexe III sans lien avec la grossesse, dérogation H340 et H350, libérateurs de formaldéhyde, motif nano, classifications générales et H317, cyclométhicone. Il reprend le 23/11.",
  "Message parti ; réponses et grille corrigée inscrites au dossier des règles.",
  [("Rédiger les questions 27 à 32 (28/10)", "Claude", 0.5, 0, None),
   ("Vérifier à la source la conclusion de l'avis SCCS/1545/15 sur la silice (§4, illisible pour Claude)", "toi", 0.5, 0, None),
   ("Envoyer le message (proposé le 27/10) avec les questions 27 à 32", "toi", 0.5, 0, "e"),
   ("Inscrire ses réponses et sa grille corrigée au dossier des règles", "Claude", 0.5, None, "a")],
  att=1, retour_min=5, prio=1, inc="f", debut=0)

I("GR-3", "Tirer et sceller R1 et R2", "Claude, toi",
  "Tirer les deux jeux réservés de la validation du prompt grossesse et les sceller.",
  "Protocole du 26/10 (étape 2) : R1 (validation) et R2 (second essai), parmi les lignes jamais notées ; partie enrichie par branche de règle, partie aléatoire ; au moins 15 items que l'expert note 2 ou plus, idéalement 29. Prévu la semaine du 26/10 (H10 ter), décalé d'une semaine : à inscrire. Préalables : ton accord sur le dossier (28/10) ; un gel propre à R1 puis une nouvelle graine (H12) ; les fichiers officiels (reçus le 28/10). Limite non tranchée : l'inventaire de CosIng est indisponible et les classifications des dossiers REACH n'ont pas de source (branche de l'arbitrage 20).",
  "Règles du tirage écrites et gelées ; R1 et R2 tirés, scellés (empreintes SHA-256), consignés.",
  [("Trancher la limite des sources pour R1 : l'accepter (proposition du 28/10) ou chercher une source REACH", "toi", 0.5, 0, None),
   ("Écrire et geler les règles du tirage (vivier, branches, part aléatoire, puissance) ; empreintes", "Claude", 0.5, 0, None),
   ("Fournir une nouvelle graine après le gel", "toi", 0.1, 1, None),
   ("Tirer, sceller, envoyer les empreintes par courriel", "Claude", 0.5, 1, None),
   ("Relire le tirage", "toi", 1, 1, None)],
  prio=1, inc="f", debut=0)

I("GR-4", "Pré-enregistrer la validation", "Claude, toi",
  "Écrire et sceller le pré-enregistrement de la validation du prompt grossesse.",
  "Protocole du 26/10 : critère principal à tolérance zéro (sous-notation quand l'expert met 2 ou plus, 4 manqué, abstention ou instabilité, fait décisif faux), critères secondaires, règles de décision (succès, R2, notes à la main, non concluant). Il fonde la condition 1 de VERROU-12 (D-290). Livrable annoncé avant rédaction (D-292).",
  "Pré-enregistrement écrit, relu deux fois, scellé avant l'envoi de R1.",
  [("Rédiger le pré-enregistrement", "Claude", 0.5, 2, None),
   ("Le relire et le valider", "toi", 1.5, 2, None),
   ("Le sceller (empreinte au registre et par courriel)", "Claude", 0.25, 3, None)],
  dep=["GR-1", "GR-3"], prio=1, inc="f", debut=2)

I("GR-5", "Envoi de R1", "toxicologue",
  "Le toxicologue note R1 à l'aveugle, sans IA, avant toute sortie du prompt.",
  "Protocole du 26/10 (étape 3) : R1 envoyé sans proposition de note, avec environ 6 lignes déjà notées pour mesurer sa stabilité ; consignes : aucune IA (attestation écrite), une note de base, règle appliquée ou « hors règle » motivé, source pour toute note de 2 ou plus. Compte rendu de l'appel : « une quarantaine d'ingrédients ». Envoi 3 de l'ordre accepté le 27/10 ; il part après les réponses sur la grille (envoi 2), pour que ses règles soient fixées.",
  "R1 noté et rendu ; empreinte envoyée ; fichier rangé hors du projet, du Drive et de la mémoire.",
  [("Préparer l'envoi de R1 avec ses consignes", "Claude", 0.5, 3, None),
   ("Envoyer R1 (envoi 3, au plus tôt le 07/12)", "toi", 0.25, None, "e"),
   ("À réception : empreinte par courriel, rangement hors du projet", "toi", 0.25, None, "a")],
  dep=["GR-4", "GR-6"], tox_dep=["GR-7"], tox=1, prio=1, inc="m", debut=4)

I("GR-6", "Envoi sur la grille", "Claude, toi",
  "Une quinzaine de questions fermées sur sa grille de notes, parties avec ②-G (envoi 2).",
  "H10 et H10 ter : lignes vides prioritaires, variantes d'écriture, notes conditionnées (à traiter par la note unique), notes sans critère écrit, justifications contraires, lavande, maille INCI ou famille (T-281) ; aucune note proposée pour les lignes vides ; après le scellement de R1, pour ne pas en brûler les candidats. Format de D-254 : question fermée, rappel de sa réponse, proposition.",
  "Questions rédigées, relues et parties avec l'envoi 2.",
  [("Rédiger les questions (D-254)", "Claude", 0.5, 2, None),
   ("Note rectificative à la grille (T-311) et maille des parabènes (T-352)", "Claude", 0.5, 2, None),
   ("Les relire", "toi", 1, 3, None)],
  dep=["GR-3"], prio=1, inc="f", debut=2)

I("GR-7", "②-G réduit", "Claude, toxicologue",
  "Dépouiller les sources non lues, puis poser au toxicologue ce qui reste ouvert sur le danger et les sources.",
  "D-252 : ②-G « danger et sources », avant l'étalon (D-250). T-525 : dépouiller `Quid_Tox.pdf` et le brief 2B d'abord (« ne pas reposer une question à laquelle il a déjà répondu »). Brief « compléments » parti le 14/08 et répondu ; sa réponse a été jointe dans la discussion « Préparation meeting toxicologue », pour R1 (ta réponse du 28/10). Reste, au 26/10 : épidémiologie (E1), algues (E2), huiles essentielles (F1, F2), chlorhexidine (H1, T-310), péremption (H4, T-242), rétinol (J1, J2), formule d'interface (J4), statut après la publication (T-15) ; information sur le « dernier cinquième » (T-556). Avec les questions sur la grille, l'envoi 2 compte environ 30 questions (revue du 28/10) : un envoi ou deux.",
  "T-525 fait ; ②-G parti avec l'envoi 2 et répondu ; réponses inscrites.",
  [("Dire si le brief « compléments » de fin août est parti", "toi", 0.1, 0, None),
   ("Dépouiller `Quid_Tox.pdf`, le brief 2B et la réponse au brief « compléments » du 14/08 côté grossesse (T-525)", "Claude", 1, 2, None),
   ("Rédiger ②-G réduit (T-600)", "Claude", 1, 2, None),
   ("Relire ②-G et l'envoi 2 ; décider un envoi d'environ 30 questions ou deux", "toi", 1.5, 3, None),
   ("Envoyer l'envoi 2 : questions sur la grille (GR-6) et ②-G réduit", "toi", 0.25, None, "e"),
   ("Inscrire ses réponses ; mettre à jour le dossier des règles", "Claude", 1.15, None, "a")],
  dep=["GR-6"], tox=1, prio=1, inc="m", debut=2)

I("GR-8", "Corriger et figer le prompt", "Claude, toi",
  "Corriger le prompt grossesse d'après le seul dossier des règles, puis le figer.",
  "Protocole du 26/10 (étape 4) : correction dans une session vierge ; configuration figée (modèle, réglages, outils, de préférence sans web en direct) ; sources fournies aux passages précisées, l'inventaire de CosIng étant indisponible (H12) ; trois exécutions, la note la plus haute retenue ; gel des empreintes. T-571 : reproductibilité. Interdit : corriger d'après les notes de sa grille ; montrer une sortie du prompt avant que R1 soit noté et scellé.",
  "Prompt corrigé, configuration figée, empreintes gelées, aucune sortie montrée au toxicologue.",
  [("Corriger le prompt en session vierge, chaque correction citant sa règle", "Claude", 1, None, None),
   ("Faire consigner par le prompt la base de chaque note, dont l'origine de chaque NB 1 (signal ou absence de données)", "Claude", 0.5, None, None),
   ("Figer la configuration (modèle, réglages, outils, sources fournies) et la consigner", "Claude", 0.5, None, None),
   ("Essai technique hors des jeux ; gel des empreintes", "Claude", 1, None, None),
   ("Relire et valider", "toi", 1.5, None, None)],
  dep=["GR-1", "GR-2", "GR-7"], prio=2, inc="m")

I("GR-9", "Valider sur R1", "Claude, toi",
  "Comparer le prompt figé aux notes du toxicologue sur R1, selon le pré-enregistrement.",
  "VERROU-12 (D-290), condition 1 : validation à l'aveugle du prompt grossesse. Puissance : au moins 15 items notés 2 ou plus par l'expert (H10 ter). Échec : cause, correction, R2 ; second échec : il note à la main les familles en cause ; plus d'un tiers de ses notes de 2 ou plus « hors règle » : non concluant.",
  "Décision écrite : succès pour cette version, ou correction et R2.",
  [("Exécuter le prompt figé sur R1 et comparer selon le pré-enregistrement", "Claude", 0.5, None, None),
   ("Rédiger le résultat et la décision", "Claude", 0.5, None, None),
   ("Valider la décision ; en cas d'échec, lancer la correction et R2", "toi", 1, None, None)],
  dep=["GR-5", "GR-8"], prio=1, inc="F")

I("GR-10", "NB_grossesse sur le référentiel", "Claude, toi, toxicologue",
  "Produire les notes grossesse des 1 318 ingrédients avec le prompt validé.",
  "D-222 et T-571 : notes versionnées, origine tracée (version, modèle, réglages, date). T-23 et T-570 : relecture par tirage au hasard, en plus des cas douteux. T-289 : la liste noire transmise devient une file d'attribution prioritaire.",
  "Notes produites, versionnées, origine tracée ; échantillon relu par le toxicologue.",
  [("Exécuter le prompt validé sur le référentiel, trois exécutions, note la plus haute", "Claude", 1, None, None),
   ("Tracer l'origine de chaque note ; report des notes déjà attribuées (T-284)", "Claude", 1, None, None),
   ("Tirer l'échantillon de relecture", "Claude", 0.75, None, None),
   ("Envoyer l'échantillon au toxicologue", "toi", 0.25, None, "e"),
   ("Relire les écarts et valider", "toi", 3, None, "a")],
  dep=["GR-9"], tox=1, prio=2, inc="m")

I("GR-11", "Complément grossesse", "Claude, toi, toxicologue",
  "Constituer, pré-enregistrer et faire juger à l'aveugle le complément de l'étalon grossesse.",
  "D-285 : strates anti-vergetures, non-rincés ordinaires, solaires corps, rincés neufs ; enrichi sur le risque de sous-évaluation ; pont de 6 à 8 produits d'août ; taille fixée après la cadence de la tranche 1 ; jugé avant ②-A (D-250). D-290 (3) : le critère n°1 doit être éprouvé sur au moins 15 produits que l'expert juge orange ou rouges ; l'étalon d'août en a 10 (4 orange, 6 rouges) : le complément doit en apporter au moins 5. D-292 : premier temps du pré-enregistrement scellé avant l'envoi, avec l'origine des notes (prompt validé) ; l'addendum du second temps est purement mécanique, donc O-59 se tranche ici. Candidats : les premiers produits encore libres de l'ordre tiré le 28/10 ; produits de la collecte : tirage séparé.",
  "Complément constitué (T-607), O-59 tranché ou écrit en limite, pré-enregistrement scellé (T-608, premier temps), complément jugé et rendu.",
  [("Fixer la taille d'après la cadence de la tranche 1", "toi", 0.5, None, None),
   ("Listes de candidats par strate (ordre du 28/10 ; collecte en tirage séparé), enrichissement visant au moins 5 produits orange ou rouges de plus, fiches anonymisées, consigne", "Claude", 1.5, None, None),
   ("Trancher O-59 (invariant n°2 grossesse : un standard de soin jamais orange ou rouge ?) ou l'écrire en limite", "toi", 1, None, None),
   ("Rédiger le premier temps du pré-enregistrement (T-608)", "Claude", 1, None, None),
   ("Relire et valider le complément et le pré-enregistrement", "toi", 2, None, None),
   ("Envoyer le complément (envoi 5)", "toi", 0.5, None, "e"),
   ("À réception : consigner, sceller", "Claude", 0.5, None, "a")],
  dep=["AL-4", "CA-1", "GR-9"], tox=1, prio=1, inc="m")

I("GR-12", "Calibration grossesse", "Claude, toi",
  "Lever les conditions 2 et 3 de VERROU-12 : contrôles du moteur, puis comparaison aux étalons.",
  "D-290 : (2) contrôles automatiques du moteur et cas de référence du tableau de basculement (D-289) ; (3) comparaison à l'étalon d'août et au complément : critère n°1 tenu sur au moins 15 produits orange ou rouges, critère n°2 tenu ou remédié. D-292 : addendum mécanique après ②-A et le gel des règles. D-287 : aucune comparaison avant la clôture du complément. D-246 : un désaccord ne se réexamine que pour une erreur factuelle.",
  "Contrôles passés, comparaison faite selon le pré-enregistrement, désaccords traités, décision écrite sur VERROU-12.",
  [("Recalculer le tableau de basculement sur les règles gelées (addendum, T-608 second temps)", "Claude", 1, None, None),
   ("Passer les contrôles du moteur et les cas de référence", "Claude", 1, None, None),
   ("Comparer à l'étalon d'août et au complément ; tests de biais (D-243 étendue)", "Claude", 1, None, None),
   ("Examiner les désaccords (erreurs factuelles seulement) et décider de VERROU-12", "toi", 3, None, None)],
  dep=["GR-10", "GR-11", "AL-8", "MC-1", "MC-4"], prio=2, inc="F")

I("GR-13", "Mesure interne des règles", "Claude",
  "Mesurer en interne l'effet des règles confirmées sur les verdicts, sans toucher aux produits réservés.",
  "H10 (tâche 3) : mesurer en interne l'effet cumulé des règles confirmées ; rien au toxicologue avant l'étalon (D-250). Revue du 28/10, constat bloquant : D-287 (c) interdit tout calcul sur l'étalon d'août (n° 1 à 36 du benchmark, L-119) avant la clôture du complément et le scellement de D-292 ; D-247 interdit tout calcul sur l'étalon allaitement avant T-599 ; les candidats du complément sont pris dans l'ordre du 28/10, donc dans tout le pool. D'où l'attente de GR-11.",
  "Effet des règles mesuré et consigné, sur des produits hors des étalons, après la clôture du complément.",
  [("Mesurer l'effet des règles confirmées sur les verdicts, hors des produits des étalons", "Claude", 1, None, None),
   ("Relire la mesure", "toi", 0.5, None, None)],
  dep=["GR-10", "GR-11"], prio=5, inc="f")

I("GR-14", "Module huiles essentielles", "toi, Claude, toxicologue, juriste",
  "Construire le module huiles essentielles, au MVP depuis D-57 : frontière, données, graduation, nature du rouge, interface.",
  "D-57 : module au MVP ; T-431 au plancher (le module n'a aucune interface : rouge non calculé, cinq flacons sur six sans INCI codifiée) ; T-416 (le rouge HE, troisième nature de verdict, question à la juriste) et O-17 (frontière module HE / dimension 2, non tracée) bloquants pour la publication. T-328 : graduation non statuée. T-453 : flacon pur sans INCI (arbitré par D-113, B6). La nouvelle vision du 16/09 lançait trois modules ensemble (grossesse, allaitement, HE).",
  "Frontière tracée ; identité et données des produits HE établies ; graduation et nature du rouge tranchées ; interface du module définie.",
  [("Tracer la frontière module HE / dimension 2, objet par objet (O-17)", "Claude", 1, None, None),
   ("Valider la frontière", "toi", 1, None, None),
   ("Identité et données : flacons purs, mélanges, cosmétiques à huiles essentielles ; INCI des flacons (T-453)", "toi", 3, None, None),
   ("Préparer les questions : graduation (T-328, deux formulations côte à côte), phototoxicité des agrumes (T-379)", "Claude", 1, None, None),
   ("Définir l'interface du module : page de verdict, contenu permis (T-431)", "toi", 3, None, None),
   ("Intégrer la réponse de la juriste sur le rouge (T-416)", "toi", 0.75, None, None, ["JU-2"]),
   ("Envoyer les questions au toxicologue", "toi", 0.25, None, "e"),
   ("Inscrire ses réponses ; figer les règles du module", "toi", 2, None, "a")],
  dep=["JU-2", "AL-8"], tox=1, prio=3, inc="F")

# ======================================================================= AL
I("AL-1", "Tranche 1 de l'étalon", "toi, Claude",
  "Constituer la tranche 1 de l'étalon allaitement : 37 produits neufs, jugés à l'aveugle.",
  "D-239 : soins des mamelons 9 (tiers réservé de D-219), divergence à la baisse 8, à la hausse 8, rincés 6, non-rincés ordinaires 6. Fait les 27 et 28/10 : huit décisions et revue critique, gel du pool (190 produits éligibles), tirage unique avec ta graine, deux remplacements, catégories validées ; liste finale de 37 produits (`claude/tirage_tranche1/`). Reste : les fiches et le classeur, avant le 23/11.",
  "Fiches anonymisées et classeur prêts, relus ; part attendue des jaunes inscrite avant toute attribution (T-589).",
  [("Prendre les huit décisions du 26/10 et demander leur revue critique (27/10)", "toi", 1, 0, None),
   ("Fournir la graine après le gel (28/10)", "toi", 0.1, 0, None),
   ("Geler le pool, tirer, appliquer les deux remplacements (28/10)", "Claude", 0.5, 0, None),
   ("Valider les catégories des produits tirés (28/10)", "toi", 1, 0, None),
   ("Écrire les fiches : INCI vérifiées (D-247), huile Medela (C-35) et VEA Olio (C-38) traduites en INCI, phrase d'usage, consigne de D-241", "Claude", 1, 1, None),
   ("Classeur : colonne allaitement unique, relevé du temps, ordre de présentation aléatoire", "Claude", 0.5, 1, None),
   ("Inscrire la part attendue des jaunes dus au seul NB_nourrisson = 1 (T-589), avant toute attribution", "Claude", 0.25, 1, None),
   ("Relire les fiches et le classeur", "toi", 2.4, 2, None)],
  prio=1, inc="f", debut=0)

I("AL-2", "Pré-enregistrement allaitement", "Claude, toi",
  "Écrire et sceller le pré-enregistrement de la calibration allaitement avant tout calcul.",
  "T-599 : critères (D-242, D-243), résultats attendus et ancres (D-244), règle du test du tube, D-200, D-219 ; daté et figé avant tout calcul (D-247). O-43 : critères de succès pré-enregistrés. O-34 : invariant n°2 (un standard de soin jamais orange ou rouge). Poids d'analyse de la tranche 1 : fractions tirées 9/26, 8/9, 8/13, 6/24, 6/70 ; tout chiffre global pondéré par leur inverse (protocole du 28/10, §8).",
  "T-599 scellé (empreinte au registre et par courriel) avant l'envoi 1.",
  [("Rédiger T-599 (livrable annoncé)", "Claude", 0.5, 2, None),
   ("Écrire l'invariant n°2 allaitement en regard de l'invariant n°1 (O-34, T-441)", "Claude", 0.25, 2, None),
   ("Porter les poids d'analyse de la tranche 1", "Claude", 0.25, 2, None),
   ("Relire et valider", "toi", 1.25, 2, None),
   ("Sceller avant l'envoi 1", "Claude", 0.25, 3, None)],
  dep=["AL-1", "AL-3"], prio=1, inc="f", debut=2)

I("AL-3", "Règle du miel", "toi, Claude ; méthode : toxicologue",
  "Fixer une règle provisoire pour un ingrédient dont le danger dépend d'un fait de produit que l'INCI ne porte pas.",
  "Session du 24 au 27/10, §3.1 : le libellé « MEL » ne dit pas si le miel est stérilisé ; défaut proposé : « Non évalué » sur la route concernée, levé par un fait documenté. Le baume au miel est le cas 4 de T-593 et une ancre de D-244 : à trancher avant le scellement de T-599. La question de méthode revient au toxicologue (T-611 ; T-524 : stérilisation déclarée, en ②-A), jamais en ②-G (D-250) ; d'ici là, la règle est provisoire et l'ancre s'écrit sous condition, comme celle du rétinol (D-289).",
  "Règle provisoire tranchée avant le scellement de T-599 ; ancre écrite sous condition ; question placée dans ②-A.",
  [("Compter les produits du corpus qui déclarent MEL", "Claude", 0.25, 0, None),
   ("Vérifier la liste des micro-organismes d'ISO 17516, ou l'écrire en limite", "Claude", 0.25, 1, None),
   ("Trancher la règle provisoire (proposition du §3.1 ou autre voie)", "toi", 1, 1, None),
   ("Écrire l'ancre du baume au miel sous condition ; mettre à jour T-593 (cas 4)", "Claude", 0.5, 1, None),
   ("Placer la question de méthode dans ②-A (T-524)", "Claude", 0.25, None, None)],
  prio=1, inc="f", debut=0)

I("AL-4", "Envoi de la tranche 1", "toxicologue, toi",
  "Envoi 1, le 23/11 : la tranche 1, jugée à l'aveugle. Elle mesure la cadence du toxicologue.",
  "T-325 : le débit du toxicologue n'a jamais été chiffré. D-239 : le temps mesuré en tranche 1 décide l'extension (jusqu'à 80) et la taille du complément grossesse. Il reprend le 23/11 : « je pense que tu pourras me faire un envoi par semaine mais à voir le temps que ça me prend surtout pour les fiches pdts ».",
  "Tranche 1 rendue ; temps par fiche mesuré ; extension et taille du complément décidées.",
  [("Contrôles finaux de l'envoi 1", "Claude", 0.5, 3, None),
   ("Envoyer la tranche 1 le 23/11 (envoi 1)", "toi", 0.25, None, "e"),
   ("Mesurer la cadence (temps par fiche) et l'inscrire (T-325)", "Claude", 0.25, None, "a"),
   ("Décider l'extension de l'étalon et la taille du complément", "toi", 1, None, "a")],
  dep=["AL-1", "AL-2"], tox=1, prio=1, inc="m", debut=4)

I("AL-5", "Tranche 2 et extension", "Claude, toi, toxicologue",
  "Tranche 2 de l'étalon allaitement, puis l'extension si la cadence le permet.",
  "D-239 : tranche 2 de 14 à 22 produits (anti-vergetures 3 à 7, solaires corps 3 à 7, produits à huiles essentielles 6, non-rincés ordinaires 2) ; extension jusqu'à 80, décidée sur le seul temps mesuré. Candidats : premiers produits encore libres de l'ordre du 28/10 ; produits de la collecte : tirage séparé avec une nouvelle graine (protocole, §7). Le N° 73, non tiré, porte une mention de doublon (H12). L'extension retarderait le retour de l'étalon, donc les envois 6 et 7.",
  "Tranche 2 (et extension éventuelle) tirée, envoyée, rendue.",
  [("Vérifier le N° 73 (mention de doublon) avant le tirage", "Claude", 0.25, None, None),
   ("Listes et tirage de la tranche 2 (ordre du 28/10 ; collecte en tirage séparé)", "Claude", 1, None, None),
   ("Fiches anonymisées", "Claude", 0.5, None, None),
   ("Relire les fiches", "toi", 1.75, None, None),
   ("Envoyer la tranche 2 (envoi 4)", "toi", 0.25, None, "e"),
   ("À réception : consigner", "Claude", 0.5, None, "a")],
  dep=["AL-4", "CA-1"], tox=1, prio=1, inc="m")

I("AL-6", "NB_nourrisson", "Claude, toxicologue",
  "Préparer pendant l'étalon les fiches NB_nourrisson et l'essai chronométré, puis les faire noter à la main au retour de l'étalon.",
  "D-193 : NB_nourrisson attribué à la main par le toxicologue sur des fiches sourcées. T-588 : une centaine de fiches, rubriques de D-209, sans note proposée, deux relectures. D-251 : le projet les prépare pendant l'étalon. D-201 et D-249 : l'essai chronométré part avec les fiches, au retour de l'étalon, hors des ingrédients de l'étalon. Décision du 22/10 : fiches détachées de ②-A. VERROU-3 : la zone de tétée n'est évaluée qu'après NB_nourrisson et le succès de la strate mamelons et des ancres (D-245, donc aussi AL-10).",
  "Fiches livrées et relues ; essai chronométré prêt ; notes attribuées à la main.",
  [("Normaliser les INCI de la collecte sur CosIng (T-574)", "Claude", 0.5, None, None),
   ("Vérifier sur emballage les trois baumes non vérifiés (T-249, T-332)", "toi", 1, None, None),
   ("Rédiger la centaine de fiches sourcées (T-588), dont paraffines (T-592)", "Claude", 1, None, None),
   ("Préparer l'essai chronométré : dix fiches hors des ingrédients des étalons (D-201)", "Claude", 0.5, None, None),
   ("Relire les fiches", "toi", 2, None, None),
   ("Envoyer les fiches et l'essai au retour de l'étalon allaitement (envoi 6)", "toi", 0.25, None, "e"),
   ("Inscrire les notes attribuées et le temps mesuré", "Claude", 0.25, None, "a")],
  dep=["AL-1"], tox_dep=["AL-5"], tox=2, prio=2, inc="m", debut=4)

I("AL-7", "Prompt allaitement", "Claude, toxicologue",
  "Construire le prompt allaitement pendant l'étalon, le valider à l'aveugle, puis produire NB_allaitement.",
  "D-222 : NB_allaitement par un prompt dédié, validé à l'aveugle avant tout usage. T-590 : grille de D-197 et règle de repli. D-248 : jeu de validation de 40 ingrédients (20 enrichis « là où la copie est basse », 20 au hasard), scellé avant l'essai ; la copie est faite des notes grossesse, qui n'existent pas encore (T-582) : le tirage attend GR-10. VERROU-1 (D-245) : la ligne allaitement n'est publiée qu'après cette validation et la comparaison à l'étalon.",
  "Prompt construit et figé ; jeu de validation noté ; prompt validé ; NB_allaitement produites et versionnées.",
  [("Construire le prompt allaitement (T-590)", "Claude", 1.5, None, None),
   ("Tirer et sceller le jeu de validation (D-248)", "Claude", 0.5, None, None, ["GR-10"]),
   ("Relire le prompt et le jeu", "toi", 2, None, None, ["GR-10"]),
   ("Envoyer le jeu de validation (après les fiches NB_nourrisson)", "toi", 0.5, None, "e"),
   ("Comparer, décider, produire NB_allaitement sur le référentiel", "Claude", 1.5, None, "a"),
   ("Valider la décision", "toi", 2, None, "a")],
  dep=["AL-1"], tox_dep=["AL-5", "AL-6"], tox=1, prio=2, inc="m", debut=4)

I("AL-8", "②-A et ①-bis", "Claude, toi, toxicologue",
  "Poser au toxicologue l'exposition, nos règles, les couleurs et tout l'allaitement, une fois les exercices à l'aveugle rendus.",
  "D-250 : ces questions passent après l'étalon (un expert qui vient de lire nos règles juge à travers elles) et, côté grossesse, après le complément (D-285). D-253 : ②-A « exposition, règles et allaitement » ; ①-bis (cas de la chlorphénésine réécrit) en tête. Contenu : règles de T-380 (plancher gradué, NB 4 sur les rincés, ingrédient inconnu), absorption cutanée, H362 en allaitement (3 ou 4), phrases (J3), miel (T-524, T-611), questions des blocs D à G (T-524). O-48, fermé sous sa réserve, se revérifie ici.",
  "②-A et ①-bis partis et répondus ; réponses inscrites ; règles gelées.",
  [("Rédiger ①-bis et ②-A (T-600)", "Claude", 1.5, None, None),
   ("Relire", "toi", 2, None, None),
   ("Envoyer ②-A et ①-bis (envoi 7, février au plus tôt)", "toi", 0.5, None, "e"),
   ("Inscrire ses réponses ; revérifier O-48 ; geler les règles", "toi", 1, None, "a")],
  dep=["GR-7", "CT-1", "PR-2", "MC-2"], tox_dep=["AL-5", "GR-11"], tox=2, prio=2, inc="m")

I("AL-9", "Test benchmark", "Claude",
  "Le test benchmark du volet allaitement, en deux passages, avec ses résultats attendus pré-enregistrés.",
  "T-582 : premier passage sur une copie des notes grossesse (mécanique des garde-fous), qui n'existent pas encore (C-251) ; second passage après l'attribution. D-247 : préalables du premier passage, dont le moteur de D-214 avec les contrôles de l'étape 9 (MC-4), T-594 (MC-1), T-312 (MC-3) et O-43 (AL-2). D-287 (c) : aucun calcul sur les produits d'août avant la clôture du complément. T-593 : treize cas de référence (dont le cas « FDA 2008 » ajouté le 13/10).",
  "Les deux passages faits ; cas de référence retrouvés ; écarts expliqués.",
  [("Pré-enregistrer les résultats attendus de chaque passage", "Claude", 1, None, None),
   ("Premier passage (mécanique)", "Claude", 1.5, None, None),
   ("Second passage (valeurs), après NB_allaitement", "Claude", 1, None, None, ["AL-7"]),
   ("Relire les résultats", "toi", 1.5, None, None, ["AL-7"])],
  dep=["GR-10", "GR-11", "MC-1", "MC-3", "MC-4", "AL-2"], prio=3, inc="m")

I("AL-10", "Calibration allaitement", "Claude, toi",
  "Comparer le modèle à l'étalon allaitement selon T-599 et décider de VERROU-1 et VERROU-3.",
  "D-245 : VERROU-1, la ligne allaitement n'est publiée qu'après la validation du prompt allaitement et la comparaison à l'étalon (critère n°1 tenu, biais traités) ; VERROU-3, la zone de tétée n'est évaluée qu'après NB_nourrisson et le succès de la strate mamelons et des ancres. D-246 : un désaccord ne se réexamine que pour une erreur factuelle.",
  "Comparaison faite selon T-599 ; désaccords traités ; décision écrite sur VERROU-1 et VERROU-3.",
  [("Comparer selon T-599, strate par strate", "Claude", 1.5, None, None),
   ("Examiner les désaccords (erreurs factuelles seulement)", "toi", 2, None, None),
   ("Décider de VERROU-1 et de VERROU-3 ; inscrire", "toi", 1.5, None, None)],
  dep=["AL-7", "AL-6", "AL-8", "AL-9", "AL-2"], prio=2, inc="F")
