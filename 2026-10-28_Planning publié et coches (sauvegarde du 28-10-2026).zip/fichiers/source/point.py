"""Point hebdomadaire du planning Ficolia.
Usage : python3 -I point.py PLAN_JSON DOSSIER_COCHES [AAAA-MM-JJ]
PLAN_JSON : plan.json publié avec la page ; DOSSIER_COCHES : un fichier <id>.json par coche ({fait, le, par, source}).
Reproduit la logique de la page (pondération option A, sous-tâches « après retour » bloquées tant que l'envoi n'est pas coché).
"""
import datetime as dt
import glob
import json
import os
import sys

P = json.load(open(sys.argv[1], encoding="utf-8"))
C = {}
for f in glob.glob(os.path.join(sys.argv[2], "*.json")):
    d = json.load(open(f, encoding="utf-8"))
    if d.get("fait"):
        C[os.path.basename(f)[:-5]] = d
today = dt.date.fromisoformat(sys.argv[3]) if len(sys.argv) > 3 else dt.date.today()
L0 = dt.date.fromisoformat(P["meta"]["lundi0"])
W = (today - L0).days // 7
MOIS = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."]
IT = {i["id"]: i for i in P["items"]}
for i in P["items"]:
    for s in i["sous"]:
        s["item"] = i["id"]


def lundi(k):
    return L0 + dt.timedelta(weeks=k)


def sem(k):
    d = lundi(k)
    return "sem. du " + d.strftime("%d/%m") + ("" if d.year == 2026 else d.strftime("/%y"))


def mois(k):
    d = lundi(k)
    return MOIS[d.month - 1] + " " + str(d.year)


def fait(sid):
    return sid in C


def item_fait(i):
    return all(fait(s["id"]) for s in i["sous"])


def envoi_fait(i):
    es = [s for s in i["sous"] if s["ph"] == "e"]
    return all(fait(s["id"]) for s in es) if es else all(item_fait(IT[d]) for d in i["dep"] if d in IT)


def bloquee(s):
    return s["ph"] == "a" and not envoi_fait(IT[s["item"]])


def wplan(s):
    return s["sem"] if s["sem"] is not None else s["c"]


def pct(filtre):
    t = f = 0.0
    for i in P["items"]:
        if i["hors_pct"] or not filtre(i):
            continue
        for s in i["sous"]:
            t += s["w"]
            f += s["w"] if fait(s["id"]) else 0
    return (100 * f / t if t else 0.0), f, t


def fp(x):
    return (f"{x:.1f}" if 0 < x < 10 else str(int(x + 0.5))).replace(".", ",") + " %"


def ligne(s, extra=""):
    i = IT[s["item"]]
    return f"- {s['id']} — {s['t']} ({i['titre']}){extra}"


out = []
L = lundi(W)
out.append(f"## Point du {today.strftime('%d/%m/%Y')} — semaine {W + 1} du planning (du {L.strftime('%d/%m')} au {(L + dt.timedelta(days=6)).strftime('%d/%m/%Y')})")
out.append(f"Planning : état au {P['meta']['etat_au']}, registre {P['meta']['registre']}.")
if W > 3:
    out.append("⚠ La partie datée du planning (26/10 au 22/11) est passée : le planning doit être recalculé.")
tot, f, t = pct(lambda i: True)
hc = pct(lambda i: not i["dev"])[0]
co = pct(lambda i: i["dev"])[0]
out.append(f"\n**Avancement** : {fp(tot)} ({int(f + 0.5)} h cochées sur {int(t + 0.5)}) ; hors code {fp(hc)} ; code {fp(co)}.")
out.append("Par groupement : " + " ; ".join(f"{fa['nom']} {fp(pct(lambda i, fa=fa: i['ch'] in fa['ch'])[0])}" for fa in P["familles"]) + ".")
lev = [v["id"] for v in P["verrous"] if not v["leve_par"] or all(fait(x) for x in v["leve_par"])]
out.append(f"Verrous de publication levés : {len(lev)} sur {len(P['verrous'])} ({', '.join(lev) or 'aucun'}).")

cette, proch, retard, glisse = [], [], [], []
for i in P["items"]:
    for s in i["sous"]:
        if fait(s["id"]) or bloquee(s):
            continue
        pw = wplan(s)
        if pw == W:
            cette.append(s)
        elif pw == W + 1:
            proch.append(s)
        elif pw < W:
            (retard if s["sem"] is not None else glisse).append(s)
h_sem = sum(s["h"] for s in cette if not IT[s["item"]]["dev"])
out.append(f"\n**Cette semaine** ({len(cette)} sous-tâches, {h_sem:.1f} h de ton temps prévues)".replace(".", ","))
for qui, lab in (("toi", "À toi"), ("Claude", "Claude prépare, tu relis")):
    x = [s for s in cette if s["qui"] == qui]
    if x:
        out.append(f"*{lab}*")
        out += [ligne(s) for s in x]
autres = [s for s in cette if s["qui"] not in ("toi", "Claude")]
out += [ligne(s, f" [{s['qui']}]") for s in autres]
if not cette:
    out.append("- rien de prévu")

tiers = []
for i in P["items"]:
    if (i["tox"] or i["att"]) and envoi_fait(i) and not any(fait(s["id"]) for s in i["sous"] if s["ph"] == "a") and not item_fait(i):
        es = [s for s in i["sous"] if s["ph"] == "e"]
        le = C.get(es[-1]["id"], {}).get("le", "") if es else ""
        ret = f", retour estimé {sem(i['ret'])}" if i["ret"] is not None else ""
        tiers.append(f"- {i['id']} — {(i['envoi'][0] + ' : ' + i['envoi'][1]) if i['envoi'] else i['titre_long']} (chez : {i.get('chez') or ('toxicologue' if i['tox'] else 'tiers')}{', parti le ' + le if le else ''}{ret})")
out.append(f"\n**Chez un tiers** ({len(tiers)})")
out += tiers or ["- rien d'après les coches"]
prochains = [e for e in P["envois"] if not envoi_fait(IT[e["item"]])][:3]
out.append("Prochains envois au toxicologue : " + ("; ".join(f"{e['lab']} ({e['item']}) — {e['desc']}, {'' if e['envoye'] <= 4 else 'au plus tôt '}{sem(e['envoye'])}" for e in prochains) or "aucun") + ".")

out.append(f"\n**En retard** ({len(retard)} sous-tâches datées)")
out += [ligne(s, f" — prévu {sem(s['sem'])}") for s in retard] or ["- rien"]
if glisse:
    out.append(f"Derrière l'estimation (non datées) : {len(glisse)} sous-tâches, dont : " + " ; ".join(s["id"] for s in glisse[:12]) + (" …" if len(glisse) > 12 else ""))

out.append(f"\n**Semaine prochaine** ({len(proch)})")
out += [ligne(s, f" [{s['qui']}]") for s in proch] or ["- rien"]

jal = sorted([j for j in P["jalons"] if not all(item_fait(IT[x]) for x in j["items"])], key=lambda j: j["c"])
if jal:
    j = jal[0]
    out.append(f"\nProchain jalon estimé : {j['id']} {j['nom']}, {mois(j['c'])} (enveloppe {mois(j['b'])} – {mois(j['hh'])}).")
pub = P["meta"]["pub"]
out.append(f"Publication estimée (scénario central) : {mois(pub['central'])} ; enveloppe {mois(pub['bas'])} – {mois(pub['haut'])}. Estimation, pas un jalon (T-236).")
out.append(f"\nQuestions ouvertes pour toi : {len(P['questions'])}.")
print("\n".join(out))
