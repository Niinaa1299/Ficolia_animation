"""Ossature du planning Ficolia (27/10/2026) : items, rattachement des barres du 20/10,
rattachements manuels, contrôle de couverture du registre v6.7.
Usage : python3 -I ossature.py OUTDIR   (lit taches.json, o_points.json, couverture.json)
"""
import json
import re
import sys
from collections import defaultdict, Counter

OUT = sys.argv[1]
T = json.load(open(OUT + "/taches.json", encoding="utf-8"))
O = json.load(open(OUT + "/o_points.json", encoding="utf-8"))
C = json.load(open(OUT + "/couverture.json", encoding="utf-8"))

# ------------------------------------------------------------------ items
ITEMS = {
    # PI — Pilotage
    "PI-1": "Source unique : projet, compte, canevas et collecte de référence",
    "PI-2": "Planning publié, coches et rappel quotidien",
    "PI-3": "Registre v6.8",
    "PI-4": "Arbitrer T-521 et poser les jalons (après la cadence mesurée)",
    "PI-5": "Arbitrage final des sujets à arbitrer, par thème",
    "PI-6": "Budget et financement",
    "PI-7": "Hygiène documentaire du projet",
    "PI-8": "Consolidation finale : registre et documents régénérés",
    # GR — Ligne grossesse
    "GR-1": "Dossier des règles de la note grossesse (v0 → tenu à jour)",
    "GR-2": "Message au toxicologue : points 21, 22, 25 et 26",
    "GR-3": "Tirer et sceller R1 et R2",
    "GR-4": "Pré-enregistrer la validation du prompt grossesse",
    "GR-5": "Envoi de R1 et retour scellé",
    "GR-6": "Envoi écrit sur la grille",
    "GR-7": "②-G réduit (après T-525)",
    "GR-8": "Corriger et figer le prompt grossesse",
    "GR-9": "Valider le prompt sur R1 (VERROU-12, condition 1)",
    "GR-10": "NB_grossesse produites sur le référentiel",
    "GR-11": "Complément grossesse",
    "GR-12": "Calibration grossesse (VERROU-12, conditions 2 et 3)",
    "GR-13": "Points internes : NB 1 sans signal, test d'impact",
    "GR-14": "Module huiles essentielles",
    # AL — Ligne allaitement
    "AL-1": "Tranche 1 de l'étalon : décisions, tirage, fiches",
    "AL-2": "Pré-enregistrement de la calibration allaitement",
    "AL-3": "Règle du miel (fait de produit absent de l'INCI)",
    "AL-4": "Envoi de la tranche 1, cadence mesurée",
    "AL-5": "Tranche 2 et extension de l'étalon",
    "AL-6": "NB_nourrisson : fiches, attribution (VERROU-3)",
    "AL-7": "Prompt allaitement : jeu de validation, validation, NB_allaitement (VERROU-1)",
    "AL-8": "②-A et ①-bis",
    "AL-9": "Test benchmark en deux passages",
    "AL-10": "Calibration allaitement",
    # MC — Modèle de calcul et exposition
    "MC-1": "Table des paramètres v1-calibration",
    "MC-2": "Audit de l'exposition",
    "MC-3": "Catégories, rinçage, attributs",
    "MC-4": "Cas de référence et contrôles du moteur",
    "MC-5": "Modèle figé, paramètres hors du code",
    # RF — Référentiel INCI et criblage
    "RF-1": "Jeux de données officiels figés",
    "RF-2": "Faits à vérifier (sources de données)",
    "RF-3": "Référentiel : comptage des statuts et synchronisation",
    "RF-4": "Criblage réglementaire complet (VERROU-2)",
    "RF-5": "Veille et révision des NB",
    # CT — Contenus et textes
    "CT-1": "Phrases sous le verdict, deux lignes, par cause",
    "CT-2": "Contenus du bloc G, sources à vérifier, faits allaitement resourcés",
    "CT-3": "Inventaire et règles des textes",
    "CT-4": "Textes « ce qui est en cause »",
    "CT-5": "Méthodologie finale et limites",
    "CT-6": "Textes publics : fiche méthode, CGU, confidentialité, mentions",
    # CA — Catalogue et données produits
    "CA-1": "Collecte complémentaire (dont le 25/10)",
    "CA-2": "Mesures sans tiers",
    "CA-3": "Alimentation de la base en listes INCI",
    "CA-4": "Mesure des mentions du fabricant",
    "CA-5": "Dix salles de bains",
    "CA-6": "Arbitrer le thème catalogue",
    "CA-7": "Catalogue et transcription",
    # PR — Prototype et tests
    "PR-1": "Canevas de référence et points en suspens",
    "PR-2": "Premier tour de test hors cible",
    "PR-3": "Prototype : étapes 5 à 8",
    "PR-4": "Tests avec des testeuses de la cible",
    "PR-5": "Essai de la version candidate",
    # TE — Technique et développement
    "TE-1": "Avis technique extérieur et devis de la revue de sécurité",
    "TE-2": "Architecture technique",
    "TE-3": "Planning de développement dédié",
    "TE-4": "Base, API, back-office",
    "TE-5": "Application Android",
    "TE-6": "Modèle figé intégré et testé",
    "TE-7": "Revue de sécurité extérieure",
    # JU — Juridique, structure, assurance
    "JU-1": "Rendez-vous avec la juriste",
    "JU-2": "Réponses de la juriste intégrées, suites",
    "JU-3": "Marque Ficolia et noms de domaine",
    "JU-4": "Structure éditrice (VERROU-5)",
    "JU-5": "Assurance (VERROU-6)",
    "JU-6": "Accord écrit avec le toxicologue",
    "JU-7": "RGPD",
    "JU-8": "Relecture des textes publics et de la version réelle",
    "JU-9": "Pièces de diligence",
    # MK — Marketing
    "MK-1": "Cadrage du marketing",
    "MK-2": "Concurrence et différenciation",
    "MK-3": "Messages et revendications",
    "MK-4": "Fiche des stores : textes et visuels",
    "MK-5": "Présence hors application",
    "MK-6": "Plan de lancement",
    # PU — Publication et stores
    "PU-1": "Politiques des stores santé (VERROU-8)",
    "PU-2": "Compte de publication",
    "PU-3": "Déclarations des stores",
    "PU-4": "Décision de lancement (JALON-05)",
    "PU-5": "Soumission et publication Android",
    # EX — Exploitation
    "EX-1": "Préparer l'exploitation (VERROU-7)",
    "EX-2": "Premier mois après la publication",
}

# ------------------------------------------------------------------ barres du 20/10
BAR2ITEM = {
    "EN1": ["AL-8"], "EN1W": ["AL-8"],
    "TX1": ["GR-1", "AL-7"], "TX2": ["GR-7", "AL-8"], "TXP": ["GR-12"],
    "TXW": ["AL-4"], "TX4": ["GR-7", "AL-8"], "TX3": ["AL-4"],
    "ETP": ["AL-1", "GR-11"], "TX8": ["AL-4", "AL-5", "GR-11"],
    "TX5": ["AL-6"], "TX6": ["GR-9", "AL-7"], "TX7": ["GR-10", "AL-7"],
    "CAL": ["GR-12", "AL-10", "MC-5"], "TX9": ["CT-4"],
    "AL1": ["AL-2"], "AL2": ["AL-1", "AL-6"], "BM1": ["AL-9"], "AL3": ["CT-2"],
    "DA1": ["CA-2"], "AVE": ["RF-2"], "DA2": ["MC-2"], "DA4": ["CA-5"],
    "DA3": ["RF-4"], "DA5": ["CA-7"],
    "PRH": ["PR-2"], "PR1": ["PR-3"], "PR2": ["PR-3"], "PR3": ["PR-4"], "VC": ["PR-5"],
    "CT1": ["CT-3"], "RES": ["CT-2"], "CT2": ["CT-4"], "CT3": ["CT-6"],
    "JU1": ["JU-1"], "POL": ["PU-1"], "JU2": ["JU-2"], "JU3": ["JU-4"],
    "TXA": ["JU-6"], "JU4": ["PU-2", "JU-5"], "RGP": ["JU-7"], "JU5": ["JU-8"],
    "LEG": ["JU-8"],
    "TE1": ["TE-1"], "TE2": ["TE-4"], "TE3": ["TE-5"], "TE4": ["TE-6"], "TE5": ["TE-7"],
    "TE6": ["PU-5"], "HE2": ["GR-14"], "HE1": ["CA-4"], "PI1": ["PI-4"],
    "FIN": ["PI-6"], "PI2": ["PI-5"], "ARC": ["CA-6"], "PI3": ["PI-8"],
    "DEC": ["PU-4"], "EX1": ["EX-1"], "VEI": ["RF-5"],
}
BARRE_RE = re.compile(r"^(" + "|".join(sorted(BAR2ITEM, key=len, reverse=True)) + r")\b")

# ------------------------------------------------------------------ rattachements manuels
# (tâches absentes de la couverture du 20/10, ou rattachement revu)
MANUAL = {
    # plancher nouveaux depuis le 13/10
    "T-594": ["MC-1"], "T-598": ["AL-1", "AL-5"], "T-599": ["AL-2"], "T-600": ["GR-7", "AL-8"],
    "T-601": ["CT-5"], "T-602": ["MC-3"], "T-603": ["MC-3"], "T-604": ["CT-1"],
    "T-605": ["CT-2"], "T-606": ["CT-2"], "T-607": ["GR-11"], "T-608": ["GR-11", "GR-12"],
    "T-609": ["CT-1"],
    # à vérifier
    "T-611": ["AL-3"], "T-591": ["GR-1"],
    # suspendue
    "T-404": ["JU-2", "PR-3"],
    # travail
    "T-12": ["MC-2"], "T-14": ["MC-3"], "T-20": ["RF-4"], "T-21": ["RF-5"], "T-22": ["RF-5"],
    "T-23": ["RF-5"], "T-24": ["GR-7"], "T-25": ["GR-1"], "T-26": ["RF-4"], "T-28": ["RF-3"],
    "T-29": ["RF-5"], "T-30": ["AL-8"], "T-31": ["RF-5"], "T-35": ["RF-4"], "T-37": ["RF-4"],
    "T-38": ["RF-5"], "T-43": ["CT-5"], "T-45": ["AL-8"], "T-47": ["AL-8"], "T-55": ["RF-5"],
    "T-58": ["CA-3"], "T-60": ["EX-1"], "T-61": ["RF-5"], "T-62": ["CA-7"], "T-67": ["RF-5"],
    "T-68": ["RF-5"], "T-75": ["CA-6"], "T-76": ["CA-3"], "T-77": ["RF-5"], "T-78": ["CA-7"],
    "T-79": ["RF-5"], "T-92": ["RF-5"], "T-94": ["EX-1"], "T-97": ["PI-5"], "T-106": ["CT-5"],
    "T-127": ["EX-1", "PR-4"], "T-145": ["JU-6"], "T-148": ["TE-1", "PI-6"], "T-153": ["MK-1"],
    "T-166": ["PI-6"], "T-171": ["JU-6"], "T-184": ["CT-3"], "T-185": ["CT-3"], "T-188": ["CT-3"],
    "T-223": ["RF-5"], "T-226": ["PR-3"], "T-236": ["PI-4"], "T-238": ["TE-5"], "T-240": ["RF-4"],
    "T-241": ["CA-2"], "T-247": ["MC-1"], "T-255": ["TE-4"], "T-259": ["CT-1"], "T-273": ["GR-7"],
    "T-274": ["GR-7"], "T-276": ["GR-1"], "T-277": ["GR-6", "AL-3"], "T-282": ["RF-4"],
    "T-284": ["GR-10"], "T-288": ["RF-3"], "T-289": ["GR-10"], "T-290": ["RF-3"], "T-291": ["PI-7"],
    "T-293": ["GR-1"], "T-294": ["CT-5"], "T-297": ["RF-5"], "T-299": ["RF-4"], "T-301": ["GR-7"],
    "T-302": ["AL-8"], "T-303": ["GR-3"], "T-325": ["AL-4"], "T-326": ["RF-3"], "T-327": ["PI-8"],
    "T-332": ["AL-6"], "T-337": ["MC-2"], "T-338": ["MC-2"], "T-348": ["GR-7"], "T-353": ["GR-7"],
    "T-354": ["RF-4"], "T-355": ["RF-4"], "T-356": ["RF-4"], "T-357": ["RF-4"], "T-358": ["RF-4"],
    "T-359": ["RF-5"], "T-364": ["PI-8"], "T-365": ["PR-3"], "T-366": ["PR-3"], "T-368": ["PR-3"],
    "T-373": ["PR-3"], "T-382": ["RF-4"], "T-397": ["PR-3"], "T-398": ["PR-4"], "T-418": ["JU-1"],
    "T-425": ["PI-8"], "T-427": ["PI-7"], "T-438": ["CT-3"], "T-445": ["MC-3"], "T-451": ["CT-5"],
    "T-496": ["PI-7"], "T-508": ["PR-4", "PI-4"], "T-520": ["EX-2"], "T-522": ["PI-4", "MK-2"],
    "T-574": ["AL-6"], "T-575": ["PI-7"], "T-578": ["PI-7"], "T-580": ["PI-7"], "T-583": ["PI-7"],
    "T-584": ["AL-6"], "T-586": ["PI-8"], "T-587": ["AL-1"], "T-592": ["AL-6"], "T-595": ["MC-1"],
    "T-596": ["GR-2"], "T-597": ["CA-1"], "T-610": ["JU-1"],
    # à arbitrer sans barre utile ou rattachement revu
    "T-521": ["PI-4"], "T-485": ["MK-2"], "T-546": ["MK-5", "CT-3"], "T-553": ["MK-2", "JU-2"],
    "T-567": ["MK-2"], "T-519": ["CA-6"], "T-517": ["CA-6"], "T-518": ["CA-3"],
    # rattachements revus (27/10) : items précis plutôt que barres génériques
    "T-593": ["MC-4", "TE-6", "AL-9"], "T-441": ["MC-4", "TE-6", "AL-9"],
    "T-463": ["JU-3"], "T-460": ["JU-9"], "T-506": ["MK-4", "CT-6", "PU-3"],
    "T-534": ["CT-3", "MK-3"], "T-541": ["CT-1", "PR-2", "PR-4"], "T-540": ["PR-2", "PR-4"],
    "T-555": ["PU-1", "PU-3", "JU-2"], "T-235": ["PU-3"], "T-503": ["PU-3", "TE-5"],
    "T-232": ["TE-5", "PU-3"], "T-233": ["PU-2"], "T-234": ["PU-2"], "T-140": ["JU-5"],
    "T-344": ["RF-3"], "T-590": ["AL-7"], "T-582": ["AL-9", "AL-2"], "T-571": ["GR-8", "AL-7"],
    "T-32": ["MC-5", "TE-4"], "T-474": ["MC-5", "TE-4"],
    # envoi ② découpé selon D-250 : ②-G (GR-7) avant l'étalon, ②-A (AL-8) après
    "T-15": ["GR-7", "EX-1", "JU-6"], "T-174": ["GR-7"], "T-242": ["GR-7", "RF-5"],
    "T-275": ["GR-7"], "T-279": ["GR-7"], "T-281": ["GR-6", "AL-3"], "T-283": ["AL-8"],
    "T-300": ["GR-1", "CT-4"], "T-311": ["GR-6"], "T-321": ["GR-7"], "T-345": ["GR-7", "RF-4"],
    "T-352": ["GR-6", "RF-4"], "T-377": ["GR-7"], "T-379": ["GR-7", "GR-14"], "T-458": ["GR-7"],
    "T-483": ["RF-3", "GR-7"], "T-487": ["RF-4", "GR-7"], "T-488": ["GR-7"], "T-498": ["GR-7"],
    "T-525": ["GR-7"], "T-530": ["GR-1", "CT-3"], "T-269": ["GR-1"], "T-270": ["GR-1"],
    "T-271": ["GR-1"], "T-272": ["GR-1"], "T-280": ["GR-1", "AL-8"],
    "T-10": ["AL-8"], "T-46": ["AL-8"], "T-239": ["AL-8", "MC-3"], "T-244": ["AL-8"],
    "T-245": ["AL-8", "MC-1"], "T-246": ["AL-8", "MC-1"], "T-316": ["AL-8"], "T-378": ["AL-8"],
    "T-317": ["AL-8"], "T-380": ["AL-8"], "T-387": ["GR-1", "AL-8", "CT-2", "PR-3"],
    "T-456": ["AL-8"], "T-471": ["CT-4", "AL-8"], "T-524": ["GR-7", "AL-8"],
    "T-579": ["PI-5"],
    # revue indépendante du 28/10 (constat 14) : rattachements corrigés
    "T-273": ["GR-1"], "T-371": ["CT-1"],
    # revue indépendante du 28/10 (constat 5) : file de contributions, rattachement provisoire
    # (décision de séance 86 du 07/10, à inscrire selon D-223) ; et trois tâches hors plancher utiles
    "T-51": ["EX-1"], "T-82": ["TE-5"], "T-84": ["CA-2"], "T-86": ["TE-4"], "T-89": ["EX-1", "JU-7"],
    "T-90": ["JU-7"], "T-138": ["JU-7", "EX-1"], "T-161": ["TE-5"], "T-227": ["TE-4"],
    "T-415": ["JU-7", "TE-2"], "T-448": ["TE-5"],
    "T-162": ["PU-3"], "T-142": ["JU-6"], "T-310": ["GR-7"], "T-556": ["GR-7"],
    "T-152": ["MK-1"],
}
PROVISOIRE = {r: "rattachement provisoire : décision de séance 86 du 07/10 (contribution photo au lancement), à inscrire (D-223)"
              for r in ("T-51", "T-82", "T-84", "T-86", "T-89", "T-90", "T-138", "T-161", "T-227", "T-415", "T-448")}
PROVISOIRE.update({
    "T-162": "hors plancher au registre ; le questionnaire des stores est obligatoire (revue du 28/10)",
    "T-142": "hors plancher au registre ; à poser au toxicologue avec l'accord (revue du 28/10)",
    "T-310": "hors plancher au registre ; déjà porté par ②-G (D-252)",
    "T-556": "hors plancher au registre ; information au toxicologue, peut partir avec ②-G",
    "T-152": "« dehors » au registre ; tu vises les maternités en second temps : à re-statuer et à soumettre à la juriste",
})
# points fermés à titre provisoire, à revérifier à la réponse d'un tiers
VERIFS = {"O-52": ["JU-2"], "O-27": ["JU-2"], "O-48": ["AL-8"]}
# ------------------------------------------------------------------ annexes (hors planning jusqu'à la publication)
ANNEXE = {}  # ref -> (annexe, note)
for r, t in T.items():
    p = t["perim"]
    if t["statut"] in ("Close", "Retirée", "Annulée"):
        continue
    if p.startswith("hors plancher (onglet)"):
        continue  # mixte : rattachée à CT-6 ci-dessous
    if p.startswith("hors plancher"):
        ANNEXE[r] = ("Hors plancher", "")
    elif p.startswith("v2"):
        ANNEXE[r] = ("V2", "")
    elif p.startswith("dehors"):
        ANNEXE[r] = ("Dehors", "")
    elif p == "—":
        ANNEXE[r] = ("Déjà tranchée", "requalifiée et tranchée : clôture à proposer en v6.8")
MANUAL["T-537"] = ["CT-6"]  # hors plancher (onglet) · plancher (menu)
MANUAL["T-205"] = ["TE-5"]  # v2 (chantier complet) · plancher (règles de non-fermeture)
for r in list(ANNEXE):
    if r in MANUAL:
        ANNEXE.pop(r)
# parties hors plancher, V2 ou reportées des tâches scindées : listées aussi en annexe
SCINDEES = {r: t["perim"] for r, t in T.items() if t["statut"] == "Scindée"}
# notes d'annexe utiles au planning
ANNEXE_NOTES = {
    "T-51": "contribution photo", "T-82": "contribution photo", "T-84": "contribution photo",
    "T-86": "contribution photo", "T-89": "contribution photo", "T-90": "contribution photo",
    "T-138": "contribution photo", "T-415": "contribution photo",
    "T-80": "conditionne la piste des sites des marques (CA-3)",
    "T-454": "piste INCI API (CA-3)", "T-455": "piste INCI API (CA-3)",
    "T-162": "à grouper avec T-7 (PU-1)", "T-231": "iOS (hors date)",
    "T-556": "information au toxicologue, peut partir avec ②-G (GR-7)",
    "T-389": "dehors sous réserve de la juriste (JU-2)",
}

OPEN_ST = ("Ouverte", "Proposition", "Suspendue", "Requalifiée", "Reformulée", "Révisée", "Scindée")
O_FERMES_ANNOT = {"O-11", "O-16", "O-26", "O-27", "O-29", "O-30"}  # fermés par annotation
O_MANUAL = {
    "O-2": ["MC-3"], "O-5": ["RF-5"], "O-6": ["CA-6"], "O-7": ["JU-4"], "O-8": ["MC-2"],
    "O-9": ["CA-6"], "O-10": ["CA-6"], "O-12": ["CA-6"], "O-13": ["TE-5"], "O-14": ["RF-5"],
    "O-15": ["PI-6"], "O-17": ["GR-14"], "O-18": ["PI-8"], "O-19": ["CT-3"], "O-20": ["CT-3"],
    "O-21": ["JU-2"], "O-22": ["JU-2", "CT-1"], "O-23": ["CA-6"], "O-24": ["CA-6"], "O-25": ["RF-4"],
    "O-28": ["CT-4"], "O-34": ["AL-2"], "O-35": ["CT-5"], "O-36": ["PI-5"], "O-40": ["AL-8"],
    "O-41": ["AL-8"], "O-43": ["AL-2"], "O-47": ["CT-5"], "O-57": ["AL-7", "JU-6"], "O-59": ["GR-12"],
}


def bars_of(ref):
    out = []
    for row in C.get(ref, []):
        for cell in row["cells"]:
            for part in cell.split(" ; "):
                m = BARRE_RE.match(part.strip())
                if m:
                    out.append(m.group(1))
    return out


rattach = {}
sources = {}
for r, t in T.items():
    if t["statut"] not in OPEN_ST:
        continue
    if r in ANNEXE:
        continue
    if r in MANUAL:
        rattach[r] = MANUAL[r]
        sources[r] = "manuel"
        continue
    b = bars_of(r)
    if b:
        items = []
        for x in b:
            for it in BAR2ITEM[x]:
                if it not in items:
                    items.append(it)
        rattach[r] = items
        sources[r] = "barres 20/10 : " + ", ".join(dict.fromkeys(b))
    else:
        rattach[r] = []
        sources[r] = "AUCUN"

orat = {}
for r, o in O.items():
    if o["ferme"] or r in O_FERMES_ANNOT:
        continue
    orat[r] = O_MANUAL.get(r, [])

# contrôles
sans = [r for r, v in rattach.items() if not v]
inconnus = [(r, it) for r, v in rattach.items() for it in v if it not in ITEMS]
inconnus += [(r, it) for r, v in orat.items() for it in v if it not in ITEMS]
o_sans = [r for r, v in orat.items() if not v]
par_item = defaultdict(list)
for r, v in rattach.items():
    for it in v:
        par_item[it].append(r)
for r, v in orat.items():
    for it in v:
        par_item[it].append(r)
for r, v in VERIFS.items():
    for it in v:
        par_item[it].append(r)
vides = [it for it in ITEMS if not par_item.get(it)]

perim = Counter()
for r in rattach:
    p = T[r]["perim"]
    perim[re.split(r"\s+—\s+|\s+\(", p)[0]] += 1
print("tâches rattachées :", len(rattach), dict(perim))
print("annexes :", Counter(a for a, _ in ANNEXE.values()))
print("points ouverts rattachés :", len(orat))
print("SANS rattachement :", sans)
print("items inconnus :", inconnus)
print("O sans rattachement :", o_sans)
print("items sans aucune entrée du registre :", vides)
json.dump(dict(items=ITEMS, rattach=rattach, sources=sources, orat=orat,
               annexe=ANNEXE, annexe_notes=ANNEXE_NOTES, provisoire=PROVISOIRE, verifs=VERIFS,
               scindees=SCINDEES,
               par_item={k: sorted(v, key=lambda x: (x[0], int(x[2:]))) for k, v in par_item.items()}),
          open(OUT + "/ossature.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for it in ITEMS:
    print(f"{it:6} {len(par_item.get(it, [])):3}  {ITEMS[it]}")
