"""Génère la page du planning Ficolia à partir de plan.json et ossature.json.
Usage : python3 -I gen_page.py OUTDIR  → OUTDIR/planning.html
"""
import json
import os
import sys
import collections

OUT = sys.argv[1]
P = json.load(open(os.path.join(OUT, "plan.json"), encoding="utf-8"))
OSS = json.load(open(os.path.join(OUT, "ossature.json"), encoding="utf-8"))

src = collections.Counter("barres" if v.startswith("barres") else v for v in OSS["sources"].values())
P["meta"]["n_barres"] = src.get("barres", 0)
P["meta"]["n_manuel"] = src.get("manuel", 0)
P["meta"]["n_rattachees"] = len(OSS["sources"])
P["meta"]["n_annexe"] = len(P["annexes"]["hors"])
P["meta"]["n_ouverts"] = len(OSS["orat"])
P["meta"]["n_items"] = len(P["items"])
P["meta"]["n_ch"] = len(P["chantiers"])

# Chez qui part chaque item en attente d'un tiers (affichage seulement)
CHEZ = {
    "GR-2": "toxicologue", "CA-5": "les dix participantes", "PR-4": "les testeuses",
    "TE-1": "l'expert technique", "TE-7": "le relecteur de sécurité",
    "JU-1": "la juriste", "JU-2": "la juriste", "JU-8": "la juriste",
    "JU-4": "démarches de la structure éditrice", "JU-5": "l'assureur",
    "JU-6": "le toxicologue (accord)", "PU-2": "vérification du compte de publication",
    "PU-5": "examen par le store",
}
for i in P["items"]:
    if i["tox"]:
        i["chez"] = "toxicologue"
    elif i["att"]:
        if i["id"] not in CHEZ:
            sys.exit("libellé « chez » manquant pour " + i["id"])
        i["chez"] = CHEZ[i["id"]]
    else:
        i["chez"] = ""

data = json.dumps(P, ensure_ascii=False, separators=(",", ":"))
# Copie publiée avec la page (fichier plan.json) : lue par la commande « point »
open(os.path.join(OUT, "plan_page.json"), "w", encoding="utf-8").write(data)
data = data.replace("</", "<\\/").replace("<!--", "<\\u0021--")

FAMS = [f["id"] for f in P["familles"]]
PATTERNS = "".join(
    '<pattern id="hz-%s" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">'
    '<line x1="0" y1="0" x2="0" y2="6" style="stroke:var(--f-%s)" stroke-width="2" opacity=".6"/></pattern>' % (f, f)
    for f in FAMS)

HTML = r"""<title>Planning Ficolia</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Antic+Didone&family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans:ital,wght@0,400;0,500;0,600;1,400&display=swap">
<style>
:root{
  --bg:#f8f4ee; --surface:#fffdf9; --sunk:#f1ebe3; --ink:#2a231f; --muted:#6c6158; --faint:#9a8e83;
  --line:#e3d9cc; --line-strong:#cdbfae; --accent:#71262f; --accent-ink:#fff8f6; --accent-soft:#f3e4e2;
  --ok:#3f6a3a; --ok-soft:#e3eddc; --warn:#8a510c; --warn-soft:#f6e9d3; --late:#a2441a; --late-soft:#f7e1d6;
  --wait:#5f5e86; --wait-soft:#e8e7f1; --today:#a2441a; --band:#efe6da; --chip-ink:#ffffff;
  --f-methode:#5f7d46; --f-contenus:#a0742a; --f-donnees:#a6491a; --f-prototype:#43707f;
  --f-code:#4b5b85; --f-juridique:#71262f; --f-lancement:#7d5f87; --f-pilotage:#6f645a;
  --shadow:0 1px 0 rgba(42,35,31,.04),0 6px 18px -12px rgba(42,35,31,.25);
}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){
  --bg:#171413; --surface:#211c1a; --sunk:#1b1716; --ink:#efe7df; --muted:#b2a598; --faint:#85796e;
  --line:#352d29; --line-strong:#4a3f39; --accent:#e0939b; --accent-ink:#2a1013; --accent-soft:#3a2326;
  --ok:#9cc58f; --ok-soft:#24301f; --warn:#e2b064; --warn-soft:#352a17; --late:#ef9a74; --late-soft:#3a2219;
  --wait:#b3b1da; --wait-soft:#2a2938; --today:#ef9a74; --band:#241f1c; --chip-ink:#1b1716;
  --f-methode:#93b077; --f-contenus:#d9a955; --f-donnees:#e08458; --f-prototype:#7fb0c2;
  --f-code:#8d9fd6; --f-juridique:#e0939b; --f-lancement:#c3a2cc; --f-pilotage:#b5a899;
  --shadow:0 1px 0 rgba(0,0,0,.2),0 8px 20px -12px rgba(0,0,0,.6); color-scheme:dark;}}
:root[data-theme="dark"]{
  --bg:#171413; --surface:#211c1a; --sunk:#1b1716; --ink:#efe7df; --muted:#b2a598; --faint:#85796e;
  --line:#352d29; --line-strong:#4a3f39; --accent:#e0939b; --accent-ink:#2a1013; --accent-soft:#3a2326;
  --ok:#9cc58f; --ok-soft:#24301f; --warn:#e2b064; --warn-soft:#352a17; --late:#ef9a74; --late-soft:#3a2219;
  --wait:#b3b1da; --wait-soft:#2a2938; --today:#ef9a74; --band:#241f1c; --chip-ink:#1b1716;
  --f-methode:#93b077; --f-contenus:#d9a955; --f-donnees:#e08458; --f-prototype:#7fb0c2;
  --f-code:#8d9fd6; --f-juridique:#e0939b; --f-lancement:#c3a2cc; --f-pilotage:#b5a899;
  --shadow:0 1px 0 rgba(0,0,0,.2),0 8px 20px -12px rgba(0,0,0,.6); color-scheme:dark;}
*{box-sizing:border-box}
body{background:var(--bg);color:var(--ink);font:15px/1.55 "IBM Plex Sans",system-ui,-apple-system,"Segoe UI",sans-serif;
  padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px));padding-block:0 64px}
body::before{content:"";position:fixed;inset:0 0 auto;height:env(safe-area-inset-top,0px);z-index:10;background:var(--bg)}
h1,h2,h3{font-family:"Antic Didone",Georgia,"Times New Roman",serif;font-weight:400;text-wrap:balance;margin:0}
h1{font-size:clamp(30px,5vw,44px);line-height:1.1}
h2{font-size:clamp(24px,3.4vw,32px);line-height:1.15}
h3{font-size:20px;line-height:1.25}
p{margin:0}
a{color:var(--accent)}
.wrap{max-width:1180px;margin:0 auto}
.kicker{font-size:11.5px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);font-weight:600}
header.top{position:sticky;top:env(safe-area-inset-top,0px);z-index:20;background:var(--bg);border-bottom:1px solid var(--line);
  margin-left:calc(-1 * max(16px,env(safe-area-inset-left,0px)));margin-right:calc(-1 * max(16px,env(safe-area-inset-right,0px)));
  padding-block:10px;padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px))}
.topin{max-width:1180px;margin:0 auto;display:flex;gap:6px 14px;align-items:center;flex-wrap:wrap}
.brand{font-family:"Antic Didone",Georgia,serif;font-size:22px;white-space:nowrap}
.brand b{font-weight:400;color:var(--accent)}
nav.tabs{display:flex;gap:2px;flex-wrap:wrap}
nav.tabs a{text-decoration:none;color:var(--muted);font-size:13.5px;padding:4px 9px;border-radius:999px;border:1px solid transparent}
nav.tabs a:hover,nav.tabs a:focus-visible{color:var(--ink);border-color:var(--line)}
.state{margin-left:auto;font-size:12.5px;color:var(--muted)}
.etat2{display:none;margin-top:6px}
@media (max-width:700px){.state{display:none}.etat2{display:block}
  nav.tabs{flex-wrap:nowrap;overflow-x:auto;width:100%;scrollbar-width:none;-webkit-overflow-scrolling:touch}
  nav.tabs::-webkit-scrollbar{display:none}
  nav.tabs a{white-space:nowrap}
  .brand{font-size:19px}
  section,details.it{scroll-margin-top:96px}}
section{padding-top:40px;scroll-margin-top:110px}
.sechead{display:flex;align-items:baseline;gap:6px 14px;flex-wrap:wrap;margin-bottom:14px}
.sechead .note{color:var(--muted);font-size:13.5px;max-width:80ch}
.card{background:var(--surface);border:1px solid var(--line);border-radius:14px;box-shadow:var(--shadow);min-width:0}
.grid{display:grid;gap:14px}
.g3{grid-template-columns:repeat(auto-fit,minmax(260px,1fr))}
.g2{grid-template-columns:repeat(auto-fit,minmax(300px,1fr))}
.pad{padding:16px 18px}
.hero{margin-top:18px;display:grid;gap:14px;grid-template-columns:minmax(0,1.2fr) minmax(0,1fr)}
@media (max-width:860px){.hero{grid-template-columns:minmax(0,1fr)}}
.week{font-family:"Antic Didone",Georgia,serif;font-size:clamp(26px,4vw,36px);line-height:1.1;margin-top:4px}
.week small{display:block;font-family:"IBM Plex Sans",sans-serif;font-size:13px;color:var(--muted);margin-top:6px;line-height:1.45}
.dial{display:flex;gap:18px;align-items:center;flex-wrap:wrap}
.ring{width:112px;height:112px;border-radius:50%;display:grid;place-items:center;flex:none}
.ring span{width:84px;height:84px;border-radius:50%;background:var(--surface);display:grid;place-items:center;font:600 21px/1 "IBM Plex Sans",sans-serif;font-variant-numeric:tabular-nums}
.stats{display:grid;gap:8px;min-width:0;flex:1}
.stat{display:flex;justify-content:space-between;gap:12px;font-size:13.5px;border-bottom:1px dashed var(--line);padding-bottom:6px}
.stat b{font-variant-numeric:tabular-nums;font-weight:600;text-align:right}
.famrow{display:grid;grid-template-columns:minmax(0,1fr) 56px;gap:4px 10px;font-size:13.5px}
.famrow b{text-align:right;font-variant-numeric:tabular-nums;font-weight:600}
.famrow .bar{grid-column:1/-1}
.bar{height:6px;border-radius:99px;background:var(--sunk);overflow:hidden}
.bar i{display:block;height:100%;background:var(--c,var(--accent));border-radius:99px;width:0}
.list{list-style:none;margin:0;padding:0;display:grid;gap:8px}
.list li{display:flex;gap:10px;align-items:flex-start;font-size:14px;min-width:0}
.list li > span:last-child{min-width:0}
.tag{display:inline-block;font-size:11px;letter-spacing:.03em;padding:1px 7px;border-radius:99px;border:1px solid var(--line);color:var(--muted);white-space:nowrap;font-weight:500;vertical-align:1px}
.tag.toi{background:var(--accent-soft);color:var(--accent);border-color:transparent}
.tag.claude{background:var(--sunk)}
.tag.tiers{background:var(--wait-soft);color:var(--wait);border-color:transparent}
.tag.late{background:var(--late-soft);color:var(--late);border-color:transparent}
.tag.ok{background:var(--ok-soft);color:var(--ok);border-color:transparent}
.tag.warn{background:var(--warn-soft);color:var(--warn);border-color:transparent}
.idref{font-family:"IBM Plex Mono",ui-monospace,Menlo,monospace;font-size:12px;color:var(--muted);white-space:nowrap}
a.idref{color:var(--accent)}
.muted{color:var(--muted)}
.small{font-size:13px}
.boxt{font-size:12px;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);font-weight:600;margin-bottom:10px;display:flex;gap:8px;align-items:baseline;flex-wrap:wrap}
.boxt .n{font-variant-numeric:tabular-nums;color:var(--ink)}
.boxt .aside{text-transform:none;letter-spacing:0;font-weight:400}
.sub{font-size:12px;color:var(--muted);margin:12px 0 6px;font-weight:600}
.empty{color:var(--faint);font-size:13.5px;font-style:italic}
.banner{border-radius:12px;padding:10px 14px;font-size:13.5px;background:var(--warn-soft);color:var(--warn);margin-top:14px}
.banner.info{background:var(--sunk);color:var(--muted)}
.fam{margin-top:22px}
details.ch{background:var(--surface);border:1px solid var(--line);border-radius:14px;margin-bottom:10px;box-shadow:var(--shadow)}
details.ch > summary{list-style:none;cursor:pointer;padding:14px 16px;display:grid;grid-template-columns:auto minmax(0,1fr) auto;gap:12px;align-items:center}
details.ch > summary::-webkit-details-marker{display:none}
.chcode{font-family:"IBM Plex Mono",monospace;font-size:12px;font-weight:500;padding:3px 7px;border-radius:6px;color:var(--chip-ink);background:var(--c)}
.chname{font-family:"Antic Didone",Georgia,serif;font-size:20px;line-height:1.2}
.chmeta{font-size:12.5px;color:var(--muted)}
.chpct{font-variant-numeric:tabular-nums;font-weight:600;font-size:15px;text-align:right;min-width:52px}
.chbody{padding:0 16px 14px;display:grid;gap:8px}
@media (max-width:560px){.chbody{padding:0 10px 12px}}
.chdesc{color:var(--muted);font-size:14px;max-width:80ch}
details.it{border:1px solid var(--line);border-radius:10px;background:var(--bg);scroll-margin-top:110px}
details.it[open]{background:var(--surface)}
details.it > summary{list-style:none;cursor:pointer;padding:10px 12px;display:grid;grid-template-columns:auto minmax(0,1fr) auto;gap:10px;align-items:center}
details.it > summary::-webkit-details-marker{display:none}
.itid{font-family:"IBM Plex Mono",monospace;font-size:12.5px;color:var(--muted);min-width:42px}
.ittitle{font-weight:500;font-size:14.5px}
.itsub{font-size:12.5px;color:var(--muted)}
.itright{display:flex;gap:8px;align-items:center;font-size:12.5px;color:var(--muted);white-space:nowrap}
.mini{width:54px}
@media (max-width:560px){.mini{display:none}}
.itbody{padding:2px 12px 12px;display:grid;gap:12px}
.facts{display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(230px,1fr))}
.fact{font-size:13.5px;min-width:0}
.fact h4{margin:0 0 2px;font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);font-weight:600}
.why{font-size:13.5px;line-height:1.55;background:var(--sunk);border-radius:10px;padding:10px 12px}
.subs{list-style:none;margin:0;padding:0;display:grid;gap:2px}
.subs li{display:grid;grid-template-columns:auto minmax(0,1fr) auto;gap:10px;align-items:start;padding:7px 6px;border-radius:8px}
.subs li:hover{background:var(--sunk)}
.subs input{width:18px;height:18px;margin:2px 0 0;accent-color:var(--accent);cursor:pointer}
.subs input:disabled{cursor:not-allowed}
.subs .t{font-size:14px;cursor:pointer}
.subs li.done .t .tx{color:var(--muted);text-decoration:line-through;text-decoration-color:var(--line-strong)}
.subs .w{font-size:12px;color:var(--muted);text-align:right;white-space:nowrap}
@media (max-width:560px){.subs li{grid-template-columns:auto minmax(0,1fr)}.subs .w{grid-column:2;text-align:left}}
.subs .src{display:block;font-size:12px;color:var(--ok)}
.ph{font-size:10.5px;letter-spacing:.06em;text-transform:uppercase;font-weight:600;color:var(--wait)}
details.refs > summary{cursor:pointer;font-size:13px;color:var(--muted)}
.reftab{width:100%;border-collapse:collapse;font-size:12.5px;margin-top:6px}
.reftab td{border-top:1px solid var(--line);padding:6px;vertical-align:top}
.reftab td:first-child{white-space:nowrap;font-family:"IBM Plex Mono",monospace;color:var(--muted)}
.reftab .st{white-space:nowrap;color:var(--muted)}
.reftab .nt{display:block;color:var(--warn);margin-top:2px}
.tools{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:4px 0 6px}
.tools input[type=search]{flex:1 1 220px;min-width:0;padding:8px 12px;border-radius:10px;border:1px solid var(--line);background:var(--surface);color:var(--ink);font:inherit;font-size:14px}
.seg{display:inline-flex;border:1px solid var(--line);border-radius:10px;overflow:hidden}
.seg button{font:inherit;font-size:13px;padding:7px 11px;border:0;background:var(--surface);color:var(--muted);cursor:pointer}
.seg button[aria-pressed=true]{background:var(--accent);color:var(--accent-ink)}
.btn{font:inherit;font-size:13px;padding:7px 12px;border-radius:10px;border:1px solid var(--line);background:var(--surface);color:var(--ink);cursor:pointer}
.gwrap{display:grid;grid-template-columns:176px minmax(0,1fr);border:1px solid var(--line);border-radius:14px;background:var(--surface);overflow:hidden;box-shadow:var(--shadow)}
@media (max-width:560px){.gwrap{grid-template-columns:96px minmax(0,1fr)}.glab .gi .tt{display:none}}
.glab{border-right:1px solid var(--line);font-size:12px;min-width:0}
.glab div{height:22px;display:flex;align-items:center;padding:0 8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.glab .gh{font-weight:600;color:var(--ink);background:var(--sunk)}
.glab .gi{color:var(--muted)}
.glab .gi .idref{margin-right:6px;color:var(--ink)}
.gscroll{overflow-x:auto;overflow-y:hidden;min-width:0}
.gscroll svg{display:block}
.legend{display:flex;gap:6px 14px;flex-wrap:wrap;font-size:12.5px;color:var(--muted);margin:10px 2px 0}
.legend span{display:inline-flex;gap:6px;align-items:center}
.sw{width:18px;height:10px;border-radius:3px;display:inline-block}
.tbl{width:100%;border-collapse:collapse;font-size:13.5px}
.tbl th{font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);text-align:left;font-weight:600;padding:8px;border-bottom:1px solid var(--line-strong)}
.tbl td{padding:8px;border-bottom:1px solid var(--line);vertical-align:top}
.tbl td.num{font-variant-numeric:tabular-nums;white-space:nowrap}
.tscroll{overflow-x:auto;min-width:0}
.tscroll .tbl{min-width:620px}
.kpis{display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(170px,1fr))}
.kpi{padding:14px 16px}
.kpi .v{font-family:"Antic Didone",Georgia,serif;font-size:26px;line-height:1.15;margin:2px 0}
.kpi .l{font-size:12.5px;color:var(--muted)}
.steps{counter-reset:s;list-style:none;padding:0;margin:0;display:grid;gap:12px}
.steps li{counter-increment:s;display:grid;grid-template-columns:34px minmax(0,1fr);gap:12px;align-items:start;font-size:14.5px;max-width:86ch}
.steps li::before{content:counter(s);width:30px;height:30px;border-radius:50%;background:var(--accent-soft);color:var(--accent);display:grid;place-items:center;font-weight:600;font-size:13px}
.flash{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(18px + env(safe-area-inset-bottom,0px));background:var(--ink);color:var(--bg);padding:10px 16px;border-radius:10px;font-size:13.5px;z-index:30;max-width:min(92vw,560px)}
.qs{margin:0;padding-left:18px;display:grid;gap:7px;font-size:14px}
footer{margin-top:48px;color:var(--muted);font-size:12.5px;border-top:1px solid var(--line);padding-top:14px;max-width:110ch}
</style>

<header class="top"><div class="topin">
  <div class="brand"><b>Ficolia</b> · planning</div>
  <nav class="tabs" aria-label="Sections">
    <a href="#point">Où j'en suis</a><a href="#gantt">Gantt</a><a href="#chantiers">Chantiers</a>
    <a href="#envois">Envois</a><a href="#jalons">Jalons et verrous</a><a href="#simulation">Dates</a>
    <a href="#annexes">Annexes</a><a href="#reprendre">Reprendre</a>
  </nav>
  <div class="state" id="etat"></div>
</div></header>

<main class="wrap">
<section id="point" style="padding-top:26px">
  <div class="kicker">Planning du projet, de la méthode à la publication</div>
  <h1>Où j'en suis</h1>
  <p class="small muted etat2" id="etat2"></p>
  <div class="hero">
    <div class="card pad" id="pt-semaine"></div>
    <div class="card pad" id="pt-avancement"></div>
  </div>
  <div id="pt-alerte"></div>
  <div class="grid g3" style="margin-top:14px">
    <div class="card pad" id="pt-cette"></div>
    <div class="card pad" id="pt-tiers"></div>
    <div class="card pad" id="pt-retard"></div>
  </div>
  <div class="grid g2" style="margin-top:14px">
    <div class="card pad" id="pt-prochaine"></div>
    <div class="card pad" id="pt-questions"></div>
  </div>
</section>

<section id="gantt">
  <div class="sechead"><h2>Gantt</h2><span class="note" id="g-note"></span></div>
  <div class="gwrap"><div class="glab" id="g-lab"></div><div class="gscroll" id="g-scroll"></div></div>
  <div class="legend" id="g-leg"></div>
</section>

<section id="chantiers">
  <div class="sechead"><h2>Chantiers</h2><span class="note" id="ch-note"></span></div>
  <div class="tools">
    <input type="search" id="q" placeholder="Chercher (item, tâche, T-xxx, D-xxx…)" aria-label="Chercher dans les chantiers">
    <div class="seg" role="group" aria-label="Filtre">
      <button data-f="tout" aria-pressed="true">Tout</button><button data-f="afaire" aria-pressed="false">À faire</button><button data-f="fait" aria-pressed="false">Commencé</button>
    </div>
    <button class="btn" id="ouvrir">Tout déplier</button>
  </div>
  <div id="ch-list"></div>
</section>

<section id="envois">
  <div class="sechead"><h2>Envois au toxicologue</h2><span class="note">Au plus un envoi par semaine à partir du 23/11 ; il les traite dans l'ordre d'envoi. Dates au plus tôt, à recalculer avec la cadence mesurée (T-236).</span></div>
  <div class="card tscroll"><table class="tbl" id="env-tab"></table></div>
  <p class="small muted" id="env-note" style="margin-top:10px;max-width:100ch"></p>
</section>

<section id="jalons">
  <div class="sechead"><h2>Jalons et verrous</h2><span class="note">Jalons proposés le 20/10, sous réserve de T-521 ; aucun n'est daté avant la cadence mesurée (T-236). Les dates ci-dessous sont des estimations.</span></div>
  <div class="card tscroll"><table class="tbl" id="jal-tab"></table></div>
  <h3 style="margin-top:22px">Verrous de publication</h3>
  <div class="card tscroll" style="margin-top:10px"><table class="tbl" id="ver-tab"></table></div>
  <p class="small muted" id="ver-maintien" style="margin-top:10px;max-width:100ch"></p>
</section>

<section id="simulation">
  <div class="sechead"><h2>Dates estimées</h2><span class="note">Une estimation pour s'orienter, pas un jalon (T-236).</span></div>
  <div class="kpis" id="sim-kpis"></div>
  <div class="grid g2" style="margin-top:14px">
    <div class="card pad"><div class="boxt">Ce qui fait bouger la date (scénario central)</div><div class="tscroll"><table class="tbl" id="sim-var" style="min-width:0"></table></div></div>
    <div class="card pad"><div class="boxt">Charge par semaine, scénario central</div><div id="sim-charge"></div></div>
  </div>
  <div class="card pad" style="margin-top:14px"><div class="boxt">Hypothèses et limites</div><ul class="qs" id="sim-lim"></ul></div>
</section>

<section id="annexes">
  <div class="sechead"><h2>Annexes</h2></div>
  <details class="ch" open><summary><span class="chcode" style="--c:var(--f-pilotage)">HP</span><div style="min-width:0"><div class="chname">Hors plancher, V2, dehors</div><div class="chmeta" id="ax-hors-meta"></div></div><span></span></summary><div class="chbody"><p class="chdesc">Ces tâches du registre ne vont pas jusqu'à la publication. Elles restent ouvertes, hors du pourcentage. Les tâches de la contribution photo, rattachées à titre provisoire, sont dans les chantiers.</p><div class="tscroll"><table class="tbl" id="ax-hors"></table></div><h3 style="margin-top:12px">Tâches scindées</h3><p class="chdesc">Chaque tâche scindée a une part au plancher, rattachée à un item, et une autre part (hors plancher, V2 ou reportée), rappelée ici.</p><div class="tscroll"><table class="tbl" id="ax-sc"></table></div></div></details>
  <details class="ch"><summary><span class="chcode" style="--c:var(--f-pilotage)">20/10</span><div style="min-width:0"><div class="chname">Plan du 20/10 : 21 actions et 59 barres</div><div class="chmeta">Sort de chaque élément (Drive : « Plan jusqu'au lancement », « Détail du Gantt »)</div></div><span></span></summary><div class="chbody"><div class="tscroll"><table class="tbl" id="ax-act"></table></div><div class="tscroll"><table class="tbl" id="ax-bar" style="margin-top:12px"></table></div></div></details>
  <details class="ch"><summary><span class="chcode" style="--c:var(--f-pilotage)">16/09</span><div style="min-width:0"><div class="chname">Feuille de route du 16/09 : 48 lots et 5 jalons</div><div class="chmeta">« Nouvelle vision » (projet) et Gantt du 16/09 (Drive) ; T-521 parle de « PLAN-01 à PLAN-23 », le document lui-même compte 48 lots</div></div><span></span></summary><div class="chbody"><div class="tscroll"><table class="tbl" id="ax-lot"></table></div></div></details>
  <details class="ch"><summary><span class="chcode" style="--c:var(--f-pilotage)">04</span><div style="min-width:0"><div class="chname">Gantt d'avril : 9 phases</div><div class="chmeta">« GANTT v4 », mai 2026 → juin 2027 (Drive)</div></div><span></span></summary><div class="chbody"><div class="tscroll"><table class="tbl" id="ax-pha"></table></div></div></details>
</section>

<section id="reprendre">
  <div class="sechead"><h2>Reprendre après une absence</h2></div>
  <div class="card pad"><ol class="steps" id="rep"></ol></div>
</section>
<footer id="pied"></footer>
</main>

<script type="application/json" id="plan">__DATA__</script>
<script>
(function(){
"use strict";
const P = JSON.parse(document.getElementById("plan").textContent);
const DAY = 864e5;
const L0 = new Date(P.meta.lundi0 + "T00:00:00");
const IT = {}, SUB = {}, CH = {};
P.items.forEach(i => { IT[i.id] = i; (CH[i.ch] = CH[i.ch] || []).push(i); i.sous.forEach(s => { s.item = i.id; SUB[s.id] = s; }); });
const FAM_OF = {}; P.familles.forEach(f => f.ch.forEach(c => { FAM_OF[c] = f; }));
let COCHES = {};
let db = null, peut = null, etatDb = "attente";
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const esc = t => String(t == null ? "" : t).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const lundi = w => new Date(L0.getTime() + w * 7 * DAY + 3 * 3600e3);
const two = n => String(n).padStart(2, "0");
const dm = d => two(d.getDate()) + "/" + two(d.getMonth() + 1);
const dmy = d => dm(d) + "/" + d.getFullYear();
const dmyy = d => dm(d) + "/" + String(d.getFullYear()).slice(2);
const MOIS = ["janv.","févr.","mars","avr.","mai","juin","juil.","août","sept.","oct.","nov.","déc."];
const moisAn = d => MOIS[d.getMonth()] + " " + d.getFullYear();
const semDu = w => "sem. du " + (lundi(w).getFullYear() === 2026 ? dm(lundi(w)) : dmyy(lundi(w)));
const frDate = s => s ? s.split("-").reverse().join("/") : "";
function aujourdHui(){ const d = new Date(); d.setHours(0,0,0,0); return d; }
function wCour(){ return Math.floor(Math.round((aujourdHui() - L0) / DAY) / 7); }   /* jours arrondis : insensible au changement d'heure */
const iso = d => d.getFullYear() + "-" + two(d.getMonth() + 1) + "-" + two(d.getDate());
const fait = id => !!(COCHES[id] && COCHES[id].fait);
const wPlan = s => (s.sem !== null && s.sem !== undefined) ? s.sem : s.c;
const famVar = ch => "var(--f-" + FAM_OF[ch].id + ")";
const nb = (x, d) => String(d ? x.toFixed(d) : Math.round(x)).replace(".", ",");
function quiTag(q){
  const l = String(q).toLowerCase();
  if (l === "toi") return '<span class="tag toi">toi</span>';
  if (l === "claude") return '<span class="tag claude">Claude</span>';
  return '<span class="tag tiers">' + esc(q) + '</span>';
}
function flash(msg){ const f = document.createElement("div"); f.className = "flash"; f.setAttribute("role", "status"); f.textContent = msg; document.body.appendChild(f); setTimeout(() => f.remove(), 4500); }

/* Pourcentage, option A : ta charge cochée depuis le 27/10, chaque sous-tâche pesant ses heures (0,5 h au moins). */
function poids(filtre){ let t = 0, f = 0; P.items.forEach(i => { if (i.hors_pct || !filtre(i)) return; i.sous.forEach(s => { t += s.w; if (fait(s.id)) f += s.w; }); }); return {t, f, p: t ? 100*f/t : 0}; }
const pct = x => (x > 0 && x < 10 ? x.toFixed(1).replace(".", ",") : String(Math.round(x))) + " %";
const itemFait = i => i.sous.every(s => fait(s.id));
const itemPct = i => { const t = i.sous.reduce((a, z) => a + z.w, 0), f = i.sous.filter(z => fait(z.id)).reduce((a, z) => a + z.w, 0); return t ? 100*f/t : 0; };
const envoiFait = i => { const es = i.sous.filter(s => s.ph === "e"); return es.length ? es.every(s => fait(s.id)) : i.dep.every(d => IT[d] && itemFait(IT[d])); };
const retourFait = i => { const as = i.sous.filter(s => s.ph === "a"); return as.length > 0 && as.every(s => fait(s.id)); };
const retourCommence = i => i.sous.some(s => s.ph === "a" && fait(s.id));
/* Une sous-tâche « après retour » est bloquée tant que l'envoi de son item n'est pas coché. */
const bloquee = s => s.ph === "a" && !envoiFait(IT[s.item]);

function rendEtat(){
  const m = { attente: "coches : connexion…", ok: (peut === false ? "coches en lecture seule" : "coches enregistrées"), absent: "coches indisponibles dans cette vue", erreur: "coches : erreur de lecture" }[etatDb];
  $("#etat").textContent = $("#etat2").textContent = "État au " + P.meta.etat_au + " · registre " + P.meta.registre + " · " + m;
}

function liSub(s, extra){
  const i = IT[s.item];
  return '<li><a class="idref" href="#it-' + esc(i.id) + '">' + esc(s.id) + '</a><span>' + esc(s.t) +
    ' <span class="muted small">— ' + esc(i.titre) + '</span>' + (extra ? '<br>' + extra : '') + '</span></li>';
}
function rendPoint(){
  const w = wCour(), L = lundi(w), D = new Date(L.getTime() + 6*DAY);
  const tot = poids(() => true), hc = poids(i => !i.dev), co = poids(i => i.dev);
  const vLev = P.verrous.filter(v => (v.leve_par.length === 0 || v.leve_par.every(fait))).length;
  const datee = w >= 0 && w <= 3;
  let hSem = 0; P.items.forEach(i => { if (i.dev) return; i.sous.forEach(s => { if (!fait(s.id) && !bloquee(s) && wPlan(s) === w) hSem += s.h; }); });
  const cw = P.charge.find(c => c.w === w), capSem = cw && cw.cap_p > 0 ? Math.round(cw.cap_p) : P.meta.cap_projet;
  const jal = P.jalons.filter(j => !j.items.every(x => itemFait(IT[x]))).sort((a, b) => a.c - b.c)[0];
  $("#pt-semaine").innerHTML =
    '<div class="kicker">' + (w < 0 ? "Avant le planning" : "Semaine " + (w + 1) + " du planning") + '</div>' +
    '<div class="week">Du ' + dm(L) + ' au ' + dmy(D) +
    '<small>' + (w < 0 ? "Le planning commence le 26/10/2026." : datee ? "Semaine datée : le plan de cette semaine est précis." : "Au-delà des quatre semaines datées : le plan est estimé ; il est recalculé à chaque génération du registre.") + '</small></div>' +
    '<div class="stats" style="margin-top:14px">' +
    '<div class="stat"><span>Publication estimée, scénario central</span><b>' + moisAn(lundi(P.meta.pub.central)) + '</b></div>' +
    '<div class="stat"><span>Enveloppe (toutes charges basses ; toutes hautes)</span><b>' + moisAn(lundi(P.meta.pub.bas)) + ' – ' + moisAn(lundi(P.meta.pub.haut)) + '</b></div>' +
    '<div class="stat"><span>Prévu cette semaine (ton temps)</span><b>' + nb(hSem, 1) + ' h sur ' + (w >= 0 ? capSem : 0) + ' h</b></div>' +
    (jal ? '<div class="stat"><span>Prochain jalon estimé</span><b>' + esc(jal.id.replace("JALON-", "J")) + ' ' + esc(jal.nom) + ', ' + moisAn(lundi(jal.c)) + '</b></div>' : '') +
    '<div class="stat"><span>Verrous de publication levés</span><b>' + vLev + ' sur ' + P.verrous.length + '</b></div>' +
    '<div class="stat" style="border:0"><span>Chemin qui fixe la date</span><b class="idref" style="white-space:normal;color:var(--ink)">' + P.meta.chemin.slice().reverse().join(" → ") + '</b></div></div>';
  const fams = P.familles.map(f => { const x = poids(i => f.ch.includes(i.ch)); return '<div class="famrow"><span>' + esc(f.nom) + '</span><b>' + pct(x.p) + '</b><div class="bar" style="--c:var(--f-' + f.id + ')"><i style="width:' + x.p.toFixed(1) + '%"></i></div></div>'; }).join("");
  $("#pt-avancement").innerHTML = '<div class="boxt">Avancement <span class="aside">— ta charge cochée depuis le 27/10</span></div>' +
    '<div class="dial"><div class="ring" style="background:conic-gradient(var(--accent) ' + tot.p.toFixed(2) + '%, var(--sunk) 0)"><span>' + pct(tot.p) + '</span></div>' +
    '<div class="stats"><div class="stat"><span>Hors code</span><b>' + pct(hc.p) + '</b></div><div class="stat"><span>Code (ordre de grandeur)</span><b>' + pct(co.p) + '</b></div><div class="stat" style="border:0"><span>Heures cochées</span><b>' + nb(tot.f) + ' h sur ' + nb(tot.t) + '</b></div></div></div>' +
    '<div class="stats" style="margin-top:16px;gap:10px">' + fams + '</div>';
  let al = "";
  if (etatDb === "absent") al = '<div class="banner">Les coches ne sont pas disponibles dans cette vue (aperçu, ou page ouverte hors de ton compte). Ouvre la page depuis ton compte pour cocher.</div>';
  if (etatDb === "erreur") al = '<div class="banner">Les coches n\'ont pas pu être lues. Recharge la page ; si l\'erreur persiste, les pourcentages affichés sont faux.</div>';
  if (etatDb === "ok" && peut === false) al = '<div class="banner info">Lecture seule : les coches se font depuis le compte qui possède la page.</div>';
  if (w > 3) al += '<div class="banner info">La partie datée du planning (26/10 au 22/11) est passée : demande à Claude de mettre le planning à jour avec la dernière génération du registre.</div>';
  $("#pt-alerte").innerHTML = al;
  const cette = [], prochaine = [], retardD = [], glisse = [];
  P.items.forEach(i => i.sous.forEach(s => {
    if (fait(s.id) || bloquee(s)) return;
    const pw = wPlan(s);
    if (pw === w) cette.push(s);
    else if (pw === w + 1) prochaine.push(s);
    else if (pw < w) { if (s.sem !== null && s.sem !== undefined) retardD.push(s); else glisse.push(s); }
  }));
  const ordreCh = Object.keys(P.chantiers);
  const tri = (a, b) => (ordreCh.indexOf(IT[a.item].ch) - ordreCh.indexOf(IT[b.item].ch)) || a.id.localeCompare(b.id, "fr", {numeric: true});
  [cette, prochaine, retardD, glisse].forEach(x => x.sort(tri));
  const groupe = arr => {
    const g = [["toi", "À toi"], ["Claude", "Claude prépare, tu relis"]];
    let h = "";
    g.forEach(([k, lab]) => { const x = arr.filter(s => s.qui === k); if (x.length) h += '<div class="sub">' + lab + '</div><ul class="list">' + x.map(s => liSub(s)).join("") + '</ul>'; });
    const autres = arr.filter(s => s.qui !== "toi" && s.qui !== "Claude");
    if (autres.length) h += '<div class="sub">Autres</div><ul class="list">' + autres.map(s => liSub(s, quiTag(s.qui))).join("") + '</ul>';
    return h;
  };
  $("#pt-cette").innerHTML = '<div class="boxt">Cette semaine <span class="n">' + cette.length + '</span></div>' +
    (cette.length ? groupe(cette) : '<p class="empty">Rien de prévu cette semaine.</p>');
  const tiers = [];
  P.items.forEach(i => {
    if (!(i.tox || i.att)) return;
    if (envoiFait(i) && !retourCommence(i) && !itemFait(i)) {
      const es = i.sous.filter(s => s.ph === "e"), last = es.length ? COCHES[es[es.length - 1].id] : null;
      tiers.push('<li><a class="idref" href="#it-' + esc(i.id) + '">' + esc(i.id) + '</a><span>' + esc(i.envoi ? i.envoi[0] + " — " + i.envoi[1] : i.titre_long) +
        '<br><span class="small muted">chez : ' + esc(i.chez) + (last && last.le ? " · parti le " + esc(frDate(last.le)) : "") + (i.ret != null ? " · retour estimé " + semDu(i.ret) : "") + '</span></span></li>');
    }
  });
  const prochEnv = P.envois.filter(e => !envoiFait(IT[e.item])).slice(0, 3);
  $("#pt-tiers").innerHTML = '<div class="boxt">Chez un tiers <span class="n">' + tiers.length + '</span></div>' +
    (tiers.length ? '<ul class="list">' + tiers.join("") + '</ul>' : '<p class="empty">Rien n\'est chez un tiers d\'après tes coches.</p>') +
    '<div class="sub">Prochains envois au toxicologue</div>' + (prochEnv.length ? '<ul class="list">' +
    prochEnv.map(e => '<li><a class="idref" href="#it-' + esc(e.item) + '">' + esc(e.lab.replace("Envoi ", "n° ")) + '</a><span>' + esc(e.desc) + '<br><span class="small muted">' + (e.envoye <= 4 ? "" : "au plus tôt ") + semDu(e.envoye) + '</span></span></li>').join("") + '</ul>' : '<p class="empty">Tous les envois sont partis.</p>');
  $("#pt-retard").innerHTML = '<div class="boxt">En retard <span class="n">' + retardD.length + '</span></div>' +
    (retardD.length ? '<ul class="list">' + retardD.map(s => liSub(s, '<span class="tag late">prévu ' + semDu(s.sem) + '</span>')).join("") + '</ul>' : '<p class="empty">Rien de daté n\'est en retard.</p>') +
    (glisse.length ? '<details style="margin-top:12px"><summary class="small muted" style="cursor:pointer">' + glisse.length + ' sous-tâche' + (glisse.length > 1 ? "s" : "") + ' derrière l\'estimation (non datées)</summary><ul class="list" style="margin-top:8px">' + glisse.slice(0, 60).map(s => liSub(s, '<span class="tag warn">estimée ' + semDu(s.c) + '</span>')).join("") + '</ul>' + (glisse.length > 60 ? '<p class="small muted" style="margin-top:6px">… et ' + (glisse.length - 60) + ' autres : demande une mise à jour du planning.</p>' : '') + '</details>' : "");
  $("#pt-prochaine").innerHTML = '<div class="boxt">Semaine prochaine <span class="n">' + prochaine.length + '</span></div>' +
    (prochaine.length ? groupe(prochaine) : '<p class="empty">Rien de prévu.</p>');
  $("#pt-questions").innerHTML = '<div class="boxt">Questions ouvertes pour toi <span class="n">' + P.questions.length + '</span></div>' + (P.questions.length ? '<ol class="qs">' + P.questions.map(q => '<li>' + esc(q) + '</li>').join("") + '</ol>' : '<p class="empty">Aucune question ouverte.</p>');
}

function rendGantt(){
  const W = 13, H = 22, N = P.meta.fin_ex2.central + 3, wNow = wCour();
  const rows = [];
  Object.keys(P.chantiers).forEach(ch => { rows.push({h: true, ch}); (CH[ch] || []).forEach(i => rows.push({i})); });
  const top = 34, width = N * W, height = top + rows.length * H + 6;
  let s = '<svg xmlns="http://www.w3.org/2000/svg" width="' + width + '" height="' + height + '" role="img" aria-label="Diagramme de Gantt : un trait par item, du début à la fin estimée"><defs>__PATTERNS__' +
    '<pattern id="est" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(-45)"><line x1="0" y1="0" x2="0" y2="5" style="stroke:var(--surface)" stroke-width="1.6" opacity=".6"/></pattern></defs>';
  s += '<rect x="0" y="0" width="' + (4*W) + '" height="' + height + '" style="fill:var(--band)"/>';
  let lastM = -1, lastLab = -99, premier = true;
  for (let w = 0; w < N; w++) {
    const d = lundi(w);
    if (d.getMonth() !== lastM) {
      lastM = d.getMonth();
      s += '<line x1="' + w*W + '" y1="0" x2="' + w*W + '" y2="' + height + '" style="stroke:var(--line)"/>';
      const suiv = lundi(w + 3).getMonth() !== d.getMonth();   // mois coupé (moins de 3 semaines visibles) : pas de libellé
      if (w - lastLab >= 3 && !(w === 0 && suiv)) {
        s += '<text x="' + (w*W + 3) + '" y="13" font-size="10.5" style="fill:var(--muted)">' + MOIS[d.getMonth()] + (d.getMonth() === 0 || premier ? " " + String(d.getFullYear()).slice(2) : "") + '</text>';
        lastLab = w; premier = false;
      }
    }
  }
  rows.forEach((r, k) => {
    const y = top + k*H;
    if (r.h) { s += '<rect x="0" y="' + y + '" width="' + width + '" height="' + H + '" style="fill:var(--sunk)" opacity=".75"/>'; return; }
    const i = r.i, fam = FAM_OF[i.ch].id, col = "var(--f-" + fam + ")";
    const p = itemPct(i);
    const x0 = i.debut * W, x1 = (i.fin + 1) * W;
    const segs = (i.seg || []).map(z => (z[0] === "tox" ? "toxicologue" : esc(i.chez || "tiers")) + " " + semDu(z[1]) + " → " + semDu(z[2] + 1)).join(" ; ");
    s += '<g><title>' + esc(i.id + " " + i.titre_long + " — " + semDu(i.debut) + " → fin " + semDu(i.fin)) + (segs ? " ; attente : " + segs : "") + " ; " + pct(p) + ' coché</title>';
    s += '<rect x="' + x0 + '" y="' + (y + 6) + '" width="' + Math.max(W, x1 - x0) + '" height="10" rx="3" style="fill:' + col + '" opacity="' + (itemFait(i) ? .35 : .9) + '"/>';
    (i.seg || []).forEach(z => { const wx = z[1]*W, ww = Math.max(W, (z[2] - z[1] + 1) * W);
      s += '<rect x="' + wx + '" y="' + (y + 4) + '" width="' + ww + '" height="14" rx="3" style="fill:var(--surface);stroke:' + col + '"/><rect x="' + wx + '" y="' + (y + 4) + '" width="' + ww + '" height="14" rx="3" fill="url(#hz-' + fam + ')"/>'; });
    if (i.fin > 3) { const xs = Math.max(x0, 4*W); if (x1 > xs) s += '<rect x="' + xs + '" y="' + (y + 6) + '" width="' + (x1 - xs) + '" height="10" fill="url(#est)"/>'; }
    if (p > 0) s += '<rect x="' + x0 + '" y="' + (y + 18) + '" width="' + Math.max(2, (x1 - x0) * p / 100) + '" height="2.5" style="fill:var(--ok)"/>';
    if (i.envoye != null && i.tox) s += '<circle cx="' + (i.envoye*W + W/2) + '" cy="' + (y + 11) + '" r="3.4" style="fill:var(--surface);stroke:var(--wait)" stroke-width="1.8"/>';
    s += '</g>';
  });
  const pub = P.meta.pub.central, xp = (pub + 1) * W;
  s += '<line x1="' + xp + '" y1="18" x2="' + xp + '" y2="' + height + '" style="stroke:var(--accent)" stroke-dasharray="3 3"/><text x="' + (xp - 4) + '" y="29" font-size="10" text-anchor="end" style="fill:var(--accent)">publication estimée</text>';
  if (wNow >= 0 && wNow < N) { const xt = (wNow + (aujourdHui() - lundi(wNow) + 3*3600e3) / (7*DAY)) * W; s += '<line x1="' + xt + '" y1="18" x2="' + xt + '" y2="' + height + '" style="stroke:var(--today)" stroke-width="1.5"/><text x="' + (xt + 3) + '" y="29" font-size="10" style="fill:var(--today)">aujourd\'hui</text>'; }
  s += '</svg>';
  const sc = $("#g-scroll"), keep = sc.scrollLeft;
  sc.innerHTML = s;
  $("#g-lab").innerHTML = '<div style="height:' + top + 'px"></div>' + rows.map(r => r.h ? '<div class="gh">' + esc(r.ch + " · " + P.chantiers[r.ch].nom) + '</div>' : '<div class="gi" title="' + esc(r.i.titre_long) + '"><span class="idref">' + esc(r.i.id) + '</span><span class="tt">' + esc(r.i.titre) + '</span></div>').join("");
  $("#g-note").textContent = "Daté du 26/10 au 22/11 (bande claire) ; estimé ensuite, scénario central. Fais défiler horizontalement ; survole un trait pour le détail.";
  $("#g-leg").innerHTML = P.familles.map(f => '<span><i class="sw" style="background:var(--f-' + f.id + ')"></i>' + esc(f.nom) + '</span>').join("") +
    '<span><i class="sw" style="border:1px solid var(--muted);background:repeating-linear-gradient(45deg,var(--muted) 0 2px,transparent 2px 5px)"></i>attente d\'un tiers</span><span><i class="sw" style="border:1.8px solid var(--wait);border-radius:50%;width:9px;height:9px"></i>envoi au toxicologue</span><span><i class="sw" style="background:var(--ok);height:3px"></i>part cochée</span>';
  if (!sc.dataset.init) { sc.dataset.init = "1"; sc.scrollLeft = Math.max(0, (wNow - 2) * W); } else sc.scrollLeft = keep;
}

function refTable(i){
  if (!i.refs.length) return '<p class="small muted">Aucune entrée du registre n\'est rattachée à cet item : il porte une démarche de pilotage, une décision récente du bloc H ou un travail que le registre ne découpe pas encore.</p>';
  return '<details class="refs"><summary>Entrées du registre rattachées (' + i.refs.length + ')</summary><table class="reftab">' +
    i.refs.map(r => '<tr><td>' + esc(r.r) + '</td><td>' + esc(r.o) + (r.note ? '<span class="nt">' + esc(r.note) + '</span>' : "") + '</td><td class="st">' + esc(r.st) + (r.pe ? "<br>" + esc(r.pe) : "") + '</td></tr>').join("") + '</table></details>';
}
function subRow(s, i){
  const pw = wPlan(s), d = fait(s.id), c = COCHES[s.id];
  const quand = (s.sem !== null && s.sem !== undefined) ? semDu(s.sem) : (s.ph === "a" ? "au retour, " : "") + "au plus tôt " + semDu(pw);
  const ph = s.ph === "e" ? '<span class="ph">envoi · </span>' : s.ph === "a" ? '<span class="ph">après retour · </span>' : "";
  const charge = i.dev ? s.h + " h de code" : (s.h ? nb(s.h, s.h % 1 ? 1 : 0) + " h" : "");
  const txt = c ? (c.source ? "coché : " + c.source : (c.le ? "coché le " + frDate(c.le) : "")) : "";
  return '<li class="' + (d ? "done" : "") + '" data-sid="' + esc(s.id) + '"><input type="checkbox" id="c-' + esc(s.id) + '" data-sid="' + esc(s.id) + '"' + (d ? " checked" : "") + ((peut === false || !db) ? " disabled" : "") + '><label for="c-' + esc(s.id) + '" class="t">' + ph + '<span class="tx">' + esc(s.t) + '</span> ' + quiTag(s.qui) + (txt ? '<span class="src">' + esc(txt) + '</span>' : "") + '</label><span class="w">' + esc(quand) + (charge ? '<br>' + esc(charge) : "") + '</span></li>';
}
function itemBlock(i){
  const p = itemPct(i);
  const deps = i.dep.length ? i.dep.map(d => '<a href="#it-' + esc(d) + '" class="idref">' + esc(d) + '</a>').join(", ") : "—";
  const tdeps = i.tox_dep.length ? ' ; part au toxicologue après le retour de ' + i.tox_dep.map(d => '<a href="#it-' + esc(d) + '" class="idref">' + esc(d) + '</a>').join(", ") : "";
  const dates = (i.fin <= 3 ? "fini " + semDu(i.fin) : "fini au plus tôt " + semDu(i.fin)) + " · enveloppe " + moisAn(lundi(i.fin_bas)) + " – " + moisAn(lundi(i.fin_haut));
  const env = i.envoi ? '<div class="fact"><h4>Envoi au toxicologue</h4>' + esc(i.envoi[0] + " — " + i.envoi[1]) + ' · ' + (i.envoye <= 4 ? "" : "au plus tôt ") + semDu(i.envoye) + ', retour ' + semDu(i.ret) + '</div>'
    : (i.att ? '<div class="fact"><h4>Attente d\'un tiers</h4>' + esc(i.chez) + ' : environ ' + i.att + ' semaine' + (i.att > 1 ? "s" : "") + (i.ret != null ? ", retour estimé " + semDu(i.ret) : "") + '</div>' : "");
  return '<details class="it" id="it-' + esc(i.id) + '" data-item="' + esc(i.id) + '"><summary><span class="itid">' + esc(i.id) + '</span><span style="min-width:0"><span class="ittitle">' + esc(i.titre_long) + '</span><br><span class="itsub">' + esc(i.qui) + ' · ' + esc(dates) + '</span></span><span class="itright"><span class="ipct">' + pct(p) + '</span><span class="bar mini" style="--c:' + famVar(i.ch) + '"><i style="width:' + p.toFixed(1) + '%"></i></span></span></summary>' +
    '<div class="itbody"><div class="facts"><div class="fact"><h4>Quoi</h4>' + esc(i.quoi) + '</div><div class="fact"><h4>Fini quand</h4>' + esc(i.fini) + '</div><div class="fact"><h4>Dépend de</h4>' + deps + tdeps + '</div>' + env + '<div class="fact"><h4>Charge</h4>' + (i.dev ? nb(i.h_code) + " h de code (ordre de grandeur, à remplacer par le planning de développement)" : nb(i.h_projet, i.h_projet % 1 ? 1 : 0) + " h de ton temps, séances avec Claude comprises") + (i.hors_pct ? " · hors pourcentage" : "") + '</div></div>' +
    '<div class="why"><b>Pourquoi.</b> ' + esc(i.pourquoi) + '</div>' +
    '<ul class="subs">' + i.sous.map(s => subRow(s, i)).join("") + '</ul>' + refTable(i) + '</div></details>';
}
function rendChantiers(){
  let h = "";
  P.familles.forEach(f => {
    h += '<div class="fam" data-fam="' + esc(f.id) + '"><div class="boxt" style="color:var(--f-' + f.id + ')">' + esc(f.nom) + '</div>';
    f.ch.forEach(ch => {
      const c = P.chantiers[ch], items = CH[ch] || [];
      const hp = items.reduce((a, i) => a + i.h_projet, 0), hc = items.reduce((a, i) => a + i.h_code, 0);
      h += '<details class="ch" data-ch="' + esc(ch) + '"><summary><span class="chcode" style="--c:var(--f-' + f.id + ')">' + esc(ch) + '</span><div style="min-width:0"><div class="chname">' + esc(c.nom) + '</div><div class="chmeta">' + items.length + ' items · ' + nb(hp) + ' h' + (hc ? ' + ' + nb(hc) + ' h de code' : '') + '</div><div class="bar" style="margin-top:6px;--c:var(--f-' + f.id + ')"><i class="chbar"></i></div></div><span class="chpct">0 %</span></summary>' +
        '<div class="chbody"><p class="chdesc">' + esc(c.desc) + '</p>' + items.map(itemBlock).join("") + '</div></details>';
    });
    h += '</div>';
  });
  $("#ch-list").innerHTML = h;
  $("#ch-note").textContent = P.meta.n_ch + " chantiers, " + P.meta.n_items + " items, " + P.meta.n_sous + " sous-tâches. Coche chaque sous-tâche quand elle est faite ; la coche est enregistrée tout de suite.";
  $$("#ch-list input[type=checkbox]").forEach(cb => cb.addEventListener("change", () => basculer(cb.dataset.sid, cb.checked, cb)));
  majChantiers();
}
function majChantiers(){
  $$("#ch-list details.ch").forEach(d => {
    const items = (CH[d.dataset.ch] || []).filter(i => !i.hors_pct);
    let t = 0, f = 0; items.forEach(i => i.sous.forEach(s => { t += s.w; if (fait(s.id)) f += s.w; }));
    const p = t ? 100*f/t : 0; $(".chbar", d).style.width = p.toFixed(1) + "%"; $(".chpct", d).textContent = pct(p);
  });
  $$("#ch-list details.it").forEach(d => { const p = itemPct(IT[d.dataset.item]); $(".ipct", d).textContent = pct(p); $(".mini i", d).style.width = p.toFixed(1) + "%"; });
  $$("#ch-list .subs li").forEach(li => {
    const id = li.dataset.sid, cb = $("input", li), d = fait(id);
    li.classList.toggle("done", d);
    if (cb.dataset.pending !== "1") { cb.checked = d; cb.disabled = (peut === false || !db); }
    const c = COCHES[id], lab = $("label", li); let src = $(".src", lab);
    const txt = c ? (c.source ? "coché : " + c.source : (c.le ? "coché le " + frDate(c.le) : "")) : "";
    if (txt) { if (!src) { src = document.createElement("span"); src.className = "src"; lab.appendChild(src); } src.textContent = txt; } else if (src) src.remove();
  });
  filtrer();
}
let FILTRE = "tout";
function filtrer(){
  const q = ($("#q").value || "").trim().toLowerCase();
  $$("#ch-list details.it").forEach(d => {
    const i = IT[d.dataset.item];
    const txt = (i.id + " " + i.titre_long + " " + i.quoi + " " + i.pourquoi + " " + i.fini + " " + i.sous.map(s => s.id + " " + s.t).join(" ") + " " + i.refs.map(r => r.r + " " + r.o).join(" ")).toLowerCase();
    let ok = !q || txt.includes(q);
    if (FILTRE === "afaire") ok = ok && !itemFait(i);
    if (FILTRE === "fait") ok = ok && i.sous.some(s => fait(s.id));
    d.hidden = !ok;
    if (q && ok) d.open = true;
  });
  $$("#ch-list details.ch").forEach(d => { const vis = $$("details.it", d).some(x => !x.hidden); d.hidden = !vis; if (q && vis) d.open = true; });
  $$("#ch-list .fam").forEach(f => { f.hidden = !$$("details.ch", f).some(x => !x.hidden); });
}
async function basculer(sid, coche, el){
  if (!db) { el.checked = !coche; flash("Les coches ne sont pas disponibles dans cette vue."); return; }
  el.dataset.pending = "1"; el.disabled = true;
  try {
    const ref = db.collection("coches").doc(sid);
    if (coche) await ref.set({ fait: true, le: iso(aujourdHui()), par: "toi" });
    else await ref.delete();
  } catch (e) {
    el.checked = fait(sid);
    flash("Coche non enregistrée (" + ((e && e.code) || "erreur") + "). Réessaie dans un instant.");
  } finally { el.dataset.pending = ""; el.disabled = (peut === false); }
}

function rendEnvois(){
  const parDate = P.envois.slice().sort((a, b) => a.envoye - b.envoye || P.envois.indexOf(a) - P.envois.indexOf(b));
  const num = e => e.lab.replace("Envoi ", "n° ");
  const dep = P.envois.map((e, k) => { const avant = P.envois.slice(0, k).filter(x => x.envoye > e.envoye); return avant.length ? num(e) + " avant " + avant.map(num).join(" et ") : ""; }).filter(Boolean);
  $("#env-note").textContent = dep.length ? "Classés par date estimée. Le numéro est l'ordre prévu le 27/10 ; un envoi prêt plus tôt part avant un envoi qui ne l'est pas encore. Dans la simulation : " + dep.join(" ; ") + "." : "";
  $("#env-tab").innerHTML = '<thead><tr><th>N°</th><th>Contenu</th><th>Item</th><th>Envoi</th><th>Retour</th><th>Scénario haut</th><th>État</th></tr></thead><tbody>' +
    parDate.map(e => {
      const i = IT[e.item], parti = envoiFait(i), rendu = parti && retourFait(i);
      const etat = rendu ? '<span class="tag ok">rendu</span>' : parti ? '<span class="tag tiers">chez lui</span>' : '<span class="tag">à préparer</span>';
      return '<tr><td class="num">' + esc(e.lab) + '</td><td>' + esc(e.desc) + '</td><td><a class="idref" href="#it-' + esc(e.item) + '">' + esc(e.item) + '</a></td><td class="num">' + (e.envoye <= 4 ? "" : "≥ ") + dmyy(lundi(e.envoye)) + '</td><td class="num">' + dmyy(lundi(e.ret)) + '</td><td class="num muted">' + dmyy(lundi(e.envoye_haut)) + ' → ' + dmyy(lundi(e.ret_haut)) + '</td><td>' + etat + '</td></tr>';
    }).join("") + '</tbody>';
}
function rendJalons(){
  $("#jal-tab").innerHTML = '<thead><tr><th>Jalon</th><th>Ce qui doit être vrai</th><th>Items</th><th>Estimation</th><th>Coché</th></tr></thead><tbody>' +
    P.jalons.map(j => {
      let t = 0, f = 0; j.items.forEach(x => IT[x].sous.forEach(s => { t += s.w; if (fait(s.id)) f += s.w; }));
      return '<tr><td><b>' + esc(j.id) + '</b><br>' + esc(j.nom) + '</td><td>' + esc(j.txt) + '</td><td>' + linkItems(j.items) + '</td><td class="num">' + moisAn(lundi(j.c)) + '<br><span class="muted small">' + moisAn(lundi(j.b)) + ' – ' + moisAn(lundi(j.hh)) + '</span></td><td class="num">' + pct(t ? 100*f/t : 0) + '</td></tr>';
    }).join("") + '</tbody>';
  $("#ver-tab").innerHTML = '<thead><tr><th>Verrou</th><th>Ce qu\'il exige</th><th>Items</th><th>Levé par</th><th>État</th></tr></thead><tbody>' +
    P.verrous.map(v => { const lev = (v.leve_par.length === 0 || v.leve_par.every(fait));
      return '<tr><td><b>' + esc(v.id) + '</b></td><td>' + esc(v.txt) + '</td><td>' + linkItems(v.items) + '</td><td class="idref">' + (v.leve_par.length ? esc(v.leve_par.join(", ")) : "déjà levé") + '</td><td>' + (lev ? '<span class="tag ok">levé</span>' : '<span class="tag">fermé</span>') + '</td></tr>'; }).join("") + '</tbody>';
  $("#ver-maintien").innerHTML = "Verrous de maintien, à tenir après la publication : " + P.verrous_maintien.map(v => '<b>' + esc(v.id) + '</b> ' + esc(v.txt) + ' (' + linkItems(v.items) + ')').join(" ; ") + ".";
}

function rendSimu(){
  const m = P.meta;
  const k = [["Publication, scénario central", moisAn(lundi(m.pub.central)), "semaine du " + dmy(lundi(m.pub.central))],
             ["Toutes charges basses", moisAn(lundi(m.pub.bas)), "semaine du " + dmy(lundi(m.pub.bas))],
             ["Toutes charges hautes", moisAn(lundi(m.pub.haut)), "semaine du " + dmy(lundi(m.pub.haut))],
             ["Fin du premier mois publié", moisAn(lundi(m.fin_ex2.central)), "scénario central (EX-2, hors pourcentage)"],
             ["Charge restante", nb(m.h_projet) + " h", "de ton temps, plus " + nb(m.h_code) + " h de code"]];
  $("#sim-kpis").innerHTML = k.map(x => '<div class="card kpi"><div class="l">' + esc(x[0]) + '</div><div class="v">' + esc(x[1]) + '</div><div class="l">' + esc(x[2]) + '</div></div>').join("");
  $("#sim-var").innerHTML = '<thead><tr><th>Si…</th><th>Publication</th><th>Écart</th></tr></thead><tbody>' + P.variantes.map(v => '<tr><td>' + esc(v.libelle) + '</td><td class="num">' + moisAn(lundi(v.pub)) + '</td><td class="num">' + (v.delta <= 0 && v.delta >= -2 ? "≈ 0" : (v.delta > 0 ? "+" : "") + v.delta + " sem.") + '</td></tr>').join("") + '</tbody>';
  const C = P.charge, bw = 6, hgt = 90, mx = 20, L = 26;
  let s = '<div class="tscroll"><svg width="' + (C.length * bw + L + 4) + '" height="' + (hgt + 28) + '" role="img" aria-label="Charge hebdomadaire estimée, projet et code">';
  [0, 10, 18].forEach(v => { const y = hgt - v / mx * hgt + 6; s += '<line x1="' + (L - 2) + '" x2="' + (C.length*bw + L + 4) + '" y1="' + y + '" y2="' + y + '" style="stroke:var(--line)"/><text x="0" y="' + (y + 3) + '" font-size="9.5" style="fill:var(--muted)">' + v + ' h</text>'; });
  C.forEach((c, n) => { const x = L + n*bw, hp = c.projet / mx * hgt, hd = c.code / mx * hgt;
    s += '<g><title>' + semDu(c.w) + " : " + nb(c.projet, 1) + " h de projet, " + nb(c.code, 1) + ' h de code</title><rect x="' + x + '" y="' + (hgt - hp + 6) + '" width="' + (bw - 1) + '" height="' + hp + '" style="fill:var(--accent)" opacity=".85"/><rect x="' + x + '" y="' + (hgt - hp - hd + 6) + '" width="' + (bw - 1) + '" height="' + hd + '" style="fill:var(--f-code)" opacity=".85"/></g>';
    const d = lundi(c.w); if (d.getMonth() === 0 && d.getDate() <= 7) s += '<text x="' + x + '" y="' + (hgt + 22) + '" font-size="9.5" style="fill:var(--muted)">' + d.getFullYear() + '</text>'; });
  s += '</svg></div><div class="legend"><span><i class="sw" style="background:var(--accent)"></i>projet</span><span><i class="sw" style="background:var(--f-code)"></i>code</span></div>';
  $("#sim-charge").innerHTML = s;
  const lim = [
    "Heures : mes estimations, sous-tâche par sous-tâche, en comptant ton temps de séance pour ce que Claude prépare. Elles seront remplacées par des mesures : T-435 pour la transcription, T-325 pour le toxicologue, l'architecture technique et l'avis technique pour le code.",
    "Capacité : " + m.cap_projet + " h par semaine au minimum (ta réponse du 28/10 ; le partage entre projet et code peut varier), toutes en projet jusqu'à ce que le code puisse commencer, c'est-à-dire l'architecture technique (TE-2) et son planning de développement dédié (TE-3) finis ; ensuite " + m.cap_apres[0] + " h de projet et " + m.cap_apres[1] + " h de code. Un item reçoit au plus " + m.cap_item + " h par semaine, sauf s'il reste du temps une fois les autres servis.",
    "Toxicologue : disponible à partir du 23/11 ; au plus un envoi par semaine, traité dans l'ordre d'envoi ; une semaine par envoi (deux pour les fiches NB_nourrisson, ②-A et les textes), le double dans le scénario haut. Pas de trêve des fêtes dans les scénarios bas et central (ta réponse du 28/10 : « non pas nécessairement ») ; le scénario haut garde une trêve du 21/12 au 03/01.",
    "Juriste et autres tiers : délais supposés (rendez-vous trois semaines après la relance, note écrite quatre semaines après, avis technique six semaines, compte de publication quatre semaines).",
    "Enveloppe : « bas » prend toutes les charges basses à la fois, « haut » toutes les hautes et un second tour de validation du prompt grossesse (R2). Ce n'est pas un intervalle de probabilité.",
    "Ordre du travail : la simulation fait passer d'abord ce qui alimente la science et le toxicologue (« science d'abord »). Les deux règles testées qui font passer d'abord la plus longue chaîne restante (calcul du 28/10, 12 h 30) publieraient trois à quatre semaines plus tôt (février 2028), mais repousseraient d'un mois et demi à deux mois et demi les modèles candidats (JALON-02, fin mai ou fin juin au lieu de mi-avril 2027) et de cinq à six mois le cadre arbitré (JALON-01, novembre au lieu de juin 2027). Je garde « science d'abord » : les retours du toxicologue arrivent tôt, quand il est encore temps de corriger.",
    "Sensibilité : la simulation répartit les heures semaine après semaine par une règle simple. Les jalons intermédiaires bougent d'un mois ou plus pour de petits changements d'hypothèses (le 28/10, retirer la trêve des fêtes a reculé JALON-02 de mi-mars à mi-avril 2027, parce que des retours du toxicologue arrivés plus tôt passent avant l'audit de l'exposition, préalable de ②-A) ; la publication ne bouge que d'une à deux semaines. Ne retenir des jalons que l'ordre de grandeur.",
    "Heures non occupées : " + nb(P.charge.filter(c => c.w > 0 && c.w <= m.pub.central).reduce((a, c) => a + Math.max(0, c.cap_p - c.projet), 0)) + " h de projet et " + nb(P.charge.filter(c => c.w > 0 && c.w <= m.pub.central).reduce((a, c) => a + Math.max(0, c.cap_d - c.code), 0)) + " h de code d'ici la publication, surtout en fin de parcours, quand tout attend un tiers (juriste, store). La date dépend alors des tiers, pas de ton temps.",
    "Pourcentage (option A) : ta charge cochée depuis le 27/10, chaque sous-tâche pesant ses heures (0,5 h au moins). Les attentes de tiers ne pèsent rien. Il ne mesure pas l'avancement scientifique : regarde aussi les verrous et les envois. Il peut baisser quand des tâches s'ajoutent : le plancher en vigueur compte 272 tâches en v6.7, près de 300 si l'arbitrage du bloc H accepte toutes les propositions.",
    "Rattachements : " + m.n_rattachees + " tâches ouvertes du registre sont rattachées à un item (" + m.n_barres + " d'après les barres du plan du 20/10, " + m.n_manuel + " par mes choix, à relire), " + m.n_annexe + " sont en annexe, et les " + m.n_ouverts + " points ouverts sont tous rattachés. Seize rattachements sont provisoires : onze pour la contribution photo (décision de séance 86, à inscrire) et cinq tâches que le registre classe hors plancher ou dehors, à re-statuer avec la v6.8.",
    "Relectures : deux relectures de ma part et une revue indépendante (même famille de modèles) ; aucune revue humaine du calendrier."
  ];
  $("#sim-lim").innerHTML = lim.map(x => '<li>' + esc(x) + '</li>').join("");
}

function linkItems(arr){ return arr && arr.length ? arr.map(x => '<a class="idref" href="#it-' + esc(x) + '">' + esc(x) + '</a>').join(" ") : '<span class="muted">—</span>'; }
function rendAnnexes(){
  const A = P.annexes;
  $("#ax-hors-meta").textContent = A.hors.length + " tâches : " + [["Hors plancher", "hors plancher"], ["V2", "V2"], ["Dehors", "dehors"], ["Déjà tranchée", "déjà tranchée"]].map(c => A.hors.filter(a => a.cat === c[0]).length + " " + c[1]).join(", ");
  $("#ax-hors").innerHTML = '<thead><tr><th>Tâche</th><th>Statut</th><th>Énoncé</th></tr></thead><tbody>' + A.hors.map(a => '<tr><td class="idref">' + esc(a.r) + '</td><td>' + esc(a.cat) + '</td><td>' + esc(a.o) + (a.note ? '<br><span class="small muted">' + esc(a.note) + '</span>' : '') + '</td></tr>').join("") + '</tbody>';
  $("#ax-sc").innerHTML = '<thead><tr><th>Tâche</th><th>Périmètre au registre</th><th>Énoncé</th><th>Item</th></tr></thead><tbody>' + A.scindees.map(a => '<tr><td class="idref">' + esc(a.r) + '</td><td>' + esc(a.pe) + '</td><td>' + esc(a.o) + '</td><td>' + linkItems(a.items) + '</td></tr>').join("") + '</tbody>';
  const tab = (rows, head) => '<thead><tr><th>' + head + '</th><th>Intitulé</th><th>Sort</th><th>Où</th></tr></thead><tbody>' + rows.map(r => '<tr><td class="idref">' + esc(r.c) + '</td><td>' + esc(r.t) + '</td><td>' + esc(r.sort) + '</td><td>' + linkItems(r.items) + '</td></tr>').join("") + '</tbody>';
  $("#ax-act").innerHTML = tab(A.actions, "Action");
  $("#ax-bar").innerHTML = tab(A.barres, "Barre");
  $("#ax-lot").innerHTML = tab(A.lots, "Lot");
  $("#ax-pha").innerHTML = tab(A.phases, "Phase");
  const rep = [
    "Lis « Où j'en suis » : la semaine, ce qui t'attend, ce qui est chez un tiers, ce qui est en retard. Le pourcentage seul ne dit pas où en est la science : regarde aussi les envois et les verrous.",
    "Dans une conversation de ce projet, tape « point » : Claude lit tes coches et le registre, puis te donne le point de la semaine.",
    "Compare la date « état au », en haut de la page, avec la dernière génération du registre. Si le registre est plus récent, demande à Claude de mettre le planning à jour : c'est la règle depuis le 27/10.",
    "Pour reprendre un item, déplie-le : « Pourquoi » explique son rôle, « Fini quand » dit ce qu'il faut obtenir, et « Entrées du registre rattachées » liste les tâches avec leur énoncé et leur statut.",
    "Pour ce qui est chez le toxicologue ou la juriste, le tableau des envois et la carte « Chez un tiers » disent ce qui est parti, quand, et ce qui doit revenir.",
    "Les quatre premières semaines sont datées ; au-delà, les semaines sont « au plus tôt ». Après une longue absence, le plan daté est périmé : fais d'abord recalculer le planning.",
    "Où sont les sources : le registre (un seul, au projet), le fichier de travail du bloc H (claude/registre_travail/), les fichiers du tirage de la tranche 1 (claude/tirage_tranche1/), les anciens plans sur ton Drive (rappelés en annexe)."
  ];
  $("#rep").innerHTML = rep.map(x => '<li><span>' + esc(x) + '</span></li>').join("");
  $("#pied").textContent = "Planning généré le " + P.meta.genere + " à partir du registre " + P.meta.registre + ", du fichier de travail du bloc H (jusqu'à H12, 28/10), du tirage de la tranche 1, du plan du 20/10, de la feuille de route du 16/09 et du Gantt d'avril. " + P.meta.n_sous + " sous-tâches dans " + P.meta.n_items + " items. Les coches sont enregistrées dans la base de cette page ; elles survivent aux mises à jour du planning tant que les identifiants des sous-tâches ne changent pas.";
}

$$(".seg button").forEach(b => b.addEventListener("click", () => { FILTRE = b.dataset.f; $$(".seg button").forEach(x => x.setAttribute("aria-pressed", String(x === b))); filtrer(); }));
$("#q").addEventListener("input", filtrer);
$("#ouvrir").addEventListener("click", e => { const btn = e.currentTarget, open = btn.dataset.o !== "1"; $$("#ch-list details.ch").forEach(d => { if (!d.hidden) d.open = open; }); btn.dataset.o = open ? "1" : ""; btn.textContent = open ? "Tout replier" : "Tout déplier"; });
document.addEventListener("click", e => { const a = e.target.closest('a[href^="#it-"]'); if (!a) return; const d = document.getElementById(a.getAttribute("href").slice(1)); if (!d) return; d.hidden = false; let p = d.parentElement.closest("details"); while (p) { p.hidden = false; p.open = true; p = p.parentElement.closest("details"); } d.open = true; });

function majTout(){ rendEtat(); rendPoint(); majChantiers(); rendEnvois(); rendJalons(); rendGantt(); }
rendEtat(); rendPoint(); rendGantt(); rendChantiers(); rendEnvois(); rendJalons(); rendSimu(); rendAnnexes();

(async function connecter(){
  const c = window.claude;
  if (!c || typeof c.use !== "function") { etatDb = "absent"; majTout(); return; }
  try {
    const [d, u] = await Promise.all([c.use("db"), c.use("user")]);
    db = d;
    if (u) { try { peut = await u.can("data.write"); } catch (e) { peut = null; } }
    if (!db) { etatDb = "absent"; majTout(); return; }
    db.collection("coches").limit(1000).onSnapshot(snap => {
      const n = {}; snap.docs.forEach(x => { if (x.exists) n[x.id] = x.data(); });
      COCHES = n; etatDb = "ok"; majTout();
    }, err => { etatDb = "erreur"; majTout(); flash("Lecture des coches impossible (" + ((err && err.code) || "erreur") + ")."); });
  } catch (e) { etatDb = "absent"; majTout(); }
})();
})();
</script>
"""
html = HTML.replace("__PATTERNS__", PATTERNS).replace("__DATA__", data)
assert "__DATA__" not in html and "__PATTERNS__" not in html
open(os.path.join(OUT, "planning.html"), "w", encoding="utf-8").write(html)
print("planning.html", len(html.encode("utf-8")), "octets")
