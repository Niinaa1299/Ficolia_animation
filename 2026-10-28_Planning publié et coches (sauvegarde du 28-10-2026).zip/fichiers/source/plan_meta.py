# Métadonnées du planning Ficolia : envois, verrous, jalons, sort des anciens plans, coches initiales,
# questions ouvertes, limites. Importé par build_plan.py.

LUNDI0 = "2026-10-26"          # semaine 0
ETAT_AU = "28/10/2026, 12 h 45"   # état des faits repris dans la page
TOX_DEBUT = 4                  # le toxicologue reprend le 23/11 (semaine 4)
TOX_CONGES = [8, 9]            # trêve du 21/12 au 03/01 : scénario haut seulement (réponse du 28/10 : « non pas nécessairement »)
CAP_PROJET = 18                # h/semaine, au minimum (réponse du 28/10), toutes en projet jusqu'à TE-2 et TE-3
CAP_APRES = (10, 8)            # puis 10 h de projet et 8 h de code (dès TE-2 et TE-3 faits)
CAP_ITEM = 6                   # plafond d'heures par item et par semaine (projet)

# Ordre des envois au toxicologue accepté le 27/10 (question 6), puis la suite.
ENVOIS = [
    ("AL-4", "Envoi 1", "Tranche 1 de l'étalon allaitement (37 fiches), le 23/11"),
    ("GR-7", "Envoi 2", "Questions sur la grille et ②-G réduit (environ 30 questions)"),
    ("GR-5", "Envoi 3", "R1, une quarantaine d'ingrédients et environ 6 déjà notés"),
    ("AL-5", "Envoi 4", "Tranche 2 de l'étalon allaitement (14 à 22 produits)"),
    ("GR-11", "Envoi 5", "Complément grossesse"),
    ("AL-6", "Envoi 6", "Fiches NB_nourrisson et essai chronométré"),
    ("AL-7", "Envoi 6 bis", "Jeu de validation du prompt allaitement (40 ingrédients)"),
    ("AL-8", "Envoi 7", "②-A et ①-bis"),
    ("GR-10", "Envoi 8", "Échantillon de relecture des NB_grossesse"),
    ("GR-14", "Envoi 9", "Règles du module huiles essentielles"),
    ("CT-4", "Envoi 10", "Textes « ce qui est en cause »"),
]

VERROUS = [
    ("VERROU-1", "Ligne allaitement publiée seulement après la validation à l'aveugle du prompt allaitement et la comparaison à l'étalon (D-245)", ["AL-10.3"], ["AL-7", "AL-10"]),
    ("VERROU-2", "Criblage complet", ["RF-4.6"], ["RF-3", "RF-4"]),
    ("VERROU-3", "Zone de tétée évaluée seulement après NB_nourrisson et le succès de la strate mamelons et des ancres (D-245)", ["AL-10.3"], ["AL-6", "AL-10"]),
    ("VERROU-4", "Accessibilité : levé le 28/09 (D-107) ; reste à corriger la palette au registre", [], ["PR-3"]),
    ("VERROU-5", "Structure éditrice", ["JU-4.3"], ["JU-4"]),
    ("VERROU-6", "Assurance souscrite avant la publication", ["JU-5.2"], ["JU-5"]),
    ("VERROU-7", "Politique de support (réponses types)", ["EX-1.9"], ["EX-1"]),
    ("VERROU-8", "Politiques des stores relevées", ["PU-1.3"], ["PU-1"]),
    ("VERROU-12", "Ligne grossesse publiée seulement après la validation à l'aveugle du prompt, les contrôles du moteur et la comparaison aux étalons (D-290)", ["GR-12.4"], ["GR-9", "GR-12"]),
]
VERROUS_MAINTIEN = [
    ("VERROU-9", "Niveau d'API Android tenu à jour", ["TE-2", "TE-5"]),
    ("VERROU-10", "Reconduction annuelle du compte développeur (note de continuité, T-168)", ["PU-2", "EX-1"]),
    ("VERROU-11", "Aucun paramètre codé en dur (T-474)", ["MC-5", "TE-4"]),
]

JALONS = [
    ("JALON-01", "Cadre arbitré", "T-521 tranché ; réponses de la juriste versées ; accord avec le toxicologue ; politiques des stores relevées ; frontière du module HE ; périmètre du catalogue", ["PI-4", "JU-2", "JU-6", "PU-1", "GR-14", "CA-6"]),
    ("JALON-02", "Modèles candidats prêts", "Prompt grossesse validé ; étalon et complément rendus ; ②-A répondu, règles gelées ; prompt allaitement validé ; NB_nourrisson ; table v1 ; exposition auditée ; mesures sans tiers", ["GR-9", "AL-4", "AL-5", "GR-11", "AL-8", "AL-7", "AL-6", "MC-1", "MC-2", "CA-2"]),
    ("JALON-03", "Socle figé", "Notes des deux lignes ; criblage complet ; calibrations ; modèle figé ; avis technique ; financement", ["GR-10", "GR-12", "AL-10", "RF-4", "MC-5", "TE-1", "PI-6"]),
    ("JALON-04", "Version candidate testée", "Logiciel conforme au moteur de référence ; catalogue au seuil ; textes validés et relus ; revue de sécurité ; essai par des testeuses ; registre des traitements. Remplace « bêta fermée autorisée » : encore une proposition (T-521, T-508)", ["TE-6", "CA-7", "CT-4", "JU-8", "TE-7", "PR-5", "JU-7"]),
    ("JALON-05", "Décision de lancement", "Plancher en vigueur clos ou reporté par décision ; verrous levés ; compte ouvert ; marque déposée ; structure et assurance ; exploitation prête", ["PU-4", "PU-2", "JU-3", "JU-4", "JU-5", "EX-1"]),
]

# Coches initiales : faits établis avant la publication (source citée). ID = item.n (1-based).
COCHES_INITIALES = {
    "PI-1.1": ("2026-10-27", "ta réponse du 27/10, 21 h 39 : « tout ce qui est sur ce compte fait foi »"),
    "PI-2.1": ("2026-10-27", "tes réponses du 27/10, 21 h 39"),
    "PI-2.2": ("2026-10-28", "page publiée le 28/10"),
    "PI-3.1": ("2026-10-27", "27/10, 20 h 15 : « date de l'appel = jeudi dernier au soir » (H12)"),
    "GR-1.1": ("2026-10-28", "28/10, 9 h 51 : « Ok pour le dossier » (version 0.1, H12)"),
    "GR-1.2": ("2026-10-28", "27/10, 20 h 15 : « ok pour l'exception d-44 » ; étendue le 28/10, 7 h 47 (H12)"),
    "GR-2.1": ("2026-10-28", "questions 27 à 32 déposées le 28/10 (H12)"),
    "AL-1.1": ("2026-10-27", "27/10, 20 h 15 : « ok pour tout » ; revue critique adoptée le 28/10, 7 h 47 (H12)"),
    "AL-1.2": ("2026-10-28", "graine 13486541, 28/10, 8 h 01 (H12)"),
    "AL-1.3": ("2026-10-28", "gel, tirage unique et remplacements du 28/10 (H12)"),
    "AL-1.4": ("2026-10-28", "28/10, 8 h 28 : « 3. ok » (H12)"),
    "RF-1.1": ("2026-10-28", "fichiers reçus le 28/10, 7 h 47 (H12)"),
    "RF-1.2": ("2026-10-28", "empreintes consignées en H12 (28/10)"),
}

# Sort des 21 actions du plan du 20/10 (« Plan jusqu'au lancement », Drive).
ACTIONS_2010 = [
    (1, "Consigner l'envoi du dossier juriste v3 et noter la date de relance", "Fait : T-470 close le 16/10 ; la relance (T-418) est en JU-1.", ["JU-1"]),
    (2, "Envoi ① (chlorphénésine) mis à jour et envoyé seul, ou D-35 renégocié", "Remplacé : D-250 et D-251 (14/10) ; ①-bis part avec ②-A.", ["AL-8"]),
    (3, "Lancer l'avis technique extérieur et le devis de la revue de sécurité", "Repris.", ["TE-1", "PI-6"]),
    (4, "Vérifier les politiques de Google Play et de l'App Store", "Repris.", ["PU-1"]),
    (5, "Arbitrer ce plan en une séance (jalons, tests, compte, protocole HE, lecture du prompt, volume de textes, stores)", "Repris et réparti.", ["PI-4", "PU-2", "CA-4", "GR-1", "CT-4", "PU-1"]),
    (6, "Vérifier six faits (UPC-A, correspondance INCI ↔ CosIng et licence, formats, export de CosIng, annexe II)", "Repris ; T-591 (annexe II) close le 26/10 (H11).", ["RF-2"]),
    (7, "Écrire le budget dès le devis reçu", "Repris.", ["PI-6"]),
    (8, "Volet allaitement, blocs D puis E ; critères pré-enregistrés", "Fait pour les blocs D et E (13/10) ; pré-enregistrement en AL-2.", ["AL-2"]),
    (9, "Lire le prompt grossesse ; écrire le prompt allaitement v0", "Remplacé par le protocole du 26/10 : dossier des règles, puis correction en session vierge ; prompt allaitement en AL-7.", ["GR-1", "GR-8", "AL-7"]),
    (10, "Fiches NB_nourrisson ; trois baumes ; tirage du tiers réservé ; règle de D-219", "Tiers réservé tiré le 28/10 (tranche 1) ; le reste repris.", ["AL-1", "AL-6", "AL-2"]),
    (11, "Dépouiller Quid Tox et le brief 2B ; compléter et envoyer l'envoi ②", "Repris, envoi ② découpé selon D-250 : ②-G avant l'étalon, ②-A après.", ["GR-7", "AL-8"]),
    (12, "Préparer la séance : comparaison modèle / expert sur l'étalon grossesse", "Remplacé : D-287 interdit toute comparaison avant la clôture du complément ; protocole de validation du 26/10.", ["GR-12", "GR-3"]),
    (13, "Premier passage du test benchmark allaitement", "Repoussé : il attend des notes grossesse (C-251) et la clôture du complément (D-287).", ["AL-9"]),
    (14, "Séance « calibration — toxicologue » et essai chronométré", "Remplacé : la cadence se mesure sur la tranche 1 (D-239, T-325) ; l'essai part avec les fiches NB_nourrisson (D-201).", ["AL-4", "AL-6"]),
    (15, "Préparer les étalons (60 à 80 produits pour l'allaitement)", "Remplacé par D-239 (tranches de 37 puis 14 à 22, extension jusqu'à 80) et D-285 (complément).", ["AL-1", "AL-5", "GR-11"]),
    (16, "Recalculer le Gantt avec le débit mesuré, réviser les jalons", "Repris.", ["PI-2", "PI-4"]),
    (17, "Mesures sans tiers (transcription, OBF, nom et marque, volume de textes, statuts)", "Repris et réparti.", ["CA-2", "CT-4", "RF-3"]),
    (18, "Premier tour de test hors cible", "Repris.", ["PR-2"]),
    (19, "Prototype : valider les étapes 5 à 7, choisir l'échelle", "Repris.", ["PR-3"]),
    (20, "Audit de l'exposition (part sans toxicologue)", "Repris.", ["MC-2", "MC-3"]),
    (21, "Après la juriste : versement, accord, marque, structure, D-U-N-S, assurance, RGPD, salles de bains, tests", "Repris et réparti.", ["JU-2", "JU-6", "JU-3", "JU-4", "PU-2", "JU-5", "JU-7", "CA-5", "PR-4"]),
]

# Sort des 59 barres du Gantt du 20/10 (« Détail du Gantt », Drive).
BARRES_2010 = [
    ("EN1", "Envoi ① mis à jour et envoyé", "Remplacé (D-250, D-251) : ①-bis avec ②-A", ["AL-8"]),
    ("EN1W", "Réponse à l'envoi ①", "Remplacé (D-251)", ["AL-8"]),
    ("TX1", "Prompts grossesse et allaitement", "Remplacé par le protocole du 26/10", ["GR-1", "GR-8", "AL-7"]),
    ("TX2", "Envoi ② complété et envoyé", "Découpé selon D-250", ["GR-7", "AL-8"]),
    ("TXP", "Préparer la séance", "Remplacé (D-287)", ["GR-12"]),
    ("TXW", "Délai avant la séance", "Remplacé : pas de séance de calibration", ["AL-4"]),
    ("TX4", "Réponses à l'envoi ②", "Découpé selon D-250", ["GR-7", "AL-8"]),
    ("TX3", "Séance calibration toxicologue", "Remplacé : cadence mesurée sur la tranche 1", ["AL-4"]),
    ("ETP", "Préparer les étalons", "Remplacé par D-239 et D-285 ; tranche 1 tirée le 28/10", ["AL-1", "GR-11"]),
    ("TX8", "Étalons à l'aveugle", "Repris", ["AL-4", "AL-5", "GR-11"]),
    ("TX5", "NB_nourrisson, à la main", "Repris", ["AL-6"]),
    ("TX6", "Validation des deux prompts", "Repris", ["GR-9", "AL-7"]),
    ("TX7", "Prompts sur le référentiel", "Repris", ["GR-10", "AL-7"]),
    ("CAL", "Calibration, modèle figé", "Repris", ["GR-12", "AL-10", "MC-5"]),
    ("TX9", "Textes validés (toxicologue)", "Repris", ["CT-4"]),
    ("AL1", "Allaitement : blocs D et E", "Fait (13/10) ; pré-enregistrement en AL-2", ["AL-2"]),
    ("AL2", "Fiches NB_nourrisson, tirages", "Tiers réservé tiré le 28/10 ; fiches reprises", ["AL-1", "AL-6"]),
    ("BM1", "Test benchmark, premier passage", "Repoussé (C-251, D-287)", ["AL-9"]),
    ("AL3", "Allaitement : bloc G", "Fait (bloc G, 15 au 20/10) ; contenus et phrases repris", ["CT-2", "CT-1"]),
    ("DA1", "Mesures sans tiers", "Repris", ["CA-2"]),
    ("AVE", "Six faits à vérifier", "Repris ; T-591 close", ["RF-2"]),
    ("DA2", "Audit de l'exposition", "Repris", ["MC-2"]),
    ("DA4", "Dix salles de bains", "Repris", ["CA-5"]),
    ("DA3", "Criblage réglementaire", "Repris", ["RF-4"]),
    ("DA5", "Catalogue et transcription", "Repris", ["CA-7"]),
    ("PRH", "Premier tour de test hors cible", "Repris", ["PR-2"]),
    ("PR1", "Prototype : étapes 5 à 7", "Repris", ["PR-3"]),
    ("PR2", "Prototype : étape 8", "Repris", ["PR-3"]),
    ("PR3", "Tests avec des testeuses", "Repris", ["PR-4"]),
    ("VC", "Essai de la version candidate", "Repris", ["PR-5"]),
    ("CT1", "Inventaire et règles des textes", "Repris", ["CT-3"]),
    ("RES", "Resourcer les faits allaitement", "Repris", ["CT-2"]),
    ("CT2", "Rédiger « ce qui est en cause »", "Repris", ["CT-4"]),
    ("CT3", "Fiche méthode, CGU, store", "Repris ; le texte des stores passe en MK-4", ["CT-6", "MK-4"]),
    ("JU1", "Analyse de la juriste (attente)", "Repris", ["JU-1"]),
    ("POL", "Politiques des stores vérifiées", "Repris", ["PU-1"]),
    ("JU2", "Réponses intégrées, suites", "Repris ; la marque passe en JU-3", ["JU-2", "JU-3"]),
    ("JU3", "Structure éditrice", "Repris", ["JU-4"]),
    ("TXA", "Accord avec le toxicologue", "Repris", ["JU-6"]),
    ("JU4", "D-U-N-S, compte Play, assurance", "Repris", ["PU-2", "JU-5"]),
    ("RGP", "RGPD : registre et analyse", "Repris", ["JU-7"]),
    ("JU5", "Relecture des textes publics", "Repris", ["JU-8"]),
    ("LEG", "Revue juridique, version réelle", "Repris", ["JU-8"]),
    ("TE1", "Avis technique, devis sécurité", "Repris", ["TE-1"]),
    ("TE2", "Base, API, back-office", "Repris", ["TE-4"]),
    ("TE3", "Application Android", "Repris", ["TE-5"]),
    ("TE4", "Modèle figé intégré, testé", "Repris", ["TE-6"]),
    ("TE5", "Revue de sécurité extérieure", "Repris", ["TE-7"]),
    ("TE6", "Soumission Google Play", "Repris", ["PU-5"]),
    ("HE2", "Règles HE : frontière, rouge", "Repris, élargi au module entier (D-57, T-431)", ["GR-14"]),
    ("HE1", "Mesure des mentions fabricant", "Repris", ["CA-4"]),
    ("PI1", "Arbitrer ce plan et les jalons", "Repris", ["PI-4"]),
    ("FIN", "Budget et financement", "Repris", ["PI-6"]),
    ("PI2", "Arbitrage des sujets restants", "Repris", ["PI-5"]),
    ("ARC", "Arbitrer le thème catalogue", "Repris", ["CA-6"]),
    ("PI3", "Régénérer registre et documents", "Repris", ["PI-8"]),
    ("DEC", "Revue finale et décision", "Repris", ["PU-4"]),
    ("EX1", "Préparer l'exploitation", "Repris", ["EX-1"]),
    ("VEI", "Veille et révision des NB", "Repris", ["RF-5"]),
]

# Sort des 48 lots et 5 jalons du 16/09 (« registre du Gantt détaillé », Drive ; « nouvelle vision », projet).
LOTS_1609 = [
    ("PLAN-01", "Inventorier les acquis et preuves", "Absorbé par le registre et ce planning ; T-522 lit l'inventaire jamais ouvert", ["PI-4"]),
    ("PLAN-02", "Reformuler besoin, promesse et finalité", "Repris", ["MK-3", "CT-6"]),
    ("PLAN-03", "Assainir les études d'avril", "Repris (revendications bornées, T-534)", ["MK-2", "MK-3"]),
    ("PLAN-04", "Formaliser rôles et compétences manquantes", "Repris (accord avec le toxicologue)", ["JU-6"]),
    ("PLAN-05", "Traiter les alertes scientifiques déjà ouvertes", "Remplacé : D-35 renégociée par D-250 et D-251 ; appel du 22/10", ["GR-7", "AL-8"]),
    ("PLAN-06", "Préparer entretiens et panier d'usage", "Repris sous une autre forme (test hors cible, salles de bains)", ["PR-2", "CA-5"]),
    ("PLAN-07", "Conduire les premiers entretiens", "Repris sous une autre forme (tests avec la cible)", ["PR-4"]),
    ("PLAN-08", "Vérifier le benchmark et tester les parcours concurrents", "Repris", ["MK-2"]),
    ("PLAN-09", "Délimiter les trois modules du lancement", "Renvoyé à T-521 ; module HE en GR-14", ["PI-4", "GR-14"]),
    ("PLAN-10", "Obtenir un cadrage réglementaire précoce", "En cours : dossier v3-2 envoyé le 16/10", ["JU-1", "JU-2"]),
    ("JALON-01", "Périmètre et finalité arbitrés", "Réécrit le 20/10", ["PI-4"]),
    ("PLAN-11", "Tester la chaîne produit et les droits de données", "Repris", ["CA-2", "RF-2"]),
    ("PLAN-12", "Construire coût de maintien et modèle de financement", "Repris", ["PI-6"]),
    ("PLAN-13", "Sécuriser développement et expertises externes", "Repris (avis technique ; tu développes, D-93)", ["TE-1", "PI-6"]),
    ("PLAN-14A", "Auditer les sources et transcriptions d'exposition", "Repris", ["MC-2"]),
    ("PLAN-14", "Stabiliser le socle méthodologique commun", "Repris (T-380 en ②-A)", ["AL-8", "MC-3"]),
    ("PLAN-15", "Achever les tests du modèle grossesse existant", "Remplacé par le protocole du 26/10 et D-290", ["GR-3", "GR-9", "GR-12"]),
    ("PLAN-16", "Corriger et spécifier la branche grossesse", "Repris", ["GR-8", "GR-10"]),
    ("PLAN-17", "Construire le corpus allaitement", "Fait en grande partie (blocs A à G, octobre)", ["CT-2"]),
    ("PLAN-18", "Spécifier et éprouver le modèle allaitement", "Repris", ["AL-6", "AL-7", "AL-10"]),
    ("PLAN-19", "Consolider identité et données du module HE", "Repris", ["GR-14"]),
    ("PLAN-20", "Arbitrer règles HE selon usages et périodes", "Repris", ["GR-14"]),
    ("PLAN-21", "Tester le module HE et ses interactions", "Repris (cas de référence, logiciel)", ["GR-14", "TE-6"]),
    ("PLAN-22", "Concevoir le schéma de données et sa provenance", "Repris", ["TE-2"]),
    ("PLAN-23", "Constituer un catalogue pilote maîtrisé", "Repris ; « petit catalogue » renvoyé à T-521 (D-102)", ["CA-7", "PI-4"]),
    ("PLAN-23A", "Vérifier les statuts avant publication", "Repris (MESURE-3)", ["RF-3", "RF-4"]),
    ("PLAN-24", "Prototyper le parcours d'information", "Fait en grande partie (prototype, étapes 1 à 4 validées)", ["PR-3"]),
    ("PLAN-25", "Tester la compréhension des trois restitutions", "Repris", ["PR-2", "PR-4"]),
    ("PLAN-26", "Préspécifier le protocole de validation", "Fait (protocole du 26/10, D-292) ; pré-enregistrements à écrire", ["GR-4", "AL-2"]),
    ("JALON-02", "Trois modèles candidats et données prêts", "Réécrit le 20/10", ["GR-9", "AL-7"]),
    ("PLAN-27", "Évaluer sur le jeu réservé indépendant", "Repris", ["GR-9", "AL-7", "GR-12", "AL-10"]),
    ("PLAN-28", "Corriger, retester et figer le socle", "Repris", ["MC-5"]),
    ("PLAN-29", "Réserve de reprise scientifique", "Remplacé par l'enveloppe haute de la simulation et R2", ["GR-9"]),
    ("JALON-03", "Socle apte à l'intégration finale", "Réécrit le 20/10", ["MC-5"]),
    ("PLAN-30", "Définir architecture et spécifications techniques", "Repris", ["TE-2", "TE-3"]),
    ("PLAN-31", "Construire base, API et administration", "Repris", ["TE-4"]),
    ("PLAN-32", "Construire le parcours mobile accessible", "Repris", ["TE-5"]),
    ("PLAN-33", "Intégrer les trois moteurs versionnés", "Repris", ["TE-6"]),
    ("PLAN-34", "Étendre le catalogue selon couverture mesurée", "Repris", ["CA-7"]),
    ("PLAN-35", "Vérifier confidentialité, contrats et sécurité", "Repris", ["JU-7", "TE-7"]),
    ("PLAN-36", "Construire veille, corrections et retraits", "Repris", ["RF-5", "TE-4"]),
    ("PLAN-37", "Tester l'application de bout en bout", "Repris", ["TE-6", "PR-5"]),
    ("JALON-04", "Bêta fermée autorisée", "Remplacé (proposition) par « version candidate testée » : dimension 9, pas de bêta fermée ; à trancher dans T-521", ["PR-5", "PI-4"]),
    ("PLAN-38", "Conduire une bêta fermée des trois modules", "Écarté (dimension 9), sous réserve de T-521", ["PI-4"]),
    ("PLAN-39", "Corriger et refaire les tests affectés", "Repris", ["PR-5"]),
    ("PLAN-40", "Réserve de correction avant lancement", "Remplacé par l'enveloppe de la simulation", []),
    ("PLAN-41", "Obtenir la revue finale scientifique et juridique", "Repris", ["JU-8"]),
    ("PLAN-42", "Organiser exploitation, incidents et suppléance", "Repris", ["EX-1"]),
    ("PLAN-43", "Valider le financement de la continuité", "Repris", ["PI-6"]),
    ("PLAN-44", "Préparer contenu public et distribution limitée", "Repris", ["CT-6", "MK-4", "MK-6"]),
    ("JALON-05", "Go / no-go commun des trois modules", "Réécrit le 20/10", ["PU-4"]),
    ("PLAN-45", "Ouvrir progressivement au public", "Repris", ["PU-5"]),
    ("PLAN-46", "Surveiller et consolider après lancement", "Repris (premier mois)", ["EX-2"]),
]

# Sort des 9 phases du Gantt d'avril (« GANTT v4 », mai 2026 → juin 2027, Drive).
PHASES_AVRIL = [
    ("Phase 1", "Stratégie, étude de marché et cahier des charges", "Remplacée : la nouvelle vision du 16/09 suspend les comparatifs d'avril (PLAN-03) ; concurrence en MK-2", ["MK-2"]),
    ("Phase 2", "Setup technique (Flutter, Supabase…)", "Remplacée : choix techniques à l'architecture (TE-2)", ["TE-2"]),
    ("Phase 3", "Base de données INCI et validation médicale", "Reprise par toute la méthode (GR, AL, MC, RF) et le catalogue (CA)", ["GR-10", "AL-7", "RF-4", "CA-7"]),
    ("Phase 4", "Développement MVP, écrans et fonctionnalités", "Reprise (TE-4, TE-5) ; le comparateur reste en V2", ["TE-4", "TE-5"]),
    ("Phase 5", "Tests, bêta et publication stores", "Reprise sans bêta fermée (dimension 9)", ["PR-4", "PR-5", "PU-5"]),
    ("Phase 6", "Marketing, communauté et acquisition", "Reprise selon ta réponse du 27/10 : réseaux d'abord, maternités et presse ensuite ; nano-influenceuses reportées", ["MK-1", "MK-5"]),
    ("Phase 7", "Monétisation (premium, affiliation, B2B)", "Écartée : D-19 et D-45 (pas de péage sur le verdict, pas d'affiliation, pas d'argent des marques) ; pérennité en PI-6 (O-15)", ["PI-6"]),
    ("Phase 8", "Version 2 (comparateur, lecture photo, encyclopédie…)", "Renvoyée en V2 (annexe)", []),
    ("Phase 9", "Expansion européenne et financement", "Expansion écartée du chemin de lancement (nouvelle vision, 16/09) ; financement en PI-6", ["PI-6"]),
]

QUESTIONS_OUVERTES = []
# Réponses du 28/10, 12 h 40 : « le » ou « la » sans importance, on ne corrige pas ; réponse au brief
# « compléments » jointe dans la discussion « Préparation meeting toxicologue » (pour R1) ; liste des neuf retraits (PI-7).
# Réponses du 28/10, 12 h 30 : projet qui fait foi (« oui ce projet fait foi ») ; canevas : la copie ;
# 18 h au minimum, partage projet/code variable ; « la » toxicologue ; trêve « non pas nécessairement » ;
# budget « à définir » (PI-6, MK-1) ; brief compléments du 14/08 parti et répondu.
