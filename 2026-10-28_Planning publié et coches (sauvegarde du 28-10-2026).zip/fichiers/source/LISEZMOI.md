# Sources du planning Ficolia (état du 28/10/2026)

Ces fichiers régénèrent la page du planning. Ils sont joints à la page (dossier `source/`) parce que l'espace de travail d'une session est effacé à sa fin. Lecture depuis une autre session : outil Artifact, action `read`, `path` = `source/<fichier>`.

## Chaîne (Python 3, sans dépendance ; Node et Playwright pour l'aperçu)

1. `python3 -I parse_reg.py REGISTRE COUVERTURE OUT` → `taches.json`, `o_points.json`, `couverture.json`, `ecarts.json`
   - REGISTRE : le registre en vigueur, au projet (`claude/mamaCARE_Registre_Projet_…md`).
   - COUVERTURE : « Couverture du registre », document de ton Drive (état au 20/10/2026, depuis le registre du 13/10) : couverture de chaque élément ouvert par les barres du plan du 20/10. Non joint ici.
2. `python3 -I ossature.py OUT` → `ossature.json` : rattachement de chaque tâche ouverte et de chaque point ouvert à un item (barres du 20/10, puis dictionnaire `MANUAL`), rattachements provisoires (`PROVISOIRE`), vérifications (`VERIFS`), annexe (hors plancher, V2, dehors), tâches scindées. Le script s'arrête si une tâche ouverte n'est rattachée nulle part.
3. `python3 -I build_plan.py OUT` → `plan.json`, `plan_rapport.txt`. Items : `plan_items_1.py` (PI, GR, AL) et `plan_items_2.py` (MC à EX). Paramètres, envois, verrous, jalons, coches initiales, sort des anciens plans, questions : `plan_meta.py`. Règle d'ordre : variable `PLAN_POLITIQUE` (A « science d'abord » par défaut ; B et C pour comparer).
4. `python3 -I gen_page.py OUT` → `planning.html` et `plan_page.json`.
5. `node preview.js OUT` (avec `NODE_PATH` pointant vers Playwright) → captures et contrôles (coche, décoche, largeur téléphone, erreurs).
6. Republier `planning.html` au même lien, avec `plan_page.json` publié sous le nom `plan.json`. Les coches sont dans la base de la page (collection `coches`, un document par sous-tâche) : elles survivent à la republication.

`point.py` : calcul du point hebdomadaire (commande « point »), à partir de `plan.json` et des coches.

## À chaque nouvelle génération du registre

- Les tâches créées après le 20/10 (T-612 et suivantes) n'ont pas de barre : les rattacher dans `MANUAL` (ossature.py), sinon le script s'arrête.
- Ne jamais renuméroter une sous-tâche cochée : l'identifiant (`XX-n.m`) est la clé de la coche. Ajouter les nouvelles sous-tâches à la fin de l'item. Si une sous-tâche cochée doit disparaître, le dire à la porteuse et supprimer sa coche.
- Mettre à jour `ETAT_AU`, la version du registre (`registre=` dans build_plan.py), les semaines datées (champ semaine des sous-tâches, 0 à 3 à partir du lundi `LUNDI0`) et les questions ouvertes.
- Deux relectures de la page avant republication (consigne de la porteuse).

## Limites connues

- Heures : estimations, à remplacer par les mesures (T-435, T-325, architecture et avis technique pour le code).
- 220 rattachements sur 475 sont des choix de Claude (à relire) ; 16 sont provisoires.
- Le pourcentage (option A) mesure la charge cochée, pas l'avancement scientifique.
