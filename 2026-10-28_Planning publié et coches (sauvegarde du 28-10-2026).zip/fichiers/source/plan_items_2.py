# Données du planning Ficolia — partie 2 : MC, RF, CT, CA, PR, TE, JU, MK, PU, EX.
# Même format que plan_items_1. Items dev=True : heures des sous-tâches = heures de code.
# RÈGLE DE STABILITÉ : après publication, ne jamais réordonner ni supprimer une sous-tâche.

ITEMS2 = []


def I(id, titre, qui, quoi, pourquoi, fini, sous, dep=(), tox_dep=(), tox=0, att=0, retour_min=None,
      dev=False, inc="m", prio=5, debut=1, hors_pct=False):
    ITEMS2.append(dict(id=id, titre=titre, qui=qui, quoi=quoi, pourquoi=pourquoi, fini=fini,
                       sous=list(sous), dep=list(dep), tox_dep=list(tox_dep), tox=tox, att=att,
                       retour_min=retour_min, dev=dev, inc=inc, prio=prio, debut=debut, hors_pct=hors_pct))


# ======================================================================= MC
I("MC-1", "Table v1-calibration", "Claude, toi",
  "Exécuter la table des paramètres « v1-calibration » pour les deux lignes et écrire ses dérogations.",
  "D-235 : table des paramètres v1-calibration, datée, pour les deux lignes ; toute modification donne une nouvelle version et de nouveaux tests ; SED_ref 123,2 (tableau 3A du SCCS, 12e révision). T-594 : l'exécuter (ligne « Soin des mamelons », SED du soin intime, valeurs de D-232, libellés de D-233, motif de la DAp) ; préalable du premier passage du test benchmark (D-247). T-595 : dérogations à la règle des SED (spray solaire corps 123,18 au lieu de 300).",
  "Table exécutée pour les deux lignes, versionnée ; dérogations écrites.",
  [("Exécuter la table pour les deux lignes (T-594)", "Claude", 1.5, None, None),
   ("Écrire les dérogations aux SED (T-595)", "Claude", 0.5, None, None),
   ("Relire et valider la table", "toi", 2, None, None)],
  prio=3, inc="f")

I("MC-2", "Audit de l'exposition", "toi, Claude",
  "Nommer l'arbitre du volet exposition, corriger ce qui est faux dans les chiffres d'exposition et préparer les questions d'exposition de ②-A.",
  "T-42 : nommer un arbitre pour le volet exposition (la revendication « méthode validée par un toxicologue » en dépend, T-534). T-337 : « un rincé a un facteur sous 0,034 » est faux (maximum 0,2641). T-338 : la dichotomie rincé / non rincé n'ordonne pas l'exposition. T-339, T-340, T-333 : sources des SED et transcriptions. La nouvelle vision du 16/09 : une calibration ne prouve rien sur une exposition non auditée.",
  "Arbitre nommé ; chiffres, SED, surfaces et libellés corrigés ou écrits en limites ; catégories manquantes créées ; questions d'exposition prêtes pour ②-A.",
  [("Nommer l'arbitre du volet exposition (T-42)", "toi", 1, None, None),
   ("Corriger les chiffres faux et leurs reprises dans les documents (T-337, T-338)", "Claude", 1, None, None),
   ("Auditer SED, provenances, surfaces, libellés ; catégories manquantes (T-339, T-340, T-333, T-576, T-577)", "Claude", 3, None, None),
   ("Lister les questions d'exposition pour ②-A", "Claude", 1, None, None),
   ("Relire et décider", "toi", 5, None, None)],
  prio=3, inc="m")

I("MC-3", "Catégories et attributs", "Claude, toi",
  "Écrire la table de rattachement des catégories, le lexique de la zone de tétée et le champ rinçage.",
  "T-602 : table de rattachement (colonne « mentions », lavants, alias, brume autobronzante à reclasser), avec l'attribut « forme inhalable » distinct de la « voie inhalatoire dominante » (arbitrage 24, 27/10). T-603 : lexique de l'attribut « zone de tétée » (« tétée(s) », jamais « tété »). T-312 : catégories « à définir » (treize produits tirés validés le 28/10). O-2, T-14, T-445 : catégorie fine et rinçage dérivé.",
  "Table et lexique écrits et validés ; champ rinçage tranché.",
  [("Table de rattachement des catégories (T-602), avec l'attribut « forme inhalable »", "Claude", 1, None, None),
   ("Lexique de la zone de tétée (T-603)", "Claude", 1, None, None),
   ("Champ rinçage : catégorie fine et rinçage dérivé (T-14, T-445, O-2)", "Claude", 0.5, None, None),
   ("Relire et valider", "toi", 2.5, None, None)],
  prio=3, inc="f")

I("MC-4", "Moteur de référence et cas de test", "Claude, toi",
  "Construire le moteur de calcul de référence, hors application, et écrire comme tests les cas qu'il doit retrouver.",
  "Revue du 28/10, constat 4 : aucun item ne portait le moteur. D-247 met le « moteur de D-214 avec les contrôles de l'étape 9 » parmi les préalables du premier passage du test benchmark ; D-290 (2) exige ses contrôles automatiques ; D-289 calcule le tableau de basculement au gel des règles. T-593 : treize cas de référence allaitement (douze, plus le cas « FDA 2008 » ajouté le 13/10). T-441 : invariants. Ce moteur sert de référence au logiciel (TE-6), qui ne peut pas en tenir lieu.",
  "Moteur de référence versionné, ou existant identifié ; cas allaitement, tableau de basculement grossesse et invariants écrits comme tests, relus.",
  [("Chercher s'il existe déjà (classeur de calibration) ; sinon le construire, versionné, avec les contrôles de l'étape 9 (D-214)", "Claude", 3, None, None),
   ("Écrire les treize cas allaitement comme tests (T-593), cas du miel sous condition (AL-3)", "Claude", 1.5, None, None),
   ("Écrire le tableau de basculement grossesse comme tests (D-289)", "Claude", 1, None, None),
   ("Écrire les invariants (T-441)", "Claude", 0.5, None, None),
   ("Relire le moteur et les tests", "toi", 3, None, None)],
  dep=["AL-3", "MC-1"], prio=2, inc="m")

I("MC-5", "Modèle figé", "Claude, toi",
  "Figer le modèle après les deux calibrations : version datée, paramètres hors du code, verdicts estampillés.",
  "T-32 : versionner le modèle et estampiller les verdicts. T-474 : paramètres synchronisés, jamais codés en dur (seuils, SED de référence, planchers, statut de l'ingrédient non évalué). VERROU-11 (maintien) : aucun paramètre codé en dur.",
  "Version datée du modèle ; fichier de paramètres unique ; estampille définie ; validé.",
  [("Geler la version du modèle après GR-12 et AL-10", "Claude", 1, None, None),
   ("Fichier de paramètres synchronisé, jamais en dur (T-474, VERROU-11)", "Claude", 1, None, None),
   ("Définir l'estampille des verdicts (T-32)", "Claude", 0.5, None, None),
   ("Valider", "toi", 2, None, None)],
  dep=["GR-12", "AL-10"], prio=2, inc="f")

# ======================================================================= RF
I("RF-1", "Jeux de données figés", "toi, Claude",
  "Télécharger, dater et hacher les jeux de données officiels dont dépendent le tirage de R1 et le criblage.",
  "Protocole du 26/10 (étape 2) : le pool de R1 et R2 se construit sur des fichiers officiels figés ; le criblage (RF-3, RF-4) aussi. Reçus le 28/10 : annexes II à VI de CosIng (mise à jour du 13/10/2026) et tableau de l'annexe VI du CLP (ATP23, « unofficial » selon son avertissement), empreintes consignées en H12. Manquent : l'inventaire des ingrédients de CosIng (non exportable, base indisponible) et une source des classifications REACH (T-344).",
  "Fichiers téléchargés, datés, hachés, consignés ; manques écrits en limite ou comblés.",
  [("Télécharger les annexes de CosIng et le tableau de l'annexe VI du CLP (28/10)", "toi", 1, 0, None),
   ("Dater, hacher et consigner les fichiers (H12, 28/10)", "Claude", 0.5, 0, None),
   ("Identifier une source des classifications REACH (T-344), ou écrire la limite", "Claude", 0.5, 1, None),
   ("Réessayer l'export de l'inventaire de CosIng plus tard", "toi", 0.25, None, None)],
  prio=1, inc="f", debut=0)

I("RF-2", "Faits à vérifier", "Claude, toi",
  "Vérifier les faits en attente sur nos sources de données avant de s'en servir.",
  "T-437 : ouvrir le fichier de correspondance INCI ↔ CosIng d'Open Beauty Facts. T-481 : vérifier d'abord sa licence (si l'ODbL s'y applique, T-439 s'étend). T-486 : format d'export et conditions de réutilisation de CosIng. T-2 : convertir les 22 UPC-A en EAN-13. T-480 : les « trois formats » de code-barres et les codes 2D GS1.",
  "Chaque fait vérifié et versé au registre ; décision d'usage écrite.",
  [("Vérifier la licence du fichier d'OBF (T-481)", "Claude", 0.5, None, None),
   ("Ouvrir et décrire le fichier (T-437)", "Claude", 1, None, None),
   ("Établir les conditions de l'export de CosIng (T-486)", "Claude", 0.5, None, None),
   ("Codes-barres : UPC-A en EAN-13 (T-2), formats et codes 2D (T-480)", "Claude", 1, None, None),
   ("Décider de l'usage", "toi", 2, None, None)],
  dep=["RF-1"], prio=4, inc="f")

I("RF-3", "Comptage des statuts", "Claude",
  "Compter combien des 1 318 ingrédients portent un statut réglementaire ou font l'objet d'une procédure.",
  "T-344 : MESURE-3, trois strates par coût croissant ; « tient à lui seul les trois verrous de publication de T-345 à T-347 » ; non commencé. Premier appui (28/10, H12) : sur les libellés du benchmark, environ 1 380 noms distincts, dont 163 retrouvés dans une annexe et 37 dans le tableau de l'ECHA (23 dans les deux) ; plus de huit sur dix sans lien possible. S'y ajoute la synchronisation de la grille et du benchmark (T-288, T-290, T-326).",
  "MESURE-3 faite sur les trois strates ; grille et benchmark synchronisés ; résultat consigné.",
  [("Strate 1 : listes réglementaires (annexes du règlement cosmétique, CLP)", "Claude", 2, None, None),
   ("Strate 2", "Claude", 2, None, None),
   ("Strate 3", "Claude", 2, None, None),
   ("Synchroniser la grille et le benchmark (T-288, T-290, T-326)", "Claude", 2, None, None),
   ("Relire le comptage", "toi", 4, None, None)],
  dep=["RF-1"], prio=3, inc="m")

I("RF-4", "Criblage complet", "Claude, toi",
  "Établir l'état de criblage et l'origine du NB 0 de chaque ingrédient, avec un contrôle de justesse. Lève VERROU-2.",
  "T-345 : un NB 0 issu du criblage peut-il fonder un vert publié ? T-346 : volume d'attribution nécessaire pour publier. T-347 : l'exercice de concordance conditionne la publication (réponse de principe du 21/10, D-290). T-350, T-285 : état de criblage et origine du NB 0. Règles nano (T-487, T-315). T-308 : contrôle de justesse.",
  "Chaque ingrédient a son état de criblage et l'origine de son NB 0 ; contrôle de justesse fait ; T-345 à T-347 tranchés ; VERROU-2 levé.",
  [("État de criblage et origine du NB 0, ingrédient par ingrédient (T-350, T-285)", "Claude", 4, None, None),
   ("Règles nano (T-487)", "Claude", 2, None, None),
   ("Contrôle de justesse sur un échantillon tiré au hasard (T-308)", "Claude", 3, None, None),
   ("Trancher T-345, T-346 et T-347", "toi", 4, None, None),
   ("Relire le criblage", "toi", 12, None, None),
   ("Inscrire la levée de VERROU-2", "toi", 3, None, None)],
  dep=["RF-3", "GR-10"], prio=2, inc="F")

I("RF-5", "Veille et révision", "toi, toxicologue",
  "Fixer comment le référentiel reste à jour après la publication.",
  "T-242 : seuil long de péremption du référentiel (posé en ②-G). T-296, T-298, T-489 : cadence de veille et régime de révision des NB. T-23 et T-570 : relecture par tirage au hasard. O-5, O-14.",
  "Cadence de veille, régime de révision des notes et seuil de péremption écrits.",
  [("Intégrer la réponse du toxicologue sur la péremption (T-242)", "toi", 1, None, None),
   ("Écrire la cadence de veille et ses sources", "toi", 4, None, None),
   ("Écrire le régime de révision des notes (versions, tirage, cas douteux)", "toi", 5, None, None),
   ("Trancher les tâches de veille rattachées (T-29, T-31, T-38, T-55, T-61 et autres)", "toi", 4, None, None),
   ("Rédiger les règles retenues", "Claude", 2, None, None)],
  dep=["GR-7", "GR-10"], prio=4, inc="m")

# ======================================================================= CT
I("CT-1", "Phrases sous le verdict", "toi, Claude",
  "Écrire en une passe les phrases sous le verdict des deux lignes, une par cause du niveau.",
  "T-609 : réécrire les quatre phrases grossesse en langage courant (vraies sur tous les chemins, D-104 ; ni fréquence, ni quantité, ni durée, D-271), une phrase par cause plutôt qu'une par niveau ; un test informel des 17 et 18/10 les a montrées incomprises sans explication. T-604 : les phrases allaitement, par toi (D-277) ; relues par le toxicologue (J3, dans ②-A), puis par la juriste pour le niveau 4. T-371 : réécrire le jeu entier. T-528 : mention « ce que ça change ». H11 : le parfum à NB 1 (arbitrage 18) peut rendre un produit jaune sans « signal modéré » : la phrase du niveau 2 doit rester vraie sur ce chemin.",
  "Phrases des deux lignes écrites par cause, vraies sur tous les chemins (parfum compris) ; « ce que ça change » spécifiée ; prêtes pour le test hors cible et ②-A.",
  [("Inventaire des causes par niveau et par ligne, avec les chemins du moteur", "Claude", 1, 2, None),
   ("Écrire les phrases par cause, deux lignes, en une passe (à partir des candidates du 24 au 27/10)", "toi", 4, 2, None),
   ("Vérifier la phrase du niveau 2 sur le chemin du seul parfum (H11)", "Claude", 0.5, None, None),
   ("Spécifier la mention « ce que ça change » (T-528)", "Claude", 1, None, None),
   ("Relire l'ensemble et le figer pour le test hors cible", "toi", 2, None, None)],
  prio=2, inc="m", debut=2)

I("CT-2", "Bloc G", "Claude, toi",
  "Écrire les contenus du bloc G, vérifier ses sources et resourcer les faits du volet allaitement.",
  "T-605 : contenus du bloc G (condition savon sans fréquence, condition parfum, section « crevasses », item « signal poitrine »). T-606 : vérifier les sources (lettre de l'Afssaps 2011, arbitrage de l'EMA, ANAES 2002, Cochrane 2014). T-581 : resourcer à la source primaire les faits du document de reprise allaitement, lu pour l'essentiel par extraits.",
  "Contenus écrits ; sources vérifiées ; faits allaitement resourcés.",
  [("Rédiger les contenus du bloc G (T-605)", "Claude", 2, None, None),
   ("Vérifier les sources du bloc G (T-606)", "Claude", 2, None, None),
   ("Resourcer les faits du volet allaitement (T-581)", "Claude", 3, None, None),
   ("Relire et valider", "toi", 6, None, None)],
  prio=4, inc="m")

I("CT-3", "Inventaire et règles", "toi, Claude",
  "Dresser la liste fermée des textes du lancement et arbitrer leurs règles de rédaction.",
  "T-526 : aucune liste des textes du lancement n'existe (onboarding, libellés et phrases, états de non-verdict, panneau à quatre champs, textes Parfum et Non évalué…). T-533 : règles de rédaction des textes publics, à arbitrer une par une (aucun texte ne présuppose l'état de la lectrice ; aucun contenu ne pousse vers une catégorie de produit…). O-19, O-20 : classement des limites.",
  "Liste fermée ; règles arbitrées une par une ; syntaxe fixée ; limites classées.",
  [("Dresser la liste fermée des textes (T-526)", "Claude", 1.5, None, None),
   ("Arbitrer les règles de rédaction une par une (T-533)", "toi", 4, None, None),
   ("Fixer la syntaxe des textes (T-184, T-185, T-188)", "Claude", 1, None, None),
   ("Classer les limites (O-19, O-20)", "toi", 2, None, None),
   ("Inscrire", "toi", 1, None, None)],
  prio=3, inc="m")

I("CT-4", "« Ce qui est en cause »", "toi, Claude, toxicologue",
  "Écrire un texte « ce qui est en cause » pour chaque ingrédient à NB ≥ 1 du catalogue, après un texte témoin validé.",
  "D-68 : un ingrédient à NB ≥ 1 sans texte « ce qui est en cause » laisse le produit sans verdict (par ligne et par route, D-278). T-545 : mesurer le volume (ingrédients distincts à NB ≥ 1 du catalogue transcrit). T-471 : texte témoin validé par le toxicologue avant d'engager le volume ; protocole en T-540 (testeuses de la cible).",
  "Volume mesuré ; texte témoin validé et éprouvé ; un texte validé par ingrédient à NB ≥ 1 du catalogue.",
  [("Mesurer le volume (T-545)", "Claude", 1, None, None),
   ("Écrire le texte témoin sur le cas le plus difficile (T-471)", "toi", 3, None, None),
   ("Faire éprouver le texte témoin au test avec la cible (PR-4, protocole T-540)", "toi", 1, None, None),
   ("Rédiger les textes en volume (premier jet Claude, relecture toi)", "toi", 40, None, None),
   ("Envoyer les textes au toxicologue pour validation", "toi", 0.5, None, "e"),
   ("Intégrer ses corrections", "toi", 9.5, None, "a")],
  dep=["CT-3", "GR-10", "AL-7", "CA-7", "PR-4"], tox=2, prio=2, inc="F")

I("CT-5", "Méthodologie finale", "Claude, toi",
  "Écrire la méthodologie finale avec ses limites déclarées.",
  "T-601 et O-47 : y écrire les apports des blocs D à G (listes, critères et exclusions des éléments de la ligne allaitement, D-257 à D-262, qui remplacent le §5.3 du document de reprise ; M30 et M31). O-35 ; T-43, T-106, T-294, T-451.",
  "Méthodologie finale écrite, relue, limites déclarées.",
  [("Rédiger la méthodologie finale (T-601)", "Claude", 3, None, None),
   ("Écrire les limites déclarées", "Claude", 1, None, None),
   ("Relire et valider", "toi", 8, None, None)],
  dep=["GR-12", "AL-10"], prio=3, inc="m")

I("CT-6", "Textes publics", "toi, Claude",
  "Écrire la fiche méthode, les CGU, la politique de confidentialité, les mentions légales et la page « Bonnes pratiques ».",
  "T-543 : rédiger la politique de confidentialité depuis l'architecture réelle (T-264 n'en prévoit que la relecture). T-544 : mentions légales, qui dépendent de la structure (T-134). D-274 : page « Bonnes pratiques ». T-537 : menu. Le texte des stores est en MK-4.",
  "Les textes publics existent, conformes aux règles de CT-3, prêts pour la relecture de la juriste (JU-8).",
  [("Fiche méthode", "toi", 4, None, None),
   ("CGU", "toi", 4, None, None),
   ("Politique de confidentialité depuis l'architecture réelle (T-543)", "toi", 4, None, None),
   ("Mentions légales (T-544), après la structure", "toi", 1.5, None, None),
   ("Page « Bonnes pratiques » (D-274)", "toi", 3, None, None),
   ("Premiers jets et contrôle des règles de rédaction", "Claude", 5.5, None, None)],
  dep=["CT-3", "TE-2", "JU-4", "CT-5"], prio=3, inc="m")

# ======================================================================= CA
I("CA-1", "Collecte", "toi, Claude",
  "Finir et rapatrier la collecte du 25/10, l'étendre à un second circuit, la dédoublonner, puis en tirer les candidats de la tranche 2 et du complément.",
  "Ta réponse du 27/10 : la collecte alimente notre base, indépendamment des futures contributions et d'Open Beauty Facts ; commencée par les solaires, anti-vergetures et baumes mamelon d'une même pharmacie ; extraction sur un autre compte. Regroupement du 26/10 : 84 produits complets et 28 groupes dont seul le code-barres est lu. T-597 demande deux points de vente de circuits différents et exclut, pour l'étalon, après-solaires et gammes enfants. La transcription complète (ta réponse 8) remplace la règle « seuls les produits tirés » : à inscrire (PI-3). Listes extraites par une IA : à vérifier sur photo pour les produits tirés (D-247, T-501). Baumes nouveaux (Medela…) : hors de la tranche 1, dont la liste close est figée.",
  "Extraction rapatriée ici ; second circuit fait ; doublons réglés ; candidats proposés (exclusions de T-597 appliquées) ; listes des produits tirés vérifiées sur photo.",
  [("Finir l'extraction de la collecte du 25/10 (autre compte)", "toi", 4, None, None),
   ("Rapatrier ici le fichier extrait (voir PI-1)", "toi", 0.5, None, None),
   ("Collecter dans un second circuit (grande surface), selon la règle de T-597", "toi", 3, None, None),
   ("Dédoublonner avec le benchmark et l'onglet « INCI vérifiés » (deux produits hors benchmark compris)", "Claude", 1, None, None),
   ("Normaliser les INCI sur CosIng (T-574)", "Claude", 1, None, None),
   ("Proposer les candidats anti-vergetures et solaires corps (hors après-solaires et gammes enfants)", "Claude", 1, None, None),
   ("Vérifier sur photo la liste INCI des produits tirés (D-247, T-501)", "toi", 2, None, None)],
  prio=1, inc="m")

I("CA-2", "Mesures sans tiers", "toi, Claude",
  "Faire les mesures qui ne demandent personne : coût de transcription, fidélité d'OBF, nom et marque.",
  "T-1 : protocole de mesure, avec les seuils pré-enregistrés et leurs conséquences. T-435 : coût de transcription d'un produit, « le chiffre qui commande le lancement » (à 90 s, mille produits coûtent 25 h ; à 5 min, 83 h) ; la collecte en donne l'occasion. T-84 : transcription d'une contribution. T-516 : fidélité des listes INCI d'OBF sur au plus 30 produits, jamais mesurée.",
  "Protocole et seuils fixés d'avance ; mesures faites et consignées.",
  [("Protocole et seuils pré-enregistrés (T-1)", "Claude", 1, None, None),
   ("Valider le protocole", "toi", 1.5, None, None),
   ("Chronométrer la transcription d'une vingtaine de produits de la collecte (T-435, T-84)", "toi", 3, None, None),
   ("Mesurer la fidélité d'OBF sur 30 produits au plus (T-516)", "Claude", 2, None, None),
   ("Contrôler la mesure de fidélité", "toi", 2, None, None),
   ("Mesurer la qualité du champ nom et marque (T-6)", "Claude", 1, None, None),
   ("Synthèse et décision", "toi", 1.5, None, None)],
  prio=2, inc="m")

I("CA-3", "Listes INCI", "toi",
  "Choisir comment la base reçoit les listes INCI : photo en magasin et transcription, sites des marques, ou autre.",
  "T-518 : voie d'alimentation à trancher ; proposition du 21/10 (base d'une pharmacie) ; T-80 (sites des marques) et T-454, T-455 (API INCI) en annexe ; réserve de la dimension 4 rouverte le 22/10 (H10 bis). Les questions (a), (b), (c) de l'additif du 24/10 portent sur les photos d'emballages prises en magasin : la juriste y répond avant tout passage à grande échelle (JU-2).",
  "Voie choisie, avec son coût mesuré (CA-2) et son cadre juridique (JU-2).",
  [("Écrire les voies et leur coût", "Claude", 1, None, None),
   ("Trancher la voie et la proposition du 21/10", "toi", 3, None, None),
   ("Inscrire", "toi", 1, None, None)],
  dep=["CA-2", "JU-2"], prio=2, inc="f")

I("CA-4", "Mentions du fabricant", "toi, Claude",
  "Appliquer le protocole du 15/10 sur les mentions du fabricant et proposer un catalogue restreint.",
  "Protocole du 15/10 : 75 produits, cinq familles (barre HE1 du plan du 20/10, 12 à 36 h estimées). Il mesure ce que les mentions du fabricant disent de l'usage en grossesse ou en allaitement ; la règle de son §6 définit les familles à photo des précautions.",
  "Protocole appliqué aux 75 produits ; catalogue restreint proposé.",
  [("Relever les mentions sur les 75 produits", "toi", 12, None, None),
   ("Analyser les relevés", "Claude", 2, None, None),
   ("Proposer un catalogue restreint", "Claude", 1, None, None),
   ("Décider", "toi", 3, None, None)],
  prio=4, inc="m")

I("CA-5", "Dix salles de bains", "toi",
  "Mesurer le contenu réel de dix salles de bains de la cible pour fixer le seuil de couverture.",
  "T-515 : « donne p, donc la taille du catalogue » ; à faire avant de trancher les sources du catalogue (T-517 à T-519). T-563 : un seuil de couverture au lancement, que D-102 n'a pas chiffré. T-464 : cadre juridique des tests avec des femmes enceintes, à régler avant (question 7.8 du dossier juriste).",
  "Dix relevés faits ; seuil de couverture proposé (T-563).",
  [("Écrire le protocole de relevé", "Claude", 1, None, None),
   ("Recruter dix personnes de la cible", "toi", 3, None, "e"),
   ("Faire les relevés", "toi", 8, None, "a"),
   ("Analyser et proposer le seuil (T-563)", "Claude", 1, None, "a"),
   ("Valider le seuil proposé", "toi", 2, None, "a")],
  dep=["JU-2", "CA-2"], att=2, prio=2, inc="m")

I("CA-6", "Thème catalogue", "toi",
  "Trancher l'usage d'OBF, inscrire la contribution photo, fixer le seuil de couverture et les catégories du lancement.",
  "T-517 : OBF au lancement pour identifier et signaler la demande seulement, ou pour produire des verdicts ? T-519 : contribution photo au plancher ; retenue en séance le 07/10 (décision 86, qui fait monter au plancher T-400, T-415, T-89, T-84, T-82 et T-5) ; elle figure au dossier juriste v3-2 (partie 4). T-563 : seuil (CA-5). O-6, O-9, O-10, O-12, O-23, O-24.",
  "T-517 et T-519 tranchés et inscrits ; seuil et catégories tranchés.",
  [("Préparer les options et leurs conséquences", "Claude", 2, None, None),
   ("Trancher l'usage d'OBF (T-517)", "toi", 1.5, None, None),
   ("Inscrire T-519 et le statut des tâches de la file de contributions (si ce n'est pas fait en v6.8)", "toi", 1, None, None),
   ("Trancher le seuil et les catégories du lancement", "toi", 2, None, None),
   ("Inscrire", "toi", 0.5, None, None)],
  dep=["CA-2", "CA-5"], prio=2, inc="f")

I("CA-7", "Catalogue", "toi, Claude",
  "Constituer le catalogue jusqu'au seuil de couverture, avec une transcription contrôlée.",
  "T-501 : aucun taux d'erreur de transcription mesuré ; double transcription d'un échantillon et contrôle automatique des termes (D-77) ; « la transcription manuelle est la source de vérité du catalogue ». T-435 donne le coût unitaire ; la charge ci-contre suppose environ un millier de produits à 3 min et sera recalculée après CA-2 et CA-5.",
  "Catalogue au seuil ; échantillon transcrit deux fois ; taux d'erreur mesuré et sous le seuil fixé.",
  [("Transcrire les produits jusqu'au seuil", "toi", 55, None, None),
   ("Double transcription d'un échantillon (T-501)", "toi", 6, None, None),
   ("Contrôle automatique des termes et taux d'erreur", "Claude", 3, None, None),
   ("Corriger les erreurs relevées", "toi", 5, None, None),
   ("Contrôler la couverture atteinte", "toi", 4, None, None),
   ("Préparer l'import dans la base", "Claude", 2, None, None)],
  dep=["CA-6", "CA-3"], prio=2, inc="F")

# ======================================================================= PR
I("PR-1", "Canevas de référence", "toi",
  "Partir de la copie du canevas et traiter ce qui reste ouvert, y compris les commentaires restés sur l'original.",
  "Deux canevas existent : l'original, avec 101 commentaires dont 37 ouverts (et une question d'un tiers du 17/10 sans réponse), et une copie du 21/10. Ta réponse du 28/10 : on part de la copie, modifiée depuis sur l'autre compte puis retransférée ici. Les 37 commentaires ouverts restent sur l'original : les relever avant de l'abandonner, pour ne rien perdre. Écarts « contact » et « savon » avec les décisions des 19 et 20/10.",
  "Copie retenue ; commentaires ouverts de l'original relevés et traités ; écarts tranchés.",
  [("Choisir le canevas de référence : la copie (28/10)", "toi", 0.5, 2, None),
   ("Relever les 37 commentaires ouverts de l'original, dont la question d'un tiers du 17/10, et décider pour chacun : reporter dans la copie, traiter ou abandonner", "toi", 3, None, None),
   ("Préparer les réponses aux commentaires", "Claude", 1, None, None),
   ("Trancher les écarts « contact » et « savon »", "toi", 1, None, None)],
  prio=2, inc="f", debut=2)

I("PR-2", "Test hors cible", "toi",
  "Faire tester le prototype par cinq personnes hors de la cible, sans question de santé.",
  "Protocole du 20/10 (« Premier tour de test hors cible ») : cinq personnes, aucune donnée de santé, tâches et critères fixés à l'avance ; il n'attend pas la juriste (T-464) et éprouve les phrases sous le verdict (CT-1) avant ②-A et avant les tests avec la cible. Estimation du 20/10 : 10 à 26 h.",
  "Cinq tests passés selon le protocole ; phrases et repères corrigés au besoin.",
  [("Préparer les tâches et les critères (protocole du 20/10)", "Claude", 1, None, None),
   ("Recruter cinq personnes hors cible", "toi", 1, 3, None),
   ("Valider la préparation", "toi", 2, None, None),
   ("Passer les cinq tests", "toi", 5, None, None),
   ("Analyser les résultats", "Claude", 1, None, None),
   ("Lire l'analyse ; corriger phrases et repères", "toi", 3, None, None)],
  dep=["CT-1", "PR-1"], prio=2, inc="m")

I("PR-3", "Étapes 5 à 8", "toi, Claude",
  "Finir le prototype : étapes 5 à 7, échelle, contrôle final, puis inscription des décisions de séance.",
  "D-223 : les décisions de séance du prototype (102 au 08/10, numérotées jusqu'à 162 au 17/10) s'inscrivent à l'étape 8. D-107 : palette validée, correction restante au registre. T-373 : le design a été jugé « moche » ; une séance dédiée est prévue. T-365, T-366, T-368 : maquettes et prototypes à des états d'alignement différents.",
  "Étapes 5 à 7 validées ; échelle choisie ; séance de design faite ; contrôle final ; décisions inscrites ; palette corrigée.",
  [("Étape 5", "toi", 4, None, None),
   ("Étape 6", "toi", 4, None, None),
   ("Étape 7", "toi", 4, None, None),
   ("Préparer chaque étape et tenir la note de reprise", "Claude", 3, None, None),
   ("Choisir l'échelle", "toi", 1, None, None),
   ("Séance de design dédiée (T-373)", "toi", 4, None, None),
   ("Contrôle final du prototype", "Claude", 2, None, None),
   ("Valider le contrôle final", "toi", 2, None, None),
   ("Étape 8 : inscrire les décisions de séance au registre (D-223), palette de D-107 comprise", "Claude", 2, None, None),
   ("Valider l'inscription", "toi", 2, None, None)],
  dep=["PR-1"], prio=2, inc="m")

I("PR-4", "Tests avec la cible", "toi",
  "Faire tester la compréhension par des testeuses de la cible, selon des critères fixés d'avance.",
  "T-414 : recruter des testeuses de la cible. T-464 : cadre juridique à régler avant (recruter revient à recueillir des informations qui révèlent une grossesse). T-508 : forme du test (PI-4). T-398 : protocole complet (trois questions, épreuve de tri, critère d'acceptation, anti-contamination). T-541 : libellés de D-103. T-540 : texte témoin. Estimation du 20/10 : 15 à 40 h.",
  "Testeuses recrutées dans le cadre fixé ; tests passés ; compréhension jugée selon les critères pré-fixés.",
  [("Protocole et critères d'acceptation fixés d'avance (T-398, T-541, T-540)", "Claude", 1, None, None),
   ("Valider le protocole", "toi", 2, None, None),
   ("Recruter les testeuses (T-414)", "toi", 4, None, "e"),
   ("Passer les tests", "toi", 8, None, "a"),
   ("Analyser", "Claude", 1, None, "a"),
   ("Lire l'analyse ; décider des corrections", "toi", 4, None, "a")],
  dep=["JU-2", "PR-3", "PI-4"], att=2, prio=3, inc="m")

I("PR-5", "Version candidate", "toi",
  "Essayer la version réelle de l'application et faire corriger les anomalies critiques.",
  "JALON-04 proposé (« version candidate testée ») à la place de « bêta fermée autorisée », qui contredit la dimension 9 ; c'est encore une proposition, à trancher dans T-521 et T-508.",
  "Version réelle essayée ; anomalies critiques corrigées et vérifiées.",
  [("Essayer la version candidate", "toi", 4, None, None),
   ("Relever et trier les anomalies", "toi", 2, None, None),
   ("Vérifier les corrections", "toi", 2, None, None)],
  dep=["TE-6", "PR-4", "CA-7", "CT-4"], prio=2, inc="m")

# ======================================================================= TE
I("TE-1", "Avis technique", "toi",
  "Faire relire l'architecture par un regard technique extérieur et chiffrer la revue de sécurité.",
  "T-523 : identifier qui rendra l'avis technique extérieur et rédiger sa saisine (implémentation et coût de D-90, modes (b) et (c) de D-74, canal de correction rapide T-120, coût d'hébergement T-148) ; action 3 du 20/10 : y ajouter une estimation de la charge de développement, dont les heures ci-dessous ne sont qu'une hypothèse. D-90 : calcul côté serveur, aucun modèle sur le téléphone, cache de verdicts. D-74 : OBF interrogé depuis le serveur ou par import, jamais depuis le téléphone. T-514 : chiffrer la revue de sécurité.",
  "Relecteur identifié ; saisine envoyée avec l'architecture ; avis rendu et intégré ; revue de sécurité chiffrée ; charge de développement réestimée.",
  [("Proposer des pistes de relecteurs", "Claude", 0.5, 1, None),
   ("Rédiger la saisine (T-523), avec l'estimation de la charge de développement", "Claude", 0.5, 2, None),
   ("Relire la saisine ; contacter le relecteur", "toi", 1, 3, None),
   ("Envoyer la saisine avec l'architecture (TE-2)", "toi", 0.5, None, "e"),
   ("Intégrer l'avis ; chiffrage de la revue de sécurité (T-514) ; recalcul de la charge de code", "toi", 2, None, "a")],
  dep=["TE-2"], att=6, prio=2, inc="m")

I("TE-2", "Architecture technique", "toi, Claude",
  "Écrire le document d'architecture technique, préalable au développement.",
  "D-90 (calcul côté serveur, cache de verdicts) ; D-74 (accès à OBF) ; T-120 (canal de correction rapide) ; T-148 (hébergement) ; verrous de maintien 9 à 11 (niveau d'API, reconduction du compte, aucun paramètre en dur) ; T-232 (contraintes iOS dès Android) ; file de contributions retenue le 07/10 (stockage des photos, file de transcription, purge T-159, données personnelles T-415). Ta réponse du 27/10 : le développement commence après l'architecture, avec son planning dédié.",
  "Document écrit et validé ; hypothèses ouvertes listées.",
  [("Commencer le document : périmètre, contraintes, choix déjà décidés", "Claude", 1, 3, None),
   ("Base, API, back-office, mises à jour signées, sauvegarde", "Claude", 1, None, None),
   ("Accès à OBF, canal de correction, hébergement et coûts", "Claude", 1, None, None),
   ("File de contributions : photos, transcription, purge, données personnelles", "Claude", 0.5, None, None),
   ("Verrous de maintien 9 à 11, contraintes iOS", "Claude", 0.5, None, None),
   ("Relire et valider", "toi", 4, None, None)],
  prio=2, inc="m", debut=3)

I("TE-3", "Planning de développement", "toi, Claude",
  "Faire le planning dédié du développement, détaillé, au moment voulu.",
  "Ta réponse du 27/10 : « dès le début du code et après la réalisation de l'architecture technique, lui aussi aura un planning dédié bien détaillé. à discuter le moment voulu ». Les heures de TE-4 à TE-7 sont des ordres de grandeur (estimation du 20/10 reprise), remplacés par ce planning et par l'avis technique.",
  "Planning de développement établi et intégré à cette page.",
  [("Séance de planning du développement", "toi", 2, None, None),
   ("Découper TE-4 à TE-7 et les intégrer ici", "Claude", 1, None, None)],
  dep=["TE-2"], prio=2, inc="f")

I("TE-4", "Base, API, back-office", "toi",
  "Construire la base, l'API et le back-office.",
  "D-90 : verdicts calculés côté serveur et mis en cache ; T-32 : verdicts versionnés et estampillés ; T-474 : paramètres synchronisés, jamais en dur ; D-95 : sauvegarde restaurée une fois ; file de contributions (T-86, T-159, T-227). Ordre de grandeur en attendant TE-3 (une personne, sans second regard sur le code, D-93).",
  "Verdicts précalculés et versionnés ; mises à jour signées ; sauvegarde restaurée une fois ; file de contributions en place.",
  [("Schéma de la base et versionnage des verdicts", "toi", 20, None, None),
   ("Import des données (classeur vers la base)", "toi", 20, None, None),
   ("API de lecture", "toi", 20, None, None),
   ("Back-office : accès, saisie, contrôle", "toi", 40, None, None),
   ("Mises à jour signées", "toi", 15, None, None),
   ("Sauvegarde et restauration testée", "toi", 10, None, None),
   ("Paramètres synchronisés, jamais en dur (T-474)", "toi", 10, None, None),
   ("File de contributions : photos, transcription, purge, courriel neutre (T-86, T-159, T-227)", "toi", 20, None, None),
   ("Tests", "toi", 15, None, None)],
  dep=["TE-2", "TE-3"], dev=True, prio=2, inc="F")

I("TE-5", "Application Android", "toi",
  "Construire l'application Android à partir du prototype.",
  "Écrans du prototype (PR-3) ; hors-ligne et alertes ; contribution photo (T-82, T-161, T-448) ; module huiles essentielles (T-431) ; accessibilité (D-107) ; T-232 (contraintes iOS dès Android) ; T-238. Ordre de grandeur en attendant TE-3.",
  "Écrans du prototype construits, hors-ligne, alertes, contribution et module HE compris.",
  [("Scan du code-barres", "toi", 25, None, None),
   ("Écran produit et verdict à deux lignes", "toi", 40, None, None),
   ("Profil et parcours d'entrée", "toi", 15, None, None),
   ("Hors-ligne", "toi", 20, None, None),
   ("Alertes et mises à jour", "toi", 15, None, None),
   ("Signalement et contribution photo (T-82, T-161, T-448)", "toi", 20, None, None),
   ("Pages du module huiles essentielles (T-431)", "toi", 15, None, None),
   ("Accessibilité (palette de D-107)", "toi", 15, None, None),
   ("Contraintes iOS dès Android (T-232)", "toi", 5, None, None),
   ("Tests", "toi", 25, None, None)],
  dep=["TE-2", "TE-3", "PR-3"], dev=True, prio=2, inc="F")

I("TE-6", "Modèle intégré", "toi",
  "Intégrer le modèle figé et vérifier que le logiciel retrouve ses verdicts.",
  "MC-4 : moteur de référence et cas de test (T-593, D-289, T-441). MC-5 : modèle figé, paramètres hors du code. D-97.",
  "Le logiciel retrouve les cas de référence et les verdicts du moteur de référence sur tout le catalogue.",
  [("Intégrer le modèle figé", "toi", 10, None, None),
   ("Cas de référence en tests automatiques", "toi", 10, None, None),
   ("Comparer logiciel et moteur de référence sur tout le catalogue", "toi", 10, None, None)],
  dep=["MC-5", "MC-4", "TE-4", "TE-5", "CA-7"], dev=True, prio=2, inc="m")

I("TE-7", "Revue de sécurité", "tiers, toi",
  "Faire passer la revue de sécurité extérieure et corriger les défauts critiques.",
  "T-514 : revue centrée sur l'intégrité des verdicts (accès au back-office, passage du classeur vers la base, signature des mises à jour, protection contre l'aspiration, aucun secret dans l'application) ; si hors budget, liste de contrôle MASVS faite honnêtement. D-96.",
  "Revue faite ; défauts critiques corrigés.",
  [("Lancer la revue", "toi", 1, None, "e"),
   ("Corriger les défauts critiques", "toi", 10, None, "a")],
  dep=["TE-4", "TE-5", "TE-1", "PI-6"], att=4, dev=True, prio=2, inc="m")

# ======================================================================= JU
I("JU-1", "Rendez-vous avec la juriste", "toi",
  "Obtenir le rendez-vous, lui remettre l'additif corrigé et lui poser les questions nouvelles.",
  "T-418 : la juriste devait revenir vers toi avant la fin de la semaine du 19/10 ; le délai est passé, d'où la relance. T-610 : additif au dossier v3-2 avant le rendez-vous ; celui de ton Drive (24/10) garde deux phrases à corriger. Questions nouvelles : photos d'emballages en magasin (a, b, c), dénigrement (« contre-indiqué » sur un produit conforme), jauge, comparaison avec un concurrent. D-271, D-274 et D-277 sont déjà dans le dossier v3-2 (questions 3.8, 3.10, 3.11, partie 3) : à reprendre à l'oral.",
  "Rendez-vous tenu ; additif corrigé remis ; questions posées.",
  [("Relancer la juriste pour fixer le rendez-vous (T-418)", "toi", 0.25, 0, "e"),
   ("Corriger l'additif du 24/10 (deux phrases)", "Claude", 0.5, 2, None),
   ("Relire l'additif et la liste des questions", "toi", 1, 3, None),
   ("Remettre l'additif avant le rendez-vous", "toi", 0.25, None, "a"),
   ("Rendez-vous", "toi", 2, None, "a"),
   ("Compte rendu du rendez-vous", "Claude", 0.25, None, "a")],
  att=3, prio=1, inc="m", debut=0)

I("JU-2", "Réponses intégrées", "toi, Claude",
  "Verser les réponses de la juriste au registre, arbitrer le thème juridique et poser les questions de suite.",
  "Plusieurs items attendent sa note écrite (« trois semaines après signature », T-418) : T-464 (tests avec des femmes enceintes), question 7.2 (destination lue dans le site, les réseaux, la presse et les stores ; elle cadre le marketing), T-416 (rouge des huiles essentielles), questions (a)(b)(c) sur les photos, T-404 (détresse à l'écran, suspendue), O-21, O-22. O-52 et O-27 sont fermés sous sa réserve : à revérifier.",
  "Réponses versées ; thème juridique arbitré ; O-52 et O-27 revérifiés ; questions de suite posées.",
  [("Verser les réponses au registre", "Claude", 1, None, "a"),
   ("Relire le versement", "toi", 1, None, "a"),
   ("Arbitrer le thème juridique ; revérifier O-52 et O-27", "toi", 3, None, "a"),
   ("Poser les questions de suite", "toi", 0.5, None, "a")],
  dep=["JU-1"], att=4, prio=1, inc="m")

I("JU-3", "Marque", "toi",
  "Vérifier l'antériorité, déposer la marque Ficolia et prendre les noms de domaine.",
  "T-463 : recherche d'antériorité et dépôt ; le nom est devenu Ficolia (D-108) ; recherche préliminaire sans titulaire identifié ; à faire sur les signes identiques et proches (INPI, EUIPO, TMview). Revue du 28/10 : la marque doit être vérifiée et déposée avant tout usage public du nom (réseaux sociaux, MK-5).",
  "Antériorité vérifiée ; marque déposée ; noms de domaine pris.",
  [("Recherche d'antériorité (signes identiques et proches)", "toi", 1.5, None, None),
   ("Préparer la recherche et les classes", "Claude", 0.5, None, None),
   ("Déposer la marque", "toi", 2, None, None),
   ("Prendre les noms de domaine", "toi", 0.5, None, None)],
  prio=3, inc="f")

I("JU-4", "Structure éditrice", "toi",
  "Créer la structure qui éditera l'application. Lève VERROU-5.",
  "VERROU-5 : structure éditrice. T-134, O-7. Le compte de publication d'organisation (PU-2), les mentions légales (T-544) et l'assurance (JU-5) en dépendent.",
  "Structure immatriculée.",
  [("Choisir la forme, après les réponses de la juriste", "toi", 2, None, None),
   ("Rédiger et déposer les statuts", "toi", 3, None, "e"),
   ("Recevoir l'immatriculation ; inscrire la levée de VERROU-5", "toi", 0.5, None, "a")],
  dep=["JU-2"], att=3, prio=2, inc="m")

I("JU-5", "Assurance", "toi",
  "Souscrire l'assurance avant la publication. Lève VERROU-6.",
  "T-140 : assurance, souscrire avant publication, jamais après. VERROU-6.",
  "Contrat souscrit avant la publication.",
  [("Demander les devis", "toi", 1.5, None, "e"),
   ("Comparer et souscrire ; inscrire la levée de VERROU-6", "toi", 1.5, None, "a")],
  dep=["JU-4"], att=2, prio=2, inc="f")

I("JU-6", "Accord avec le toxicologue", "toi",
  "Écrire et signer l'accord avec le toxicologue.",
  "T-459 : encadrement contractuel. T-145 : lien avec la structure et responsabilité si un verdict qu'il a arbitré est contesté. T-171 et T-142 : il est « le plafond de croissance » ; sort du référentiel s'il se retire ou si le projet cesse. T-15 : son statut après la publication (posé en ②-G). T-572 : propriété du prompt, rédigé par une IA à partir de sa méthode (C-251). O-57.",
  "Accord écrit et signé.",
  [("Rédiger les points de l'accord", "Claude", 1, None, None),
   ("Les relire et les lui soumettre", "toi", 2, None, "e"),
   ("Signer", "toi", 1, None, "a")],
  dep=["JU-2", "GR-7"], att=2, prio=2, inc="m")

I("JU-7", "RGPD", "toi",
  "Tenir le registre des traitements, faire l'analyse d'impact si elle est requise et écrire la procédure des demandes.",
  "T-136 : registre des traitements. Les maquettes promettent un DPO, un hébergement en Europe, un export sous 30 jours (T-543). L'architecture réelle (TE-2) fixe ce qui est traité. File de contributions : la photo peut contenir une personne identifiable (T-415) ; conservation des photos (T-90, T-138) ; modération (T-89).",
  "Registre des traitements tenu ; analyse d'impact faite ou non requise et motivée ; procédure écrite.",
  [("Registre des traitements (T-136)", "toi", 1.5, None, None),
   ("Analyse d'impact si requise", "toi", 2, None, None),
   ("Procédure des demandes", "toi", 0.5, None, None),
   ("Durées de conservation et flux de la file de contributions (T-90, T-138, T-415)", "toi", 1.5, None, None),
   ("Premiers jets", "Claude", 1, None, None)],
  dep=["TE-2", "JU-2"], prio=3, inc="m")

I("JU-8", "Relectures", "juriste, toi",
  "Faire relire par la juriste les textes publics, les phrases du niveau 4 et la version réelle.",
  "T-264 : relecture juridique des textes publics (CGU, confidentialité, mentions légales, fiche méthode). T-262 : qualification en dispositif médical, qui se joue sur la destination revendiquée et la formulation des verdicts, donc sur la version réelle. T-604 : phrases du niveau 4 relues par la juriste.",
  "Textes publics, phrases du niveau 4 et version réelle relus ; corrections intégrées.",
  [("Envoyer les textes, les phrases du niveau 4 et l'accès à la version réelle", "toi", 1, None, "e"),
   ("Intégrer les corrections", "toi", 3.5, None, "a")],
  dep=["CT-6", "CT-1", "PR-5"], att=3, prio=2, inc="m")

I("JU-9", "Pièces de diligence", "Claude, toi",
  "Ranger les preuves du sérieux de la démarche.",
  "T-460 : documentation à conserver pour établir le sérieux de la démarche en cas de contentieux : empreintes des scellements (tirage du 28/10 compris), captures datées, traces des verrous.",
  "Dossier de diligence constitué et tenu.",
  [("Constituer le dossier (empreintes, captures datées, traces des verrous)", "Claude", 1, None, None),
   ("Le relire et le ranger", "toi", 2, None, None)],
  prio=5, inc="f")

# ======================================================================= MK
I("MK-1", "Cadrage du marketing", "toi",
  "Cadrer le marketing : objectifs, cible, canaux, budget, calendrier.",
  "Ta réponse du 27/10 : les réseaux sociaux d'abord, puis les maternités et la presse, sans influenceuses, du moins au début. Question 7.2 du dossier juriste : la destination de l'application se lit aussi dans le site, les réseaux, la presse et la fiche des stores. T-546 : mêmes règles pour les textes hors de l'application. Les maternités relèvent de la voie professionnelle (T-152, « dehors » au registre : « Rouvre la catégorie de store et la qualification »). Budget : sans réponse.",
  "Cadrage écrit, conforme à la réponse 7.2 ; T-152 re-statuée ; budget fixé.",
  [("Écrire le cadrage", "toi", 3, None, None),
   ("Fixer le budget du marketing", "toi", 1, None, None),
   ("Re-statuer T-152 (voie professionnelle) et poser la question des maternités à la juriste (7.2, T-262)", "toi", 1, None, None),
   ("Contrôler le cadrage contre T-546 et la réponse 7.2", "Claude", 1, None, None)],
  dep=["JU-2"], prio=4, inc="m")

I("MK-2", "Concurrence", "Claude, toi",
  "Mettre à jour la matrice de concurrence et ce qui nous différencie.",
  "T-485 : les applications spécialisées grossesse (VeriMom, MamaSkin, Skeenfit…) manquaient à l'analyse d'avril, dont la comparaison était circulaire. MamaSkin, relue le 22/10 (H10). T-553, T-567. T-522 : trois fichiers du 16/09 jamais ouverts. Rien de public sans la juriste.",
  "Matrice à jour ; différenciation à démontrer écrite.",
  [("Mettre la matrice à jour (ligne MamaSkin comprise)", "Claude", 2, None, None),
   ("La relire", "toi", 2, None, None),
   ("Écrire la différenciation à démontrer", "toi", 1, None, None)],
  prio=5, inc="m")

I("MK-3", "Messages", "toi",
  "Fixer la promesse, les revendications permises et l'accroche.",
  "T-534 : revendications de méthode à borner (« sources publiques exclusivement », « en cas de doute, toujours le plus restrictif », « méthode validée par un toxicologue »…) ; « méthode et outil de notre toxicologue » à proscrire (C-251).",
  "Promesse, revendications bornées et accroche écrites.",
  [("Borner les revendications (T-534)", "toi", 2, None, None),
   ("Écrire la promesse et l'accroche", "toi", 2, None, None),
   ("Contrôler contre les règles de CT-3", "Claude", 1, None, None)],
  dep=["MK-1", "CT-3"], prio=4, inc="m")

I("MK-4", "Fiche des stores", "toi, Claude",
  "Écrire les textes et préparer les visuels de la fiche des stores.",
  "T-506 : texte de la fiche de publication (périmètre explicite, portée du marché, aucune promesse de différenciation). Politiques santé des stores : PU-1.",
  "Textes et visuels prêts et conformes aux politiques santé.",
  [("Écrire les textes (T-506)", "toi", 2, None, None),
   ("Préparer les visuels", "toi", 3, None, None),
   ("Contrôler contre les politiques des stores", "Claude", 1, None, None)],
  dep=["MK-3", "PU-1", "PR-3"], prio=3, inc="m")

I("MK-5", "Présence hors application", "toi",
  "Préparer les réseaux sociaux d'abord, puis les maternités et la presse.",
  "Ta réponse du 27/10 : réseaux d'abord, maternités et presse ensuite, pas d'influenceuses au début. Le Gantt d'avril prévoyait Instagram, TikTok, des nano-influenceuses, les maternités et la presse. T-546 : règles des textes hors de l'application. La marque doit être déposée avant tout usage public du nom (JU-3).",
  "Comptes ouverts ; ligne éditoriale conforme ; premiers contenus prêts ; maternités et presse préparées si T-152 le permet.",
  [("Ouvrir les comptes et réserver les noms", "toi", 1, None, None),
   ("Ligne éditoriale conforme aux règles (T-546)", "toi", 2, None, None),
   ("Contrôler la ligne éditoriale", "Claude", 1, None, None),
   ("Préparer les premiers contenus", "toi", 6, None, None),
   ("Page de présentation minimale", "toi", 3, None, None),
   ("Second temps : préparer les contacts maternités et presse", "toi", 2, None, None)],
  dep=["MK-1", "MK-3", "JU-3"], prio=4, inc="F")

I("MK-6", "Plan de lancement", "toi",
  "Écrire le plan du mois avant au mois après la publication.",
  "Il ordonne MK-4 et MK-5 autour de la date de publication et prépare EX-2.",
  "Plan écrit.",
  [("Écrire le plan de lancement", "toi", 4, None, None),
   ("Le relire", "Claude", 1, None, None)],
  dep=["MK-4", "MK-5"], prio=4, inc="m")

# ======================================================================= PU
I("PU-1", "Politiques des stores", "Claude, toi",
  "Relever les exigences santé de Google Play et de l'App Store. Lève VERROU-8.",
  "T-7 : critères de rattachement à la catégorie santé ; la politique de Google s'applique selon le contenu (C-151). T-555 : exigences des stores pour les applications de santé (déclaration santé en console, politique de confidentialité, mention « n'est pas un dispositif médical… », rappel de consulter un professionnel, en tension avec T-117, O-27).",
  "Exigences relevées et sourcées ; décisions prises ; VERROU-8 levé.",
  [("Relever les exigences des deux stores (T-7, T-555)", "Claude", 1, 1, None),
   ("Relire et décider", "toi", 2, None, None),
   ("Inscrire la levée de VERROU-8", "toi", 1, None, None)],
  prio=2, inc="f")

I("PU-2", "Compte de publication", "toi",
  "Ouvrir le compte de publication Google Play.",
  "T-233 : compte personnel ou d'entreprise, après la structure. T-234 : compte d'organisation (structure, puis numéro D-U-N-S, jusqu'à 30 jours) ; un compte personnel impose un test fermé (12 testeurs pendant 14 jours), qui heurte la dimension 9 (pas de bêta fermée). VERROU-10 (maintien) : reconduction annuelle du compte.",
  "Compte ouvert et validé.",
  [("Choisir le type de compte (T-233)", "toi", 0.5, None, None),
   ("Demander le D-U-N-S et ouvrir le compte", "toi", 1.5, None, "e"),
   ("Valider le compte", "toi", 1, None, "a")],
  dep=["JU-4"], att=4, prio=2, inc="m")

I("PU-3", "Déclarations", "toi, Claude",
  "Préparer les déclarations des stores : sécurité des données, catégorie, santé, classification par âge.",
  "T-503 : fiche « Sécurité des données » de Google Play, cohérente avec l'étanchéité et T-462. T-235 : catégorie de publication, jamais inventoriée. T-555 : déclaration santé. T-232 : déclaration iOS par type de donnée. T-162 : classification par âge, questionnaire obligatoire des stores (D-21 : adolescente enceinte).",
  "Déclarations prêtes et cohérentes avec l'architecture réelle.",
  [("Fiche « Sécurité des données » (T-503)", "toi", 1.5, None, None),
   ("Catégorie de publication (T-235)", "toi", 1, None, None),
   ("Déclaration santé (T-555)", "toi", 1, None, None),
   ("Classification par âge (T-162)", "toi", 0.5, None, None),
   ("Premiers jets et contrôle de cohérence", "Claude", 1.5, None, None)],
  dep=["PU-1", "TE-2", "JU-7"], prio=3, inc="f")

I("PU-4", "Décision de lancement", "toi",
  "Décider du lancement : tout le plancher en vigueur est clos ou reporté par décision, tous les verrous sont levés. JALON-05.",
  "JALON-05 proposé (réécrit le 20/10, sous réserve de T-521). Plancher en vigueur : 272 tâches en v6.7, près de 300 si l'arbitrage accepte toutes les propositions « plancher ». Verrous de publication : 1, 2, 3, 5, 6, 7, 8 et 12 (4 levé). Le jalon exige aussi un compte ouvert, une marque déposée et une exploitation prête.",
  "Les tâches au plancher en vigueur sont closes ou reportées par décision ; les verrous sont levés ; la décision est écrite.",
  [("Contrôler le plancher tâche par tâche", "Claude", 1, None, None),
   ("Contrôler les verrous", "Claude", 0.5, None, None),
   ("Décider et inscrire", "toi", 2.5, None, None)],
  dep=["GR-12", "AL-10", "AL-6", "RF-4", "RF-5", "MC-5", "CT-2", "CT-4", "CT-5", "CT-6", "CA-7",
       "PR-5", "TE-6", "TE-7", "JU-3", "JU-5", "JU-6", "JU-7", "JU-8", "JU-9", "PU-2", "PU-3",
       "EX-1", "PI-6", "PI-8", "MK-4", "MK-6", "GR-14"], prio=1, inc="f")

I("PU-5", "Soumission", "toi",
  "Soumettre l'application à Google Play. iOS hors date.",
  "T-231 : iOS hors date (annexe). Google : examen « habituellement sept jours ou moins » (aide lue le 17/10).",
  "Application acceptée et publiée sur Google Play.",
  [("Soumettre", "toi", 1.5, None, "e"),
   ("Répondre aux demandes de la revue ; publier", "toi", 1.5, None, "a")],
  dep=["PU-4"], att=1, prio=1, inc="f")

# ======================================================================= EX
I("EX-1", "Préparer l'exploitation", "toi",
  "Préparer le support, la continuité et la charge d'exploitation. Lève VERROU-7.",
  "VERROU-7 : politique de support (réponses types). T-168 : note de continuité d'une page (fichiers, comptes, interlocuteurs, reconduction du compte développeur, VERROU-10). T-500 : indicateurs d'exploitation. T-15 : disponibilité du toxicologue après la publication (posée en ②-G). File de contributions : charge (T-51, 25 % d'illisibles à ne pas utiliser en l'état), modération et exposition du vérificateur (T-89, T-138). T-60, T-94, T-127.",
  "Réponses types, note de continuité, charge estimée et indicateurs écrits ; VERROU-7 levé.",
  [("Réponses types du support", "toi", 4, None, None),
   ("Premiers jets des réponses types", "Claude", 1, None, None),
   ("Note de continuité (T-168)", "toi", 3, None, None),
   ("Estimer la charge d'exploitation, file de contributions comprise (T-51, T-89, T-138)", "toi", 3, None, None),
   ("Indicateurs d'exploitation (T-500)", "Claude", 1, None, None),
   ("Valider les indicateurs", "toi", 1, None, None),
   ("Intégrer la disponibilité du toxicologue après la publication (T-15)", "toi", 1, None, None),
   ("File et agrégation (T-60, T-94)", "Claude", 1, None, None),
   ("Inscrire la levée de VERROU-7", "toi", 2, None, None)],
  dep=["GR-7", "TE-2"], prio=3, inc="m")

I("EX-2", "Premier mois", "toi",
  "Suivre le premier mois après la publication. Hors du pourcentage.",
  "T-500 : indicateurs d'exploitation ; T-520. Le plan de lancement (MK-6) en fixe le contenu marketing ; maternités et presse en second temps.",
  "Un mois suivi ; bilan écrit.",
  [("Suivre les indicateurs chaque semaine (T-500)", "toi", 4, None, None),
   ("Répondre aux avis des stores", "toi", 4, None, None),
   ("Traiter les signalements et les contributions", "toi", 6, None, None),
   ("Corrections urgentes", "toi", 4, None, None),
   ("Bilan à un mois", "toi", 2, None, None)],
  dep=["PU-5"], prio=1, inc="m", hors_pct=True)
